package com.example.demo.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class MarketService {

    // Stores the live multiplier for each stock (e.g., "Apple" -> 1.05)
    private final ConcurrentHashMap<String, Double> priceMultipliers = new ConcurrentHashMap<>();

    // 1. GET LIVE PRICE
    // Formula: Original Price * Current Market Multiplier
    public double getCurrentPrice(String assetName, Double basePrice) {
        String key = assetName.toLowerCase().trim();

        // If we haven't tracked this stock yet, start it at 1.0 (original price)
        priceMultipliers.putIfAbsent(key, 1.0);

        return basePrice * priceMultipliers.get(key);
    }

    // 2. BACKGROUND TASK: RUNS EVERY 2 SECONDS
    @Scheduled(fixedRate = 2000) // <--- Changed to 2000ms (2 seconds)
    public void simulateMarket() {

        // Loop through every stock we know about
        for (String key : priceMultipliers.keySet()) {
            double currentFactor = priceMultipliers.get(key);

            // Randomly fluctuate between -2% and +2%
            double change = 0.98 + (ThreadLocalRandom.current().nextDouble() * 0.04);

            double newFactor = currentFactor * change;

            // Safety limits: Don't let stock crash to 0 or explode to 500%
            if (newFactor < 0.1) newFactor = 0.1;
            if (newFactor > 5.0) newFactor = 5.0;

            priceMultipliers.put(key, newFactor);
        }

        // Print to console so you know it's working
//        System.out.println(">>> Market Updated (2s): Prices fluctuated.");
    }
}