package com.example.demo.repository;

import com.example.demo.bean.Asset;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AssetRepository extends JpaRepository<Asset, Integer> {

    List<Asset> findByPortfolioId(Integer portfolioId);

    // For live price simulation
    List<Asset> findByName(String name);

    // --- NEW: Get all unique asset names for Market View ---
    @Query("SELECT DISTINCT a.name FROM Asset a")
    List<String> findDistinctNames();

    // --- ADDED FOR DELETE VALIDATION ---
    // This allows the Service to check the DB before deleting a portfolio
    boolean existsByPortfolioId(Integer portfolioId);

    // Add this to your PortfolioRepository interface
    boolean existsByPortfolioIdAndName(Integer portfolioId, String name);
    // long countByName(String name);
    // Change countByName to this:
    long countByNameIgnoreCase(String name);
    List<Asset> findByNameIgnoreCase(String name);
    //List<Asset> findByPortfolioId(Integer portfolioId);

    // Keep your other existing methods...

}