package com.example.demo.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class DuplicatePortfolioNameException extends RuntimeException {
    @Override
    public synchronized Throwable fillInStackTrace() { return this; }

    public DuplicatePortfolioNameException(String name) {
        super(String.format("You already have a portfolio named '%s'. Please choose a unique name.", name));
    }
}