package com.example.demo.Exceptions;
import com.example.demo.Exceptions.AssetInUseException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class AssetInUseException extends RuntimeException {

    @Override
    public synchronized Throwable fillInStackTrace() { return this; }

    public AssetInUseException(String assetName, long count) {
        super(String.format("Cannot delete '%s'! There are %d investors currently holding this asset in their portfolios.",
                assetName, count));
    }
}