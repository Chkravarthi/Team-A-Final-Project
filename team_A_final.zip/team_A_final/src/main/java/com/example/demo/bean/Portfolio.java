package com.example.demo.bean;

import jakarta.persistence.*;
import java.math.BigDecimal;
import jakarta.validation.constraints.DecimalMin;

@Entity
@Table(name = "portfolio") // Ensure table name matches DB (case sensitive in Linux)
public class Portfolio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer portfolioId;

    private String portfolioName;

    @DecimalMin(value = "0.01", message = "Target goal must be greater than zero")
    @Column(precision = 10, scale = 2)
    private BigDecimal totalValue; // This is the "Target Goal" amount

    @Enumerated(EnumType.STRING)
    private RiskLevel riskLevel;

    private Integer investorId;

    // --- TRANSIENT FIELDS (UI Only, Not in DB) ---
    @Transient private double liveValue;        // Current Market Value
    @Transient private double growthPct;        // Progress towards Goal

    @Transient private double investedAmount;   // Total Buy Price
    @Transient private double profitLossPct;    // (Live - Invested) / Invested

    public enum RiskLevel { HIGH, MEDIUM, LOW }

    // --- Getters & Setters ---
    public Integer getPortfolioId() { return portfolioId; }
    public void setPortfolioId(Integer portfolioId) { this.portfolioId = portfolioId; }

    public String getPortfolioName() { return portfolioName; }
    public void setPortfolioName(String portfolioName) { this.portfolioName = portfolioName; }

    public BigDecimal getTotalValue() { return totalValue; }
    public void setTotalValue(BigDecimal totalValue) { this.totalValue = totalValue; }

    public RiskLevel getRiskLevel() { return riskLevel; }
    public void setRiskLevel(RiskLevel riskLevel) { this.riskLevel = riskLevel; }

    public Integer getInvestorId() { return investorId; }
    public void setInvestorId(Integer investorId) { this.investorId = investorId; }

    // --- Live Data Getters/Setters ---
    public double getLiveValue() { return liveValue; }
    public void setLiveValue(double liveValue) { this.liveValue = liveValue; }

    public double getGrowthPct() { return growthPct; }
    public void setGrowthPct(double growthPct) { this.growthPct = growthPct; }

    public double getInvestedAmount() { return investedAmount; }
    public void setInvestedAmount(double investedAmount) { this.investedAmount = investedAmount; }

    public double getProfitLossPct() { return profitLossPct; }
    public void setProfitLossPct(double profitLossPct) { this.profitLossPct = profitLossPct; }
}