package com.example.demo.controller;

import com.example.demo.bean.Ticket;
import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import com.example.demo.repository.TicketRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;

@Controller
public class TicketController {

    @Autowired private TicketRepository ticketRepository;
    @Autowired private AuthRepository authRepository;

    // --- 1. INVESTOR: RAISE TICKET ---
    @PostMapping("/ticket/raise")
    public String raiseTicket(@RequestParam String requestType,
                              @RequestParam String description,
                              HttpSession session) {

        Integer investorId = (Integer) session.getAttribute("userId");

        Ticket t = new Ticket();
        t.setInvestorId(investorId);
        t.setRequestType(requestType);
        t.setDescription(description);
        t.setStatus("OPEN");
        t.setCreatedAt(new Date());

        ticketRepository.save(t);

        return "redirect:/welcome?success=TicketRaised";
    }

    // --- 2. ADMIN: RESOLVE TICKET ---
    @PostMapping("/admin/ticket/resolve")
    public String resolveTicket(@RequestParam Integer ticketId) {

        Ticket t = ticketRepository.findById(ticketId).orElse(null);

        if (t != null) {
            // A. If it's a Disconnect Request, perform the action automatically
            if ("DISCONNECT_ADVISOR".equals(t.getRequestType())) {
                User investor = authRepository.findById(t.getInvestorId()).orElse(null);
                if (investor != null) {
                    investor.setAdvisorId(null);
                    investor.setConnectionStatus(null);
                    authRepository.save(investor);
                }
            }

            // B. Mark Ticket as Resolved
            t.setStatus("RESOLVED");
            ticketRepository.save(t);
        }

        return "redirect:/welcome?success=TicketResolved";
    }
}