package com.example.demo.repository;

import com.example.demo.bean.PerformanceReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PerformanceRepository extends JpaRepository<PerformanceReport, Integer> {

    // Fetch reports for a specific portfolio
    List<PerformanceReport> findByPortfolioId(Integer portfolioId);
}