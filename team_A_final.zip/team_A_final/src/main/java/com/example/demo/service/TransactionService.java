package com.example.demo.service;

import com.example.demo.bean.Transaction;
import com.example.demo.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class TransactionService {

    @Autowired private TransactionRepository transactionRepository;

    // 1. RECORD A NEW TRANSACTION
    public void record(Integer userId, String type, String assetName, Integer qty, Double price) {
        try {
            Transaction t = new Transaction();
            t.setUserId(userId);
            t.setType(type);
            t.setAssetName(assetName);
            t.setQuantity(qty);
            t.setPrice(price);
            t.setTransactionDate(new Date());
            transactionRepository.save(t);
        } catch (Exception e) {
            System.err.println("Error saving transaction: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // 2. FETCH HISTORY (Investor View)
    public List<Transaction> getTransactionsByUserId(Integer userId) {
        return transactionRepository.findByUserIdOrderByTransactionDateDesc(userId);
    }

    // 3. FETCH SINGLE RECEIPT
    public Transaction getTransactionById(Integer id) {
        return transactionRepository.findById(id).orElse(null);
    }

    // 4. ADMIN VIEW (Fetch All)
    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    // 5. CALCULATE AVERAGE BUY PRICE
    public double calculateAvgBuyPrice(Integer userId, String assetName) {
        List<Transaction> transactions = transactionRepository.findByUserIdOrderByTransactionDateDesc(userId);
        if (transactions == null || transactions.isEmpty()) return 0.0;

        double totalCost = 0.0;
        int totalQty = 0;

        for (Transaction t : transactions) {
            if ("BUY".equalsIgnoreCase(t.getType()) &&
                    t.getAssetName().equalsIgnoreCase(assetName)) {

                totalCost += (t.getPrice() * t.getQuantity());
                totalQty += t.getQuantity();
            }
        }

        if (totalQty == 0) return 0.0;
        return totalCost / totalQty;
    }

    // 6. FILTER TRANSACTIONS BY DATE (Added for Analytics Page)
    public List<Transaction> getTransactionsByDateRange(Integer userId, Date startDate, Date endDate) {
        if (startDate == null || endDate == null) {
            return transactionRepository.findByUserIdOrderByTransactionDateDesc(userId);
        }
        return transactionRepository.findByUserIdAndTransactionDateBetween(userId, startDate, endDate);
    }
}