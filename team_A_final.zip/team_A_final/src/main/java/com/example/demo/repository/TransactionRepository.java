package com.example.demo.repository;

import com.example.demo.bean.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date; // CHANGED: Using java.util.Date to match your Entity
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer> {

    // Existing method
    List<Transaction> findByUserIdOrderByTransactionDateDesc(Integer userId);

    // Filter by User ID
    List<Transaction> findByUserId(Integer userId);

    // FIX 1: Renamed 'Date' to 'TransactionDate' to match Entity field
    // FIX 2: Changed parameter type to Date
    List<Transaction> findByUserIdAndTransactionDateBetween(Integer userId, Date startDate, Date endDate);
}