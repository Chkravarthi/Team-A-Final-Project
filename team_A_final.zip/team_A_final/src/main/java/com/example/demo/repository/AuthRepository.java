package com.example.demo.repository;

import com.example.demo.bean.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AuthRepository extends JpaRepository<User, Integer> {

    // --- Login & Registration ---
    Optional<User> findByEmail(String email);
    User findByUsername(String username);

    // Validations (Crucial for AuthController)
    boolean existsByEmail(String email);
    boolean existsByUsername(String username);

    // --- Role Based Queries ---
    List<User> findByRole(String role);
    List<User> findByRoleAndStatus(String role, String status);

    // --- Advisor/Client Management ---
    // This is the specific method you were missing:
    List<User> findByAdvisorId(Integer advisorId);
    List<User> findByAdvisorIdAndConnectionStatus(Integer advisorId, String connectionStatus);
    // Filter clients by status (Active vs Pending)
    @Query(value = "SELECT u.username FROM User u WHERE u.user_id = (SELECT p.investorId FROM portfolio p WHERE p.portfolioId = :portfolioId)", nativeQuery = true)
    String findUsernameByPortfolioId(@Param("portfolioId") Integer portfolioId);
}