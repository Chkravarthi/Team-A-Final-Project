package com.example.demo.bean;

import jakarta.persistence.*;

@Entity
@Table(name = "User") // Matched exact table name
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer userId;

    private String username;
    private String email;
    private String password;
    private String role; // "ADMIN", "ADVISOR", "INVESTOR"

    @Column(name = "advisor_id")
    private Integer advisorId;

    @Column(name = "connection_status")
    private String connectionStatus;

    private String status; // "PENDING", "APPROVED"

    // Extra fields for Advisors
    private String qualification;
    private String experience;

    public User() {}

    // --- GETTERS AND SETTERS ---

    // 1. Primary ID (Mapped to DB column 'user_id')
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    // 2. Compatibility Helper (Prevents "cannot find symbol" errors)
    // This allows controllers to call user.getId() safely
    public Integer getId() {
        return userId;
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public Integer getAdvisorId() { return advisorId; }
    public void setAdvisorId(Integer advisorId) { this.advisorId = advisorId; }

    public String getConnectionStatus() { return connectionStatus; }
    public void setConnectionStatus(String connectionStatus) { this.connectionStatus = connectionStatus; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getQualification() { return qualification; }
    public void setQualification(String qualification) { this.qualification = qualification; }

    public String getExperience() { return experience; }
    public void setExperience(String experience) { this.experience = experience; }
}