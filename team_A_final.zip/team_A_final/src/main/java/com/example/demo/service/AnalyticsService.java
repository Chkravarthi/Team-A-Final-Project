package com.example.demo.service;

import com.example.demo.bean.Asset;
import com.example.demo.bean.PerformanceReport;
import com.example.demo.bean.Portfolio;
import com.example.demo.repository.AssetRepository;
import com.example.demo.repository.PerformanceRepository;
import com.example.demo.repository.PortfolioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AnalyticsService {

    @Autowired private PerformanceRepository performanceRepository;
    @Autowired private PortfolioRepository portfolioRepository;
    @Autowired private AssetService assetService;
    @Autowired private AssetRepository assetRepository;

    // --- HELPER: Get All Market Asset Names ---
    public List<String> getAllMarketAssetNames() {
        return assetRepository.findDistinctNames();
    }

    // --- HELPER: Safe Value Extraction ---
    private double getSafeValue(Asset a) {
        if (a == null || a.getPrice() == null || a.getQuantity() == null) {
            return 0.0;
        }
        return a.getPrice() * a.getQuantity();
    }

    // --- GET LIVE PRICE (Advanced Simulation: Curves + Noise) ---
    public double getLiveAssetPrice(String assetName) {
        if (assetName == null || assetName.trim().isEmpty()) return 0.0;

        List<Asset> assets = assetRepository.findByName(assetName);
        double realBasePrice = 0.0;

        if (assets != null && !assets.isEmpty()) {
            realBasePrice = assets.get(0).getPrice();
        } else {
            // Handle unknown assets gracefully
            return 0.0;
        }

        // --- MARKET MAKER LOGIC ---
        // 1. Get current time in seconds to drive the curve
        long time = System.currentTimeMillis() / 1000;

        // 2. Create a "Trend Curve" using Sine Wave
        // The division by 20.0 slows down the wave (longer cycles)
        // The * 0.02 means the price swings up/down by roughly 2% in a cycle
        double trend = Math.sin(time / 20.0) * 0.02;

        // 3. Add Random "Jitter" (Volatility) for realism
        // Small random noise between -0.5% and +0.5%
        double noise = (Math.random() - 0.5) / 100.0;

        // 4. Combine Base + Trend + Noise
        double multiplier = 1.0 + trend + noise;

        return realBasePrice * multiplier;
    }

    // --- 1. Generate Report ---
    public PerformanceReport generateReport(Integer portfolioId) {
        Portfolio p = portfolioRepository.findById(portfolioId).orElse(null);
        if (p == null) return null;

        List<Asset> assets = assetService.getAssetsByPortfolio(portfolioId);
        double currentVal = 0.0;

        for (Asset a : assets) {
            if (a.getPrice() != null && a.getQuantity() != null) {
                // Keep simple volatility for the static report snapshot
                double volatility = 0.98 + (Math.random() * 0.04);
                currentVal += (a.getPrice() * volatility * a.getQuantity());
            }
        }

        double initialVal = (p.getTotalValue() != null) ? p.getTotalValue().doubleValue() : 0.0;
        double returnPct = 0.0;

        if (initialVal > 0) {
            returnPct = ((currentVal - initialVal) / initialVal) * 100;
        }

        PerformanceReport report = new PerformanceReport();
        report.setPortfolioId(portfolioId);
        report.setReportDate(LocalDate.now());
        report.setReturnPercentage(BigDecimal.valueOf(returnPct).setScale(2, RoundingMode.HALF_UP));

        double risk = 1.0;
        if (p.getRiskLevel() != null) {
            switch (p.getRiskLevel()) {
                case HIGH -> risk = 8.5;
                case MEDIUM -> risk = 5.5;
                case LOW -> risk = 2.5;
                default -> risk = 1.0;
            }
        }
        report.setRiskScore(BigDecimal.valueOf(risk).setScale(2, RoundingMode.HALF_UP));

        return performanceRepository.save(report);
    }

    // --- 2. Asset Allocation ---
    public Map<String, Double> getAssetAllocation(Integer portfolioId) {
        List<Asset> assets = assetService.getAssetsByPortfolio(portfolioId);
        Map<String, Double> allocation = new HashMap<>();

        if (assets == null || assets.isEmpty()) return allocation;

        double totalValue = 0.0;
        for (Asset a : assets) totalValue += getSafeValue(a);

        if (totalValue > 0) {
            for (Asset a : assets) {
                double assetVal = getSafeValue(a);
                double pct = (assetVal / totalValue) * 100;
                allocation.merge(a.getName(), pct, Double::sum);
            }
        }

        for (Map.Entry<String, Double> entry : allocation.entrySet()) {
            entry.setValue(BigDecimal.valueOf(entry.getValue())
                    .setScale(2, RoundingMode.HALF_UP).doubleValue());
        }
        return allocation;
    }

    // --- 3. Investor Performance ---
    public double getInvestorTotalPerformance(Integer investorId) {
        List<Portfolio> portfolios = portfolioRepository.findByInvestorId(investorId);
        if (portfolios == null || portfolios.isEmpty()) return 0.0;

        double totalInitial = 0.0;
        double totalCurrent = 0.0;

        for (Portfolio p : portfolios) {
            totalInitial += (p.getTotalValue() != null) ? p.getTotalValue().doubleValue() : 0.0;
            List<Asset> assets = assetService.getAssetsByPortfolio(p.getPortfolioId());
            for (Asset a : assets) {
                totalCurrent += getSafeValue(a);
            }
        }

        if (totalInitial == 0) return 0.0;
        double val = ((totalCurrent - totalInitial) / totalInitial) * 100;
        return BigDecimal.valueOf(val).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public double getWholeMarketAverage() { return 12.50; }

    // --- 4. System Allocation ---
    public Map<String, Double> getSystemWideAllocation() {
        List<Asset> allAssets = assetRepository.findAll();
        Map<String, Double> allocation = new HashMap<>();
        double totalValue = 0.0;
        for (Asset a : allAssets) totalValue += getSafeValue(a);
        if (totalValue > 0) {
            for (Asset a : allAssets) {
                double assetVal = getSafeValue(a);
                double pct = (assetVal / totalValue) * 100;
                allocation.merge(a.getName(), pct, Double::sum);
            }
        }
        for (Map.Entry<String, Double> entry : allocation.entrySet()) {
            entry.setValue(BigDecimal.valueOf(entry.getValue()).setScale(2, RoundingMode.HALF_UP).doubleValue());
        }
        return allocation;
    }

    // --- 5. Leaderboard ---
    public List<PerformanceReport> getTopPortfolios() {
        List<Portfolio> all = portfolioRepository.findAll();
        List<PerformanceReport> reports = new ArrayList<>();
        for (Portfolio p : all) {
            PerformanceReport r = generateReport(p.getPortfolioId());
            if(r != null) reports.add(r);
        }
        reports.sort((r1, r2) -> r2.getReturnPercentage().compareTo(r1.getReturnPercentage()));
        return reports.stream().limit(3).toList();
    }
}