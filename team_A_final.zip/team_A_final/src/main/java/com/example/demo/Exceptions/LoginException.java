//package com.example.demo.Exceptions;
//
//public class LoginException extends Exception {
//    public LoginException(String message) {
//        super(message);
//    }
//}

package com.example.demo.Exceptions;

public class LoginException extends RuntimeException {
    public LoginException(String message) {
        super(message);
    }
}