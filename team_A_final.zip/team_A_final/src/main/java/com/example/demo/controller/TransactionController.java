package com.example.demo.controller;

import com.example.demo.bean.Transaction;
import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import com.example.demo.service.TransactionService;
import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.awt.Color; // Explicitly import AWT Color to avoid conflict
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class TransactionController {

    @Autowired private TransactionService transactionService;
    @Autowired private AuthRepository authRepository;

    @GetMapping("/transaction")
    public String showTransactions(@RequestParam(required = false) Integer viewUserId,
                                   HttpSession session, Model model) {

        Integer userId = (Integer) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");

        if (userId == null) return "redirect:/signin";

        // --- 1. ADMIN VIEW LOGIC (New Card Flow) ---
        if ("ADMIN".equals(role)) {
            if (viewUserId == null) {
                // SHOW USER CARDS: Fetch all investors so Admin can pick one
                List<User> investors = authRepository.findByRole("INVESTOR");
                model.addAttribute("investorList", investors);
                model.addAttribute("viewMode", "USER_LIST"); // Signals JSP to show Cards
                return "transaction";
            } else {
                // SHOW HISTORY TABLE: Admin clicked a specific user
                List<Transaction> transactions = transactionService.getTransactionsByUserId(viewUserId);
                User selectedUser = authRepository.findById(viewUserId).orElse(new User());

                model.addAttribute("transactionList", transactions);
                model.addAttribute("selectedUser", selectedUser);

                // We still populate userMap just in case your JSP relies on it for names
                Map<Integer, User> userMap = new HashMap<>();
                userMap.put(viewUserId, selectedUser);
                model.addAttribute("userMap", userMap);

                model.addAttribute("viewMode", "HISTORY_TABLE"); // Signals JSP to show Table
                return "transaction";
            }
        }

        // --- 2. ADVISOR VIEW LOGIC ---
        else if ("ADVISOR".equals(role)) {
            // Per your request, Advisors don't use this menu, but keeping logic safe
            return "redirect:/welcome";
        }

        // --- 3. INVESTOR VIEW LOGIC (Standard) ---
        else {
            List<Transaction> transactionList = transactionService.getTransactionsByUserId(userId);
            model.addAttribute("transactionList", transactionList);
            model.addAttribute("viewMode", "HISTORY_TABLE");
            return "transaction";
        }
    }

    // --- PDF DOWNLOAD FUNCTIONALITY (Kept Exactly as is) ---
    @GetMapping("/transaction/download")
    public void downloadInvoice(@RequestParam("id") Integer id, HttpServletResponse response) throws IOException {
        Transaction t = transactionService.getTransactionById(id);

        if (t == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=Trade_Invoice_" + id + ".pdf");

        try (Document document = new Document(PageSize.A4)) {
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, Color.DARK_GRAY);
            Paragraph header = new Paragraph("GROWMORE WEALTH MANAGEMENT", headerFont);
            header.setAlignment(Element.ALIGN_CENTER);
            document.add(header);

            Paragraph subHeader = new Paragraph("Official Transaction Receipt", FontFactory.getFont(FontFactory.HELVETICA, 12, Color.GRAY));
            subHeader.setAlignment(Element.ALIGN_CENTER);
            document.add(subHeader);

            document.add(new Paragraph(" "));
            document.add(new Paragraph("------------------------------------------------------------------------------------------"));

            Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
            Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 12);

            addDetail(document, "Transaction ID:", String.valueOf(t.getTransactionId()), labelFont, valueFont);
            addDetail(document, "Date:", t.getTransactionDate().toString(), labelFont, valueFont);
            addDetail(document, "Investor ID:", String.valueOf(t.getUserId()), labelFont, valueFont);

            document.add(new Paragraph(" "));

            addDetail(document, "Asset Name:", t.getAssetName(), labelFont, valueFont);
            addDetail(document, "Action Type:", t.getType(), labelFont, valueFont);
            addDetail(document, "Quantity:", String.valueOf(t.getQuantity()), labelFont, valueFont);
            addDetail(document, "Unit Price:", "Rs. " + t.getPrice(), labelFont, valueFont);

            document.add(new Paragraph("------------------------------------------------------------------------------------------"));

            Paragraph total = new Paragraph("TOTAL AMOUNT: Rs. " + String.format("%.2f", (t.getQuantity() * t.getPrice())),
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, Color.BLUE));
            total.setAlignment(Element.ALIGN_RIGHT);
            document.add(total);

            document.add(new Paragraph(" "));
            Paragraph footer = new Paragraph("This is a computer-generated invoice and does not require a signature.",
                    FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 10, Color.GRAY));
            footer.setAlignment(Element.ALIGN_CENTER);
            document.add(footer);

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addDetail(Document doc, String label, String value, Font labelFont, Font valueFont) throws DocumentException {
        Paragraph p = new Paragraph();
        p.add(new Chunk(label + " ", labelFont));
        p.add(new Chunk(value, valueFont));
        doc.add(p);
    }
}