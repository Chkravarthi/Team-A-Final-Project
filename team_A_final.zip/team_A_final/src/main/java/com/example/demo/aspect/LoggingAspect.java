package com.example.demo.aspect;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Aspect
@Component
public class LoggingAspect {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    // 1. Controller Methods (Keep this as is)
    @Pointcut("execution(* com.example.demo.controller.*.*(..))")
    public void controllerMethods() {}

    // 2. Service Methods (UPDATED TO IGNORE NOISY METHODS)
    // The '&& !execution(...)' part tells AOP to skip the simulateMarket method
    @Pointcut("execution(* com.example.demo.service.*.*(..)) " +
            "&& !execution(* com.example.demo.service.MarketService.simulateMarket(..)) " +
            "&& !execution(* com.example.demo.service.MarketService.getCurrentPrice(..))")
    public void serviceMethods() {}

    // --- The rest of your code remains exactly the same ---

    @Before("controllerMethods()")
    public void logUserActivity(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();

        String user = "Anonymous";
        try {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes != null) {
                HttpServletRequest request = attributes.getRequest();
                HttpSession session = request.getSession(false);
                if (session != null && session.getAttribute("userName") != null) {
                    user = (String) session.getAttribute("userName");
                }
            }
        } catch (Exception e) { }

        logger.info("USER TRACKING: [{}] executed {} in {}", user, methodName, className);
    }

    @Around("serviceMethods()")
    public Object measureExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        Object proceed = joinPoint.proceed();
        long executionTime = System.currentTimeMillis() - start;

        // Optional: Only log if it takes longer than 5ms to reduce noise further
        if (executionTime > 5) {
            logger.info("------------------- PERFORMANCE: {} executed in {} ms", joinPoint.getSignature().getName(), executionTime);
        }
        return proceed;
    }
}