package com.example.demo.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import java.math.BigDecimal;

@ResponseStatus(HttpStatus.PAYMENT_REQUIRED)
public class InsufficientPortfolioBalanceException extends RuntimeException {
    @Override
    public synchronized Throwable fillInStackTrace() { return this; }

    public InsufficientPortfolioBalanceException(BigDecimal required, BigDecimal available) {
        super(String.format("Transaction failed. Required: $%.2f, Available: $%.2f", required, available));
    }
}