package com.example.demo.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InsufficientAssetQuantityException extends RuntimeException {
    @Override
    public synchronized Throwable fillInStackTrace() { return this; }

    public InsufficientAssetQuantityException(String assetName, int owned, int requested) {
        super(String.format("Failed to sell! You only have %d unit(s) of %s, but you tried to sell %d.",
                owned, assetName, requested));
    }
}