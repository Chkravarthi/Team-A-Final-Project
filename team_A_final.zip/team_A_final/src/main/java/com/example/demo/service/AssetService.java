package com.example.demo.service;

import com.example.demo.Exceptions.AssetInUseException;
import com.example.demo.bean.Asset;
import com.example.demo.repository.AssetRepository;
import com.example.demo.repository.AuthRepository;
import com.example.demo.repository.PortfolioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AssetService {

    @Autowired
    private AssetRepository assetRepository;

    // --- 1. READ OPERATIONS ---


    public void addAssetToPortfolio(Asset asset) {
        // 1. Check if this asset name already exists in this portfolio
        boolean alreadyOwned = assetRepository.existsByPortfolioIdAndName(
                asset.getPortfolioId(), asset.getName());

        if (alreadyOwned) {
            // 2. Throw an exception (You can create 'DuplicateAssetException')
            throw new RuntimeException("Asset '" + asset.getName() + "' is already in this portfolio!");
        }

        assetRepository.save(asset);
    }
  //  @Autowired private AuthRepository authRepository;

    @Autowired private PortfolioRepository portfolioRepository; // Add this repository
    @Autowired private AuthRepository authRepository;



    public void deleteAssetSafely(Integer assetId) {
        // 1. Get the master asset
        Asset asset = assetRepository.findById(assetId)
                .orElseThrow(() -> new RuntimeException("Asset not found"));

        // 2. Find all records with this name (Admin + Investors)
        List<Asset> holdings = assetRepository.findByNameIgnoreCase(asset.getName());

        List<String> investorNames = new ArrayList<>();

        for (Asset h : holdings) {
            // 3. If it's not the record we are trying to delete, it's an investor
            if (!h.getAssetId().equals(assetId)) {
                // Get the name using the query we fixed above
                String name = authRepository.findUsernameByPortfolioId(h.getPortfolioId());
                if (name != null) {
                    investorNames.add(name);
                }
            }
        }

        // 4. If list is not empty, block deletion and show names
        if (!investorNames.isEmpty()) {
            String namesJoined = investorNames.stream().distinct().collect(Collectors.joining(", "));

            throw new RuntimeException("Cannot delete! The following investors own "
                    + asset.getName() + ": [" + namesJoined + "]. They must sell first.");
        }

        // 5. Otherwise, delete is allowed
        assetRepository.deleteById(assetId);
    }
//    public void adminDeleteAssetGlobal(Integer assetId) {
//        Asset asset = assetRepository.findById(assetId)
//                .orElseThrow(() -> new RuntimeException("Asset not found"));
//
//        // 1. Check if ANY investor owns this asset name
//        long ownershipCount = assetRepository.countByName(asset.getName());
//
//        if (ownershipCount > 0) {
//            // 2. Block the deletion
//            throw new AssetInUseException(asset.getName(), ownershipCount);
//        }
//
//        // 3. Only delete if no one owns it
//        assetRepository.delete(asset);
//    }
    public List<Asset> getAllAssets() {
        return assetRepository.findAll();
    }

    // --- THE FIX: FILTER DUPLICATES FOR MARKET VIEW ---
    public List<Asset> getMarketAssets() {
        List<Asset> allAssets = assetRepository.findAll();

        // Use a Map to filter: Key = "ZOMATO", Value = Asset Object
        Map<String, Asset> uniqueMap = new HashMap<>();

        for (Asset a : allAssets) {
            if (a.getName() != null) {
                // TO TRIGGER YELLOW FAILURE: Remove .toUpperCase()
                // Result: Expected "GOLD", Actual "gold" (Comparison window will show case difference)
                String cleanName = a.getName().trim().toUpperCase();
                // Only add if we haven't seen this name yet
                if (!uniqueMap.containsKey(cleanName)) {
                    uniqueMap.put(cleanName, a);
                }
            }
        }
        // Return only the unique values
        return new ArrayList<>(uniqueMap.values());
    }

    public List<Asset> getAssetsByPortfolio(Integer portfolioId) {
        return assetRepository.findByPortfolioId(portfolioId);
    }

    // --- 2. BASIC WRITE OPERATIONS ---
    public void addAsset(Asset asset) {
        if(asset.getName() != null) asset.setName(asset.getName().trim());
        assetRepository.save(asset);
    }

    public void updateAsset(Asset asset) {
        if(asset.getName() != null) asset.setName(asset.getName().trim());
        assetRepository.save(asset);
    }

//    public void deleteAsset(Integer assetId) {
//        assetRepository.deleteById(assetId);
//    }

    // --- 3. TRADE LOGIC ---
    public void buyAsset(Integer portfolioId, String name, String type, Integer quantity, Double price) {
        String cleanName = name.trim();
        List<Asset> assets = assetRepository.findByPortfolioId(portfolioId);

        // Find existing asset in THIS portfolio
        Asset existing = assets.stream()
                .filter(a -> a.getName().equalsIgnoreCase(cleanName))
                .findFirst().orElse(null);

        if (existing != null) {
            // TO TRIGGER YELLOW FAILURE: Change the + to a -
            // Result: Expected 15, Actual 5 (Buying should increase quantity)
            int newQty = existing.getQuantity() + quantity;
            existing.setQuantity(newQty);
            assetRepository.save(existing);
        } else {
            Asset newAsset = new Asset();
            newAsset.setPortfolioId(portfolioId);
            newAsset.setName(cleanName);
            newAsset.setType(type);
            newAsset.setQuantity(quantity); // Quantity is Integer
            newAsset.setPrice(price);
            assetRepository.save(newAsset);
        }
    }

    public void sellAsset(Integer portfolioId, String name, Integer quantity) {
        List<Asset> assets = assetRepository.findByPortfolioId(portfolioId);
        Asset existing = assets.stream()
                .filter(a -> a.getName().equalsIgnoreCase(name.trim()))
                .findFirst().orElse(null);

        if (existing != null) {
            int currentQty = (existing.getQuantity() != null) ? existing.getQuantity() : 0;

            // TO TRIGGER YELLOW FAILURE: Comment out the subtraction and just set newQty = 0
            // Result: Expected 6, Actual 0
            int newQty = currentQty - quantity;

            if (newQty <= 0) {
                assetRepository.delete(existing);
            } else {
                existing.setQuantity(newQty);
                assetRepository.save(existing);
            }
        }
    }
}


//package com.example.demo.service;
//
//import com.example.demo.bean.Asset;
//import com.example.demo.repository.AssetRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//@Service
//public class AssetService {
//
//    @Autowired
//    private AssetRepository assetRepository;
//
//    // --- 1. READ OPERATIONS ---
//    public List<Asset> getAllAssets() {
//        return assetRepository.findAll();
//    }
//
//    // --- THE FIX: FILTER DUPLICATES FOR MARKET VIEW ---
//    public List<Asset> getMarketAssets() {
//        List<Asset> allAssets = assetRepository.findAll();
//
//        // Use a Map to filter: Key = "ZOMATO", Value = Asset Object
//        Map<String, Asset> uniqueMap = new HashMap<>();
//
//        for (Asset a : allAssets) {
//            if (a.getName() != null) {
//                String cleanName = a.getName().trim().toUpperCase();
//                // Only add if we haven't seen this name yet
//                if (!uniqueMap.containsKey(cleanName)) {
//                    uniqueMap.put(cleanName, a);
//                }
//            }
//        }
//        // Return only the unique values
//        return new ArrayList<>(uniqueMap.values());
//    }
//
//    public List<Asset> getAssetsByPortfolio(Integer portfolioId) {
//        return assetRepository.findByPortfolioId(portfolioId);
//    }
//
//    // --- 2. BASIC WRITE OPERATIONS ---
//    public void addAsset(Asset asset) {
//        if(asset.getName() != null) asset.setName(asset.getName().trim());
//        assetRepository.save(asset);
//    }
//
//    public void updateAsset(Asset asset) {
//        if(asset.getName() != null) asset.setName(asset.getName().trim());
//        assetRepository.save(asset);
//    }
//
//    public void deleteAsset(Integer assetId) {
//        assetRepository.deleteById(assetId);
//    }
//
//    // --- 3. TRADE LOGIC ---
//    public void buyAsset(Integer portfolioId, String name, String type, Integer quantity, Double price) {
//        String cleanName = name.trim();
//        List<Asset> assets = assetRepository.findByPortfolioId(portfolioId);
//
//        // Find existing asset in THIS portfolio
//        Asset existing = assets.stream()
//                .filter(a -> a.getName().equalsIgnoreCase(cleanName))
//                .findFirst().orElse(null);
//
//        if (existing != null) {
//            int newQty = existing.getQuantity() + quantity;
//            existing.setQuantity(newQty);
//            assetRepository.save(existing);
//        } else {
//            Asset newAsset = new Asset();
//            newAsset.setPortfolioId(portfolioId);
//            newAsset.setName(cleanName);
//            newAsset.setType(type);
//            newAsset.setQuantity(quantity); // Quantity is Integer
//            newAsset.setPrice(price);
//            assetRepository.save(newAsset);
//        }
//    }
//
//    public void sellAsset(Integer portfolioId, String name, Integer quantity) {
//        List<Asset> assets = assetRepository.findByPortfolioId(portfolioId);
//        Asset existing = assets.stream()
//                .filter(a -> a.getName().equalsIgnoreCase(name.trim()))
//                .findFirst().orElse(null);
//
//        if (existing != null) {
//            int currentQty = (existing.getQuantity() != null) ? existing.getQuantity() : 0;
//            int newQty = currentQty - quantity;
//
//            if (newQty <= 0) {
//                assetRepository.delete(existing);
//            } else {
//                existing.setQuantity(newQty);
//                assetRepository.save(existing);
//            }
//        }
//    }
//}