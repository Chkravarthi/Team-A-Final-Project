package com.example.demo.controller;

import com.example.demo.Exceptions.AssetInUseException;
import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import com.example.demo.repository.AssetRepository;
import com.example.demo.repository.TicketRepository;
import com.example.demo.service.AssetService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    @Autowired private AuthRepository authRepository;
    @Autowired private AssetRepository assetRepository;
    @Autowired private TicketRepository ticketRepository;
    @Autowired private AssetService assetService;

    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @GetMapping("/")
    public String home() { return "landing"; }

    // --- 1. LOGIN PAGE ---
    @GetMapping("/signin")
    public String showLogin(@RequestParam(required = false) String msg,
                            @RequestParam(required = false) String error,
                            Model model) {
        // Handle Success Messages coming from Redirects
        if ("advisor_wait".equals(msg)) {
            model.addAttribute("success", "Registration Successful! Please wait for Admin approval.");
        } else if ("registered".equals(msg)) {
            model.addAttribute("success", "Registration Successful! You may now login.");
        } else if ("logout".equals(msg)) {
            model.addAttribute("success", "You have been logged out.");
        }

        // Handle Errors
        if (error != null) {
            model.addAttribute("error", "Invalid Credentials");
        }
        return "signin";
    }

    // --- 2. SIGNUP PAGE ---
    @GetMapping("/signup")
    public String showSignup(@RequestParam(required = false) String error, Model model) {
        if (error != null) model.addAttribute("error", error);
        return "signup";
    }

    // --- 3. REGISTER ACTION ---
    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {

        // A. Sanitize Inputs
        String email = (user.getEmail() != null) ? user.getEmail().trim() : "";
        String username = (user.getUsername() != null) ? user.getUsername().trim() : "";
        user.setEmail(email);
        user.setUsername(username);

        // --- NEW: Backend Password Validation ---
        // Regex: At least one digit, one special char, 8+ length
        String passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$";

        if (!user.getPassword().matches(passwordPattern)) {
            model.addAttribute("error", "Password too weak. Use 8+ chars, numbers & symbols.");
            return "signup"; // Stop here and return to signup page
        }
        // ----------------------------------------

        // B. Validation: Check Duplicates
        if (authRepository.existsByEmail(email)) {
            model.addAttribute("error", "This email is already registered. Please login.");
            return "signup"; // Return to JSP to show error
        }

        if (authRepository.existsByUsername(username)) {
            model.addAttribute("error", "Username is already taken. Please choose another.");
            return "signup"; // Return to JSP to show error
        }

        // C. Encrypt Password
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // D. Set Status based on Role
        if ("ADVISOR".equals(user.getRole())) {
            user.setStatus("PENDING");
            authRepository.save(user);
            return "redirect:/signin?msg=advisor_wait"; // Special message for Advisors
        } else {
            user.setStatus("APPROVED");
            authRepository.save(user);
            return "redirect:/signin?msg=registered"; // Standard message
        }
    }

    // --- 4. LOGIN ACTION ---
    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {

        String input = email.trim();

        // Try Email first, then Username
        User user = authRepository.findByEmail(input).orElse(null);
        if (user == null) {
            user = authRepository.findByUsername(input);
        }

        if (user == null) {
            model.addAttribute("error", "User does not exist");
            return "signin";
        }

        if (passwordEncoder.matches(password, user.getPassword())) {
            // Check for Pending Status
            if ("PENDING".equalsIgnoreCase(user.getStatus())) {
                model.addAttribute("error", "Your account is pending Admin approval.");
                return "signin";
            }

            // Success
            session.setAttribute("userId", user.getUserId());
            session.setAttribute("userName", user.getUsername());
            session.setAttribute("role", user.getRole());
            return "redirect:/welcome";
        } else {
            model.addAttribute("error", "Invalid Credentials");
            return "signin";
        }
    }

    // --- 5. WELCOME DASHBOARD ---
    @GetMapping("/welcome")
    public String showWelcome(HttpSession session, Model model) {
        Integer userId = (Integer) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");

        if (userId == null) return "redirect:/signin";

        User currentUser = authRepository.findById(userId).orElse(null);
        if (currentUser == null) return "redirect:/logout";
        model.addAttribute("user", currentUser);

        if ("ADMIN".equals(role)) {
            model.addAttribute("allAdvisors", authRepository.findByRole("ADVISOR"));
            model.addAttribute("allInvestors", authRepository.findByRole("INVESTOR"));
            model.addAttribute("assetList", assetRepository.findAll());
            model.addAttribute("pendingAdvisors", authRepository.findByRoleAndStatus("ADVISOR", "PENDING"));
            model.addAttribute("openTickets", ticketRepository.findByStatus("OPEN"));
            model.addAttribute("resolvedTickets", ticketRepository.findByStatus("RESOLVED"));
        }
        else if ("INVESTOR".equals(role)) {
            model.addAttribute("advisorList", authRepository.findByRoleAndStatus("ADVISOR", "APPROVED"));
            if (currentUser.getAdvisorId() != null) {
                authRepository.findById(currentUser.getAdvisorId())
                        .ifPresent(adv -> model.addAttribute("advisorName", adv.getUsername()));
            }
            model.addAttribute("myTickets", ticketRepository.findByInvestorId(userId));
        }
        else if ("ADVISOR".equals(role)) {
            model.addAttribute("myClients", authRepository.findByAdvisorIdAndConnectionStatus(userId, "ACTIVE"));
            model.addAttribute("pendingRequests", authRepository.findByAdvisorIdAndConnectionStatus(userId, "PENDING"));
        }
        return "welcome";
    }

    // --- 6. ACTIONS ---
    @PostMapping("/connect-advisor")
    public String connect(@RequestParam Integer advisorId, HttpSession session) {
        Integer investorId = (Integer) session.getAttribute("userId");
        authRepository.findById(investorId).ifPresent(inv -> {
            inv.setAdvisorId(advisorId);
            inv.setConnectionStatus("PENDING");
            authRepository.save(inv);
        });
        return "redirect:/welcome?success=Sent";
    }

    @PostMapping("/advisor/accept")
    public String acceptClient(@RequestParam Integer investorId) {
        authRepository.findById(investorId).ifPresent(inv -> {
            inv.setConnectionStatus("ACTIVE");
            authRepository.save(inv);
        });
        return "redirect:/welcome?success=Accepted";
    }

    @PostMapping("/advisor/decline")
    public String declineClient(@RequestParam Integer investorId) {
        authRepository.findById(investorId).ifPresent(inv -> {
            inv.setAdvisorId(null);
            inv.setConnectionStatus(null);
            authRepository.save(inv);
        });
        return "redirect:/welcome?msg=Declined";
    }

    @PostMapping("/admin/approve-advisor")
    public String approveAdvisor(@RequestParam Integer advisorId) {
        authRepository.findById(advisorId).ifPresent(adv -> {
            adv.setStatus("APPROVED");
            authRepository.save(adv);
        });
        return "redirect:/welcome?success=AdvisorApproved";
    }

    @PostMapping("/admin/disconnect")
    public String disconnect(@RequestParam Integer investorId, HttpSession session) {
        if ("ADMIN".equals(session.getAttribute("role"))) {
            authRepository.findById(investorId).ifPresent(inv -> {
                inv.setAdvisorId(null);
                inv.setConnectionStatus(null);
                authRepository.save(inv);
            });
        }
        return "redirect:/welcome";
    }

    @PostMapping("/admin/asset/delete")
    public String deleteAsset(@RequestParam Integer assetId, RedirectAttributes redirectAttributes) {
        try {
            assetService.deleteAssetSafely(assetId);
            redirectAttributes.addFlashAttribute("successPopup", "Asset removed.");
        } catch (Exception e) {
            // e.getMessage() will now contain the list of names!
            redirectAttributes.addFlashAttribute("errorPopup", e.getMessage());
        }
        return "redirect:/assets";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/signin?msg=logout";
    }
}