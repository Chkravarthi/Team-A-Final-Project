package com.example.demo.service;

import com.example.demo.Exceptions.DuplicatePortfolioNameException;
import com.example.demo.Exceptions.PortfolioNotEmptyException;
import com.example.demo.bean.Asset;
import com.example.demo.bean.Portfolio;
import com.example.demo.repository.AssetRepository;
import com.example.demo.repository.PortfolioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PortfolioService {

    @Autowired private PortfolioRepository portfolioRepository;
    @Autowired private AssetRepository assetRepository;
    @Autowired private MarketService marketService; // Reuse existing Market Logic

    // --- CORE LOGIC: Calculate All Metrics ---
    public void calculateMetrics(Portfolio p) {
        List<Asset> assets = assetRepository.findByPortfolioId(p.getPortfolioId());
        double currentVal = 0.0;
        double investedVal = 0.0;

        for (Asset a : assets) {
            // 1. Calculate Invested Amount (Buy Price * Qty)
            // TO TRIGGER YELLOW FAILURE: Change * to +
            // Result: Expected 1000.0, Actual 110.0 (Difference window shows math error)
            if (a.getPrice() != null && a.getQuantity() != null) {
                investedVal += (a.getPrice() * a.getQuantity());
            }

            // 2. Calculate Live Market Value (Using MarketService or Simulation)
            // TO TRIGGER YELLOW FAILURE: Multiply by a wrong constant like * 2
            // Result: Expected 1200.0, Actual 2400.0
            double livePrice = marketService.getCurrentPrice(a.getName(), a.getPrice());
            currentVal += (livePrice * a.getQuantity());
        }

        // Set Values to Portfolio Object
        p.setLiveValue(currentVal);
        p.setInvestedAmount(investedVal);

        // 3. Progress towards Goal (Target)
        double target = (p.getTotalValue() != null) ? p.getTotalValue().doubleValue() : 0.0;
        if (target > 0) {
            double progress = (currentVal / target) * 100;
            // TO TRIGGER YELLOW FAILURE: Change the 100 cap to 0
            // Result: Expected 60.0, Actual 0.0
            p.setGrowthPct(progress > 100 ? 100 : progress); // Cap at 100% for bar
        }

        // 4. Profit/Loss Percentage
        if (investedVal > 0) {
            // TO TRIGGER YELLOW FAILURE: Remove the / investedVal
            // Result: Expected 20.0, Actual 20000.0
            double pl = ((currentVal - investedVal) / investedVal) * 100;
            p.setProfitLossPct(pl);
        } else {
            p.setProfitLossPct(0.0);
        }
    }
    // ... existing autowired fields ...
// @Autowired private AssetRepository assetRepository; <--- It is already here!

    public void deletePortfolioByAdmin(Integer portfolioId) {
        // 1. Check if the portfolio is empty
        // We reuse the same repository the user side uses
        List<Asset> holdings = assetRepository.findByPortfolioId(portfolioId);

        if (!holdings.isEmpty()) {
            // 2. Identify what is inside to tell the Admin
            String names = holdings.stream()
                    .map(Asset::getName)
                    .distinct()
                    .collect(Collectors.joining(", "));

            // 3. Throw the exception to block the Admin
            throw new RuntimeException("Admin Alert: Cannot delete this portfolio! It still contains: ["
                    + names + "]. Please ensure the user sells these assets before deletion.");
        }

        // to fial delete test add 1
        portfolioRepository.deleteById(portfolioId);
    }

    // --- CRUD Methods ---
//public void createPortfolio(Portfolio p) { portfolioRepository.save(p); }
    public void createPortfolio(Portfolio p) {
        // CORRECT: Calling portfolioRepository
        boolean nameExists = portfolioRepository.existsByInvestorIdAndPortfolioName(
                p.getInvestorId(), p.getPortfolioName());

        if (nameExists) {
            throw new DuplicatePortfolioNameException(p.getPortfolioName());
        }
        // to fail teh createportfolio test commet the below line
       portfolioRepository.save(p);
    }

    public void updatePortfolio(Portfolio p) { portfolioRepository.save(p); }
    public Portfolio getPortfolioById(Integer id) { return portfolioRepository.findById(id).orElse(null);}
//    public void deletePortfolio(Integer id) { portfolioRepository.deleteById(id); }


//    @Autowired private AssetRepository assetRepository;
//    @Autowired private PortfolioRepository portfolioRepository;

    public void deletePortfolio(Integer portfolioId) {
        // 1. Check DB: Does this portfolio have assets?
        boolean hasAssets = assetRepository.existsByPortfolioId(portfolioId);

        if (hasAssets) {
            // 2. Fetch the name for a better error message
            Portfolio p = portfolioRepository.findById(portfolioId).orElse(new Portfolio());
            // 3. Throw your NEW custom exception
            throw new PortfolioNotEmptyException(p.getPortfolioName());
        }

        portfolioRepository.deleteById(portfolioId);
    }
    public List<Portfolio> getAllPortfolios() { return portfolioRepository.findAll(); }

    // --- Fetch & Calculate Wrapper ---
    public List<Portfolio> getPortfoliosByInvestor(Integer investorId) {
        List<Portfolio> list = portfolioRepository.findByInvestorId(investorId);
        list.forEach(this::calculateMetrics); // Apply Math
        return list;
    }

    public List<Portfolio> getPortfoliosByAdvisor(Integer advisorId) {
        // Assuming you have a custom query for this in Repo, else filter manually
        return portfolioRepository.findAll(); // Placeholder
    }
}

//package com.example.demo.service;
//
//import com.example.demo.bean.Asset;
//import com.example.demo.bean.Portfolio;
//import com.example.demo.repository.AssetRepository;
//import com.example.demo.repository.PortfolioRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import java.util.List;
//
//@Service
//public class PortfolioService {
//
//    @Autowired private PortfolioRepository portfolioRepository;
//    @Autowired private AssetRepository assetRepository;
//    @Autowired private MarketService marketService; // Reuse existing Market Logic
//
//    // --- CORE LOGIC: Calculate All Metrics ---
//    public void calculateMetrics(Portfolio p) {
//        List<Asset> assets = assetRepository.findByPortfolioId(p.getPortfolioId());
//        double currentVal = 0.0;
//        double investedVal = 0.0;
//
//        for (Asset a : assets) {
//            // 1. Calculate Invested Amount (Buy Price * Qty)
//            if (a.getPrice() != null && a.getQuantity() != null) {
//                investedVal += (a.getPrice() * a.getQuantity());
//            }
//
//            // 2. Calculate Live Market Value (Using MarketService or Simulation)
//            double livePrice = marketService.getCurrentPrice(a.getName(), a.getPrice());
//            currentVal += (livePrice * a.getQuantity());
//        }
//
//        // Set Values to Portfolio Object
//        p.setLiveValue(currentVal);
//        p.setInvestedAmount(investedVal);
//
//        // 3. Progress towards Goal (Target)
//        double target = (p.getTotalValue() != null) ? p.getTotalValue().doubleValue() : 0.0;
//        if (target > 0) {
//            double progress = (currentVal / target) * 100;
//            p.setGrowthPct(progress > 100 ? 100 : progress); // Cap at 100% for bar
//        }
//
//        // 4. Profit/Loss Percentage
//        if (investedVal > 0) {
//            double pl = ((currentVal - investedVal) / investedVal) * 100;
//            p.setProfitLossPct(pl);
//        } else {
//            p.setProfitLossPct(0.0);
//        }
//    }
//
//    // --- CRUD Methods ---
//    public void createPortfolio(Portfolio p) { portfolioRepository.save(p); }
//    public void updatePortfolio(Portfolio p) { portfolioRepository.save(p); }
//    public Portfolio getPortfolioById(Integer id) { return portfolioRepository.findById(id).orElse(null); }
//    public void deletePortfolio(Integer id) { portfolioRepository.deleteById(id); }
//    public List<Portfolio> getAllPortfolios() { return portfolioRepository.findAll(); }
//
//    // --- Fetch & Calculate Wrapper ---
//    public List<Portfolio> getPortfoliosByInvestor(Integer investorId) {
//        List<Portfolio> list = portfolioRepository.findByInvestorId(investorId);
//        list.forEach(this::calculateMetrics); // Apply Math
//        return list;
//    }
//
//    public List<Portfolio> getPortfoliosByAdvisor(Integer advisorId) {
//        // Assuming you have a custom query for this in Repo, else filter manually
//        return portfolioRepository.findAll(); // Placeholder
//    }
//}