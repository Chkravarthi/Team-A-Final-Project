package com.example.demo.bean;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "transactions") // Matches your existing DB table name
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "transactionId") // Ensure DB has this column (or change to 'transaction_id')
    private Integer transactionId;

    // FIX: Explicitly map to standard DB naming (snake_case)
    @Column(name = "userId")
    private Integer userId;

    @Column(name = "assetName")
    private String assetName;

    @Column(name = "type")
    private String type;

    @Column(name = "quantity")
    private Integer quantity;

    @Column(name = "price")
    private Double price;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "transactionDate")
    private Date transactionDate;

    // --- Getters and Setters (No changes needed here) ---
    public Integer getTransactionId() { return transactionId; }
    public void setTransactionId(Integer transactionId) { this.transactionId = transactionId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getAssetName() { return assetName; }
    public void setAssetName(String assetName) { this.assetName = assetName; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public Date getTransactionDate() { return transactionDate; }
    public void setTransactionDate(Date transactionDate) { this.transactionDate = transactionDate; }
}