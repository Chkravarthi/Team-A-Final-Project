package com.example.demo.controller;

import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import com.example.demo.service.PortfolioService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminController {

    @Autowired
    private AuthRepository authRepository;

    // --- MANAGE ADVISOR VERIFICATION (Approve/Reject) ---
    @PostMapping("/admin/verify")
    public String verifyAdvisor(@RequestParam Integer userId, @RequestParam String action) {

        // 1. Find the User (Advisor)
        User user = authRepository.findById(userId).orElse(null);

        if (user != null) {
            if ("APPROVE".equalsIgnoreCase(action)) {
                // A. Approve: Change status so they can log in
                user.setStatus("APPROVED");
                authRepository.save(user);
            } else if ("REJECT".equalsIgnoreCase(action)) {
                // B. Reject: Delete the account (or you could set status to 'REJECTED')
                authRepository.delete(user);
            }
        }

        // 2. Redirect back to Welcome page
        return "redirect:/welcome?msg=VerificationUpdated";
    }
    @Autowired
    private PortfolioService portfolioService;
    @PostMapping("/admin/portfolio/delete")
    public String adminDeletePortfolio(@RequestParam("portfolioId") Integer portfolioId, RedirectAttributes ra, HttpServletRequest request) {
        // 1. Check your IDE Console for this message!
        System.out.println(">>> RECEIVED DELETE REQUEST FOR ID: " + portfolioId);

        try {
            if (portfolioId == null) {
                throw new RuntimeException("Error: Portfolio ID is null!");
            }

            // 2. Call the service
            portfolioService.deletePortfolioByAdmin(portfolioId);
            ra.addFlashAttribute("successMessage", "Portfolio deleted successfully.");

        } catch (Exception e) {
            System.out.println(">>> DELETE FAILED: " + e.getMessage());
            ra.addFlashAttribute("errorPopup", e.getMessage());
        }

        // 3. Return to the same page
        String referer = request.getHeader("Referer");
        return "redirect:" + (referer != null ? referer : "/portfolio");

    }
}