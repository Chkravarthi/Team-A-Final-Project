package com.example.demo.repository;

import com.example.demo.bean.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Integer> {
    // 1. For Admin: See all Open tickets
    List<Ticket> findByStatus(String status);

    // 2. For Investor: See my own ticket history
    List<Ticket> findByInvestorId(Integer investorId);
}