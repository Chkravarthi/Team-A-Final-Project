package com.example.demo.bean;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "Assets")
public class Asset {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer assetId;

    private Integer portfolioId;
    private String name;
    private String type; // STOCK, MF, GOLD
    private Integer quantity;
    private Double price; // The base price stored in DB

    // --- NEW: Transient Fields (Not saved to DB, just for display) ---
    @Transient
    private Double tempCurrentPrice; // Real-time market price

    @Transient
    private Double tempAvgBuyPrice;  // Your average buy price

    // --- Getters and Setters ---

    public Integer getAssetId() { return assetId; }
    public void setAssetId(Integer assetId) { this.assetId = assetId; }

    public Integer getPortfolioId() { return portfolioId; }
    public void setPortfolioId(Integer portfolioId) { this.portfolioId = portfolioId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    // --- NEW Getters/Setters for Transient Fields ---
    public Double getTempCurrentPrice() { return tempCurrentPrice; }
    public void setTempCurrentPrice(Double tempCurrentPrice) { this.tempCurrentPrice = tempCurrentPrice; }

    public Double getTempAvgBuyPrice() { return tempAvgBuyPrice; }
    public void setTempAvgBuyPrice(Double tempAvgBuyPrice) { this.tempAvgBuyPrice = tempAvgBuyPrice; }
}