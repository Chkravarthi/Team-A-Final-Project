package com.example.demo;

import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableScheduling
@SpringBootApplication
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	// --- ADDED SECTION: Auto-Create Default Admin ---
	@Bean
	public CommandLineRunner createDefaultAdmin(AuthRepository authRepository) {
		return args -> {
			// Check if 'admin' already exists to prevent duplicates or errors
			if (authRepository.findByUsername("admin") == null) {
				User admin = new User();
				admin.setUsername("admin");
				admin.setEmail("admin@growmore.com");

				// IMPORTANT: We must encrypt the password so the AuthController can verify it
				PasswordEncoder encoder = new BCryptPasswordEncoder();
				admin.setPassword(encoder.encode("admin@123"));

				admin.setRole("ADMIN");
				admin.setStatus("APPROVED");

				authRepository.save(admin);

				System.out.println("---------------------------------------------");
				System.out.println("✅ DEFAULT ADMIN CREATED: admin / admin@123");
				System.out.println("---------------------------------------------");
			}
		};
	}
}