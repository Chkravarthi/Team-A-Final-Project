package com.example.demo.controller;

import com.example.demo.bean.PerformanceReport;
import com.example.demo.bean.Portfolio;
import com.example.demo.bean.Transaction;
import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import com.example.demo.repository.PerformanceRepository;
import com.example.demo.service.AnalyticsService;
import com.example.demo.service.PortfolioService;
import com.example.demo.service.TransactionService; // Added Import
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class AnalyticsController {

    @Autowired private AnalyticsService analyticsService;
    @Autowired private PortfolioService portfolioService;
    @Autowired private AuthRepository authRepository;
    @Autowired private PerformanceRepository performanceRepository;
    @Autowired private TransactionService transactionService; // Added Injection

    @GetMapping("/analytics")
    public String showAnalytics(@RequestParam(required = false) Integer selectedPortfolioId,
                                @RequestParam(required = false) Integer viewInvestorId,
                                @RequestParam(required = false) Boolean viewMarket,
                                HttpSession session, Model model) {

        String role = (String) session.getAttribute("role");
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) return "redirect:/signin";

        // ADMIN VIEW
        if ("ADMIN".equals(role) && viewInvestorId == null) {
            List<User> allInvestors = authRepository.findByRole("INVESTOR");
            model.addAttribute("allInvestors", allInvestors);
            Map<Integer, String> advisorMap = new HashMap<>();
            for (User inv : allInvestors) {
                if (inv.getAdvisorId() != null) {
                    authRepository.findById(inv.getAdvisorId()).ifPresent(adv -> advisorMap.put(inv.getUserId(), adv.getUsername()));
                }
            }
            model.addAttribute("advisorMap", advisorMap);
            model.addAttribute("sysValues", new ArrayList<>(analyticsService.getSystemWideAllocation().values()));
            model.addAttribute("sysLabels", new ArrayList<>(analyticsService.getSystemWideAllocation().keySet()));
            model.addAttribute("topPortfolios", analyticsService.getTopPortfolios());
            return "analytics";
        }

        // ADVISOR VIEW
        if ("ADVISOR".equals(role)) {
            // Case A: Advisor wants to see Market Assets
            if (Boolean.TRUE.equals(viewMarket)) {
                model.addAttribute("marketView", true);
                List<String> allAssets = analyticsService.getAllMarketAssetNames();
                model.addAttribute("assetLabels", allAssets);
                List<Double> mockValues = new ArrayList<>();
                for(String s : allAssets) mockValues.add(100.0);
                model.addAttribute("assetValues", mockValues);
                return "analytics";
            }
            // Case B: Advisor Dashboard (Client List)
            if (viewInvestorId == null) {
                List<User> myClients = authRepository.findByAdvisorIdAndConnectionStatus(userId, "ACTIVE");
                model.addAttribute("myClients", myClients);
                return "analytics";
            }
        }

        // INDIVIDUAL VIEW
        Integer targetUserId = userId;
        if (viewInvestorId != null && ("ADMIN".equals(role) || "ADVISOR".equals(role))) {
            targetUserId = viewInvestorId;
            model.addAttribute("viewingUser", authRepository.findById(targetUserId).orElse(null));
        }
        model.addAttribute("targetUserId", targetUserId);

        List<Portfolio> portfolios = portfolioService.getPortfoliosByInvestor(targetUserId);
        model.addAttribute("portfolios", portfolios);

        if (selectedPortfolioId == null && !portfolios.isEmpty()) {
            selectedPortfolioId = portfolios.get(0).getPortfolioId();
        }

        if (selectedPortfolioId != null) {
            PerformanceReport report = analyticsService.generateReport(selectedPortfolioId);
            model.addAttribute("report", report);
            model.addAttribute("selectedId", selectedPortfolioId);

            Map<String, Double> allocation = analyticsService.getAssetAllocation(selectedPortfolioId);
            model.addAttribute("assetLabels", new ArrayList<>(allocation.keySet()));
            model.addAttribute("assetValues", new ArrayList<>(allocation.values()));
        } else {
            model.addAttribute("assetLabels", new ArrayList<String>());
            model.addAttribute("assetValues", new ArrayList<Double>());
        }

        model.addAttribute("myPerformance", analyticsService.getInvestorTotalPerformance(targetUserId));
        model.addAttribute("marketAvg", analyticsService.getWholeMarketAverage());

        return "analytics";
    }

    @GetMapping("/api/analytics/asset-live")
    @ResponseBody
    public Map<String, Object> getAssetLive(@RequestParam String assetName) {
        double currentPrice = analyticsService.getLiveAssetPrice(assetName);
        Map<String, Object> response = new HashMap<>();
        response.put("asset", assetName);
        response.put("price", currentPrice);
        response.put("timestamp", System.currentTimeMillis());
        return response;
    }

    // --- API 1: FILTER TABLE (Added) ---
    @GetMapping("/api/analytics/filter")
    @ResponseBody
    public List<Transaction> filterAnalytics(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam Integer viewInvestorId) {

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date start = sdf.parse(startDate);
            java.util.Date end = sdf.parse(endDate);
            end.setHours(23); end.setMinutes(59); end.setSeconds(59);

            return transactionService.getTransactionsByDateRange(viewInvestorId, start, end);
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // --- API 2: DOWNLOAD REPORT (Added) ---
    @GetMapping("/analytics/download")
    public void downloadCSV(
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam Integer viewInvestorId,
            HttpServletResponse response) {

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date start = sdf.parse(startDate);
            java.util.Date end = sdf.parse(endDate);
            end.setHours(23); end.setMinutes(59); end.setSeconds(59);

            List<Transaction> list = transactionService.getTransactionsByDateRange(viewInvestorId, start, end);

            response.setContentType("text/csv");
            response.setHeader("Content-Disposition", "attachment; filename=\"report_" + viewInvestorId + ".csv\"");

            PrintWriter writer = response.getWriter();
            writer.println("Transaction ID,Date,Type,Asset,Quantity,Price,Total Value");

            for (Transaction t : list) {
                double total = t.getPrice() * t.getQuantity();
                writer.printf("%d,%s,%s,%s,%d,%.2f,%.2f%n",
                        t.getTransactionId(),
                        t.getTransactionDate().toString(),
                        t.getType(),
                        t.getAssetName(),
                        t.getQuantity(),
                        t.getPrice(),
                        total);
            }
            writer.flush();
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}