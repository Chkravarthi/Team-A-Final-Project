package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                // Disable CSRF for simplicity (needed if you want GET logout)
                .csrf(csrf -> csrf.disable())

                // Allow all requests (JSPs, static resources, etc.)
                .authorizeHttpRequests(auth -> auth
                        .anyRequest().permitAll()
                )

                // Logout configuration
                .logout(logout -> logout
                        .logoutUrl("/logout")                 // GET /logout
                        .logoutSuccessUrl("/signin?logout")  // Redirect after logout
                        .invalidateHttpSession(true)         // Clear session
                        .deleteCookies("JSESSIONID")          // Remove cookie
                        .permitAll()
                );

        return http.build();
    }
}
