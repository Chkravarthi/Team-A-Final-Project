package com.example.demo.controller;

import com.example.demo.Exceptions.DuplicatePortfolioNameException;
import com.example.demo.Exceptions.PortfolioNotEmptyException;
import com.example.demo.bean.Portfolio;
import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import com.example.demo.service.AssetService;
import com.example.demo.service.MarketService;
import com.example.demo.service.PortfolioService;
import com.example.demo.service.TransactionService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid; // NEW IMPORT
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult; // NEW IMPORT
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PortfolioController {

    @Autowired private PortfolioService portfolioService;
    @Autowired private AuthRepository authRepository;
    @Autowired private AssetService assetService;
    @Autowired private MarketService marketService;
    @Autowired private TransactionService transactionService;

    // --- 1. SHOW PAGE ---
    @GetMapping("/portfolio")
    public String showPortfolio(
            @RequestParam(value = "investorId", required = false) Integer queryInvestorId,
            HttpSession session,
            Model model) {

        String role = (String) session.getAttribute("role");
        Integer myUserId = (Integer) session.getAttribute("userId");
        if (role == null) return "redirect:/signin";

        if ("INVESTOR".equals(role) || queryInvestorId != null) {
            Integer targetId = ("INVESTOR".equals(role)) ? myUserId : queryInvestorId;

            if ("ADVISOR".equals(role)) {
                User targetUser = authRepository.findById(targetId).orElse(null);
                if (targetUser == null || !myUserId.equals(targetUser.getAdvisorId())) {
                    return "redirect:/portfolio";
                }
            }

            List<Portfolio> portfolios = portfolioService.getPortfoliosByInvestor(targetId);
            portfolios.forEach(portfolioService::calculateMetrics);

            model.addAttribute("viewMode", "PORTFOLIO_LIST");
            model.addAttribute("portfolioList", portfolios);

            User u = authRepository.findById(targetId).orElse(new User());
            model.addAttribute("viewingName", u.getUsername());

            return "portfolio";
        }

        List<User> investorsToShow = new ArrayList<>();
        Map<Integer, Integer> portfolioCounts = new HashMap<>();

        if ("ADMIN".equals(role)) {
            investorsToShow = authRepository.findByRole("INVESTOR");
        } else if ("ADVISOR".equals(role)) {
            investorsToShow = authRepository.findByAdvisorId(myUserId);
        }

        for (User u : investorsToShow) {
            List<Portfolio> pList = portfolioService.getPortfoliosByInvestor(u.getId());
            portfolioCounts.put(u.getId(), pList.size());
        }

        model.addAttribute("viewMode", "INVESTOR_LIST");
        model.addAttribute("investorList", investorsToShow);
        model.addAttribute("portfolioCounts", portfolioCounts);

        return "portfolio";
    }

    // --- 2. API: PORTFOLIO LIVE UPDATES ---
    @GetMapping("/api/portfolio-updates")
    @ResponseBody
    public List<Map<String, Object>> getPortfolioUpdates(HttpSession session,
                                                         @RequestParam(value = "investorId", required = false) Integer queryInvestorId) {

        Integer myUserId = (Integer) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");
        if (myUserId == null) return new ArrayList<>();

        List<Portfolio> portfolios = new ArrayList<>();

        if ("INVESTOR".equals(role)) {
            portfolios = portfolioService.getPortfoliosByInvestor(myUserId);
        } else if (queryInvestorId != null) {
            portfolios = portfolioService.getPortfoliosByInvestor(queryInvestorId);
        }

        List<Map<String, Object>> updates = new ArrayList<>();
        for (Portfolio p : portfolios) {
            portfolioService.calculateMetrics(p);
            Map<String, Object> map = new HashMap<>();
            map.put("id", p.getPortfolioId());
            map.put("value", String.format("%.2f", p.getLiveValue()));
            map.put("progress", String.format("%.1f", p.getGrowthPct()));
            map.put("invested", String.format("%.2f", p.getInvestedAmount()));
            map.put("pl", p.getProfitLossPct());
            updates.add(map);
        }
        return updates;
    }

    // --- 3. CRUD ACTIONS ---

    @PostMapping("/portfolio/add")
    public String addPortfolio(@Valid @ModelAttribute("portfolio") Portfolio p,
                               BindingResult result,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {

        // Check for Bean Validation errors (e.g., negative totalValue)
        if (result.hasErrors()) {
            String errorMessage = result.getFieldError().getDefaultMessage();
            redirectAttributes.addFlashAttribute("errorPopup", errorMessage);
            return "redirect:/portfolio";
        }

        try {
            Integer userId = (Integer) session.getAttribute("userId");
            if (userId == null) return "redirect:/signin";

            p.setInvestorId(userId);
            portfolioService.createPortfolio(p);

            redirectAttributes.addFlashAttribute("successPopup", "Portfolio '" + p.getPortfolioName() + "' created successfully!");

        } catch (DuplicatePortfolioNameException ex) {
            redirectAttributes.addFlashAttribute("errorPopup", ex.getMessage());
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorPopup", "Error: " + ex.getMessage());
        }

        return "redirect:/portfolio";
    }

    @PostMapping("/portfolio/edit")
    public String editPortfolio(@Valid @ModelAttribute("portfolio") Portfolio p,
                                BindingResult result,
                                RedirectAttributes redirectAttributes) {

        // Check for validation errors during edit
        if (result.hasErrors()) {
            String errorMessage = result.getFieldError().getDefaultMessage();
            redirectAttributes.addFlashAttribute("errorPopup", "Edit Failed: " + errorMessage);
            return "redirect:/portfolio";
        }

        Portfolio existing = portfolioService.getPortfolioById(p.getPortfolioId());
        if (existing != null) {
            existing.setPortfolioName(p.getPortfolioName());
            existing.setTotalValue(p.getTotalValue());
            existing.setRiskLevel(p.getRiskLevel());
            portfolioService.updatePortfolio(existing);
            redirectAttributes.addFlashAttribute("successPopup", "Portfolio updated successfully!");
        }
        return "redirect:/portfolio";
    }

    @RequestMapping(value = "/portfolio/delete", method = {RequestMethod.GET, RequestMethod.POST})
    public String deletePortfolio(@RequestParam Integer portfolioId, RedirectAttributes redirectAttributes) {
        try {
            portfolioService.deletePortfolio(portfolioId);
            redirectAttributes.addFlashAttribute("successPopup", "Deleted successfully!");
        } catch (PortfolioNotEmptyException ex) {
            redirectAttributes.addFlashAttribute("errorPopup", ex.getMessage());
        }
        return "redirect:/portfolio";
    }
}