package com.example.demo.controller;

import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class UserManagementController {

    @Autowired
    private AuthRepository authRepository;

    @GetMapping("/manage-users")
    public String showUserManagement(HttpSession session, Model model) {
        String role = (String) session.getAttribute("role");
        Integer myId = (Integer) session.getAttribute("userId");

        if ("ADVISOR".equals(role)) {
            // 1. Fetch Active Clients (Can see portfolio)
            List<User> activeClients = authRepository.findByAdvisorIdAndConnectionStatus(myId, "ACTIVE");

            // 2. Fetch Pending Requests (Cannot see portfolio yet)
            List<User> pendingRequests = authRepository.findByAdvisorIdAndConnectionStatus(myId, "PENDING");

            model.addAttribute("activeClients", activeClients);
            model.addAttribute("pendingRequests", pendingRequests);

            return "manage-users";
        }

        // ... (Keep Admin logic here if needed) ...
        return "redirect:/welcome";
    }

    // --- NEW: HANDLE ACCEPT / REJECT ---
    @PostMapping("/advisor/action")
    public String handleRequest(@RequestParam("clientId") Integer clientId,
                                @RequestParam("action") String action) {

        User client = authRepository.findById(clientId).orElse(null);

        if (client != null) {
            if ("ACCEPT".equals(action)) {
                client.setConnectionStatus("ACTIVE"); // Access Granted
            } else if ("REJECT".equals(action)) {
                client.setAdvisorId(null);       // Remove Link
                client.setConnectionStatus(null);
            }
            authRepository.save(client);
        }
        return "redirect:/manage-users";
    }
}