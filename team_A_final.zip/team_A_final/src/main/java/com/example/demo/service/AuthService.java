package com.example.demo.service;

import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder; // 1. Import
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private AuthRepository authRepository;

    @Autowired
    private PasswordEncoder passwordEncoder; // 2. Inject Encoder

    // --- REGISTER (Handles Hashing & Roles) ---
    public User registerUser(User user) throws Exception {
        if (authRepository.existsByEmail(user.getEmail())) {
            throw new Exception("Email already exists!");
        }

        // A. Hash the password
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);

        // B. Handle Advisor Logic
        if ("ADVISOR".equals(user.getRole())) {
            user.setStatus("PENDING");
        } else {
            user.setStatus("APPROVED");
        }

        return authRepository.save(user);
    }

    // --- LOGIN (Handles Verification) ---
    public User loginUser(String email, String password) throws Exception {
        Optional<User> userOpt = authRepository.findByEmail(email);

        if (userOpt.isPresent()) {
            User user = userOpt.get();

            // C. Compare Raw Password vs Hashed Password
            if (passwordEncoder.matches(password, user.getPassword())) {
                return user;
            } else {
                throw new Exception("Invalid Password"); // Generic error is safer
            }
        } else {
            throw new Exception("User not found");
        }
    }
}