package com.example.demo.repository;

import com.example.demo.bean.Portfolio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PortfolioRepository extends JpaRepository<Portfolio, Integer> {

    // 1. Find by Investor ID (For Investors to see their own data)
    List<Portfolio> findByInvestorId(Integer investorId);

    // 2. Find by Advisor ID (Fixed Field Name)
    // CHANGE: "u.userId" -> "u.id"
    // JPQL looks for the field 'private Integer id' inside your User.java
    @Query("SELECT p FROM Portfolio p WHERE p.investorId IN " +
            "(SELECT u.id FROM User u WHERE u.advisorId = :advisorId AND u.connectionStatus = 'ACTIVE')")
    List<Portfolio> findByInvestor_AdvisorId(@Param("advisorId") Integer advisorId);
    boolean existsByInvestorIdAndPortfolioName(Integer investorId, String portfolioName);

}