package com.example.demo.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class PortfolioNotEmptyException extends RuntimeException {

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }

    public PortfolioNotEmptyException(String portfolioName) {
        super(String.format("The portfolio '%s' cannot be deleted because it still contains assets. Please sell or remove all assets first.", portfolioName));
    }
}

