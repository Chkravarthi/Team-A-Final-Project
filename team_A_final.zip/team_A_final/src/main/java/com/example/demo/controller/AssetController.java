package com.example.demo.controller;

import com.example.demo.bean.Asset;
import com.example.demo.bean.Portfolio;
import com.example.demo.service.AssetService;
import com.example.demo.service.MarketService;
import com.example.demo.service.PortfolioService;
import com.example.demo.service.TransactionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // Added for popups

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class AssetController {

    @Autowired private AssetService assetService;
    @Autowired private PortfolioService portfolioService;
    @Autowired private TransactionService transactionService;
    @Autowired private MarketService marketService;

    // --- 1. SHOW ASSETS PAGE (Unchanged) ---
    @GetMapping("/assets")
    public String showAssets(@RequestParam(required = false) Integer portfolioId,
                             @RequestParam(required = false) Integer investorId,
                             HttpSession session, Model model) {

        Integer loggedInUserId = (Integer) session.getAttribute("userId");
        if (loggedInUserId == null) return "redirect:/signin";

        List<Asset> assetsToDisplay;
        String viewingMode = "MARKET_VIEW";

        if (portfolioId != null) {
            assetsToDisplay = assetService.getAssetsByPortfolio(portfolioId);
            viewingMode = "PORTFOLIO_VIEW";
            model.addAttribute("selectedPortfolioId", portfolioId);

            for (Asset a : assetsToDisplay) {
                double avgBuy = transactionService.calculateAvgBuyPrice(loggedInUserId, a.getName());
                if (avgBuy == 0.0) avgBuy = a.getPrice();
                a.setTempAvgBuyPrice(avgBuy);
            }
        } else if (investorId != null) {
            List<Portfolio> portfolios = portfolioService.getPortfoliosByInvestor(investorId);
            if (!portfolios.isEmpty()) {
                assetsToDisplay = assetService.getAssetsByPortfolio(portfolios.get(0).getPortfolioId());
                viewingMode = "CLIENT_VIEW";
            } else {
                assetsToDisplay = new ArrayList<>();
            }
        } else {
            assetsToDisplay = assetService.getMarketAssets();
        }

        if (assetsToDisplay != null) {
            for (Asset a : assetsToDisplay) {
                a.setTempCurrentPrice(marketService.getCurrentPrice(a.getName(), a.getPrice()));
            }
            model.addAttribute("assetList", assetsToDisplay);
        }

        model.addAttribute("viewingMode", viewingMode);
        model.addAttribute("userPortfolios", portfolioService.getPortfoliosByInvestor(loggedInUserId));
        return "assets";
    }

    // --- 2. API: LIVE UPDATES (Unchanged) ---
    @GetMapping("/api/asset-updates")
    @ResponseBody
    public List<Map<String, Object>> getAssetUpdates(@RequestParam(required = false) Integer portfolioId) {

        List<Asset> assets;
        if (portfolioId != null) {
            assets = assetService.getAssetsByPortfolio(portfolioId);
        } else {
            assets = assetService.getMarketAssets();
        }

        List<Map<String, Object>> updates = new ArrayList<>();

        for (Asset a : assets) {
            double basePrice = marketService.getCurrentPrice(a.getName(), a.getPrice());
            double change = (Math.random() * 20) - 10;
            double livePrice = basePrice + change;

            if(livePrice < 1.0) livePrice = 1.0;

            Map<String, Object> map = new HashMap<>();
            map.put("assetId", a.getAssetId());
            map.put("livePrice", String.format("%.2f", livePrice));

            if (portfolioId != null) {
                double quantity = a.getQuantity();
                double currentValue = livePrice * quantity;

                double avgBuyPrice = transactionService.calculateAvgBuyPrice(portfolioId, a.getName());
                if(avgBuyPrice == 0) avgBuyPrice = a.getPrice();

                double invested = avgBuyPrice * quantity;
                double pl = currentValue - invested;
                double plPct = 0.0;
                if(invested > 0) plPct = (pl / invested) * 100;

                map.put("currentValue", String.format("%.2f", currentValue));
                map.put("pl", String.format("%.2f", pl));
                map.put("plPct", String.format("%.2f", plPct));
            }
            updates.add(map);
        }
        return updates;
    }

    // --- 3. TRADE ACTIONS (Added Validation) ---
    @PostMapping("/asset/trade")
    public String executeTrade(@RequestParam String action, @RequestParam String name,
                               @RequestParam Integer quantity, @RequestParam Double price,
                               @RequestParam Integer targetPortfolioId, HttpSession session,
                               RedirectAttributes redirectAttributes) {
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) return "redirect:/signin";

        // NEW: Validation for negative quantity or price
        if (quantity <= 0 || price <= 0) {
            redirectAttributes.addFlashAttribute("errorPopup", "Quantity and Price must be positive values.");
            return "redirect:/assets?portfolioId=" + targetPortfolioId;
        }

        try {
            if ("BUY".equalsIgnoreCase(action)) {
                assetService.buyAsset(targetPortfolioId, name, "STOCK", quantity, price);
                transactionService.record(userId, "BUY", name, quantity, price);
            } else {
                List<Asset> owned = assetService.getAssetsByPortfolio(targetPortfolioId);
                boolean canSell = owned.stream().anyMatch(a -> a.getName().equalsIgnoreCase(name) && a.getQuantity() >= quantity);
                if (!canSell) {
                    redirectAttributes.addFlashAttribute("errorPopup", "Insufficient quantity to sell.");
                    return "redirect:/assets?portfolioId=" + targetPortfolioId;
                }
                assetService.sellAsset(targetPortfolioId, name, quantity);
                transactionService.record(userId, "SELL", name, quantity, price);
            }
            redirectAttributes.addFlashAttribute("successPopup", "Trade executed successfully!");
            return "redirect:/assets?portfolioId=" + targetPortfolioId;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorPopup", "Transaction Failed: " + e.getMessage());
            return "redirect:/assets?portfolioId=" + targetPortfolioId;
        }
    }

    // --- 4. ADMIN ACTIONS (Added Validation) ---
    @PostMapping("/admin/asset/manage")
    public String manageAsset(@ModelAttribute Asset asset, @RequestParam String operation,
                              RedirectAttributes redirectAttributes) {

        // NEW: Validation for Admin Create/Update
        if ("CREATE".equals(operation) || "UPDATE".equals(operation)) {
            if (asset.getPrice() == null || asset.getPrice() <= 0) {
                redirectAttributes.addFlashAttribute("errorPopup", "Asset price must be a positive value.");
                return "redirect:/assets";
            }
        }

        try {
            if ("CREATE".equals(operation)) {
                asset.setPortfolioId(null);
                assetService.addAsset(asset);
                redirectAttributes.addFlashAttribute("successPopup", "New asset added to market.");
            } else if ("UPDATE".equals(operation)) {
                assetService.updateAsset(asset);
                redirectAttributes.addFlashAttribute("successPopup", "Asset updated successfully.");
            } else if ("DELETE".equals(operation)) {
                assetService.deleteAssetSafely(asset.getAssetId());
                redirectAttributes.addFlashAttribute("successPopup", "Asset removed from market.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorPopup", "Operation Failed: " + e.getMessage());
        }

        return "redirect:/assets";
    }
}