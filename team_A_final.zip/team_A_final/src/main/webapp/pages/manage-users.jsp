<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Manage Users | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Branding Variables --- */
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
            --bg-light: #f4fcfb;
            --glass-bg: rgba(255, 255, 255, 0.95);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--color-secondary);
        }

        /* --- Navbar --- */
        .navbar-custom {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 15px 0;
        }
        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            color: var(--color-secondary) !important;
            letter-spacing: -0.5px;
        }
        .logo-icon { color: var(--color-primary); }

        .nav-link-custom {
            color: #64748b;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            text-decoration: none;
            font-size: 0.95rem;
        }
        .nav-link-custom:hover { color: var(--color-primary); background: rgba(0, 208, 156, 0.05); }

        /* --- Cards --- */
        .card-custom {
            border: none;
            border-radius: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            background: #fff;
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        /* --- Admin Table Styles --- */
        .table-custom thead th {
            background: #f8fafc;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #64748b;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px;
        }
        .table-custom td {
            vertical-align: middle;
            padding: 16px;
            color: var(--color-secondary);
            font-weight: 500;
        }

        /* --- Advisor/User Cards --- */
        .user-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.03);
            background: white;
            padding: 24px;
            text-align: center;
            height: 100%;
            transition: 0.3s;
        }
        .user-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.08); }

        .avatar-circle {
            width: 50px; height: 50px; border-radius: 50%;
            background: #f0fdf9; color: var(--color-primary); font-weight: 700; font-size: 1.2rem;
            display: flex; align-items: center; justify-content: center;
        }

        /* --- Buttons & Badges --- */
        .btn-outline-dark { border-radius: 50px; font-weight: 600; padding: 6px 16px; font-size: 0.9rem; }
        .btn-brand {
            background: var(--color-primary); color: white; border: none; font-weight: 600;
            border-radius: 50px; padding: 8px 20px; transition: 0.2s;
        }
        .btn-brand:hover { background: var(--color-primary-dark); transform: translateY(-2px); }

        /* --- Modal --- */
        .modal-content { border-radius: 24px; border: none; padding: 10px; }
        .modal-header { border-bottom: 1px solid #f1f5f9; padding-bottom: 15px; }

        .list-group-item { border: none; border-bottom: 1px solid #f1f5f9; }
        .list-group-item:last-child { border-bottom: none; }
    </style>
</head>
<body>

    <nav class="navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a class="navbar-brand me-5" href="welcome">
                    <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
                </a>
                <div class="d-none d-lg-flex gap-2">
                    <a href="welcome" class="nav-link-custom"><i class="fa-solid fa-arrow-left me-1"></i> Dashboard</a>
                    <span class="nav-link-custom text-dark fw-bold" style="cursor: default;">
                        <i class="fa-solid fa-users-gear me-1"></i> Manage Users
                    </span>
                </div>
            </div>

            <div class="dropdown">
                <div class="bg-white border rounded-pill px-3 py-1 shadow-sm d-flex align-items-center" style="cursor: pointer;" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=${sessionScope.userName}&background=00d09c&color=fff" class="rounded-circle me-2" width="32">
                    <span class="small fw-bold text-dark">${sessionScope.userName}</span>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 p-2 rounded-4">
                    <li class="dropdown-item small text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">${sessionScope.role} View</li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger fw-bold rounded-3" href="logout"><i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">

        <c:if test="${sessionScope.role == 'ADMIN'}">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1 text-dark">System Administration</h3>
                    <p class="text-muted small">Manage Advisors and their assigned clients.</p>
                </div>
            </div>

            <div class="card-custom mb-5">
                <div class="card-header bg-white py-3 border-bottom">
                    <h5 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-user-tie me-2 text-primary"></i>Advisors List</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-custom table-hover mb-0 align-middle">
                            <thead>
                                <tr>
                                    <th class="ps-4">Advisor Name</th>
                                    <th>Email</th>
                                    <th class="text-end pe-4">Assigned Clients</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="adv" items="${advisorList}">
                                    <tr>
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle me-3 text-uppercase">${adv.username.charAt(0)}</div>
                                                <span class="fw-bold text-dark">${adv.username}</span>
                                            </div>
                                        </td>
                                        <td class="text-muted">${adv.email}</td>
                                        <td class="text-end pe-4">
                                            <button class="btn btn-sm btn-outline-dark shadow-sm"
                                                    onclick="showAdvisorClients('${adv.userId}', '${adv.username}')">
                                                <i class="fa-solid fa-users-viewfinder me-1"></i> View Investors
                                            </button>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div id="investorDataStore" style="display:none;">
                <c:forEach var="inv" items="${investorList}">
                    <span data-advisor-id="${inv.advisorId}"
                          data-name="${inv.username}"
                          data-email="${inv.email}"
                          data-status="${inv.connectionStatus}"></span>
                </c:forEach>
            </div>

            <div class="modal fade" id="adminModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold">Clients: <span id="modalAdvisorName" class="text-primary"></span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body p-0">
                            <ul class="list-group list-group-flush" id="modalClientList">
                                </ul>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button type="button" class="btn btn-sm btn-light border fw-bold rounded-pill px-3" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

        </c:if>

        <c:if test="${sessionScope.role == 'ADVISOR'}">

            <c:if test="${not empty pendingRequests}">
                <div class="card-custom mb-5 border border-warning bg-warning-subtle">
                    <div class="p-4">
                        <h5 class="fw-bold text-warning-emphasis mb-3">
                            <i class="fa-solid fa-bell me-2"></i> New Connection Requests
                        </h5>
                        <div class="row g-3">
                            <c:forEach var="req" items="${pendingRequests}">
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center justify-content-between p-3 rounded-4 bg-white shadow-sm">
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-light d-flex align-items-center justify-content-center me-3" style="width:45px; height:45px;">
                                                <i class="fa-solid fa-user text-muted"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-bold text-dark">${req.username}</h6>
                                                <small class="text-muted">Requesting Access</small>
                                            </div>
                                        </div>
                                        <div>
                                            <form action="advisor/action" method="post" class="d-flex gap-2">
                                                <input type="hidden" name="clientId" value="${req.userId}">
                                                <button type="submit" name="action" value="ACCEPT" class="btn btn-sm btn-brand shadow-sm">Accept</button>
                                                <button type="submit" name="action" value="REJECT" class="btn btn-sm btn-light border text-danger fw-bold shadow-sm">Decline</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </c:forEach>
                        </div>
                    </div>
                </div>
            </c:if>

            <h4 class="fw-bold mb-4">Your Active Clients</h4>
            <div class="row g-4">
                <c:forEach var="client" items="${activeClients}">
                    <div class="col-md-4 col-lg-3">
                        <div class="user-card">
                            <img src="https://ui-avatars.com/api/?name=${client.username}&background=random&color=fff" class="rounded-circle mb-3 shadow-sm" width="65">
                            <h5 class="fw-bold text-dark mb-1">${client.username}</h5>
                            <p class="text-muted small mb-3">${client.email}</p>

                            <div class="d-grid gap-2">
                                <a href="mailto:${client.email}" class="btn btn-light border btn-sm rounded-pill fw-bold">
                                    <i class="fa-regular fa-envelope me-1"></i> Email
                                </a>
                                <a href="portfolio?investorId=${client.userId}" class="btn btn-brand btn-sm shadow-sm">
                                    Portfolio
                                </a>
                            </div>
                        </div>
                    </div>
                </c:forEach>

                <c:if test="${empty activeClients}">
                    <div class="col-12 text-center text-muted py-5">
                        <i class="fa-solid fa-users fs-1 d-block mb-3 opacity-25"></i>
                        <h5 class="fw-bold text-muted">No active clients yet</h5>
                        <p class="small">Accept requests to see them here.</p>
                    </div>
                </c:if>
            </div>
        </c:if>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function showAdvisorClients(advisorId, advisorName) {
            // 1. Set Title
            document.getElementById('modalAdvisorName').innerText = advisorName;

            // 2. Clear List
            const listContainer = document.getElementById('modalClientList');
            listContainer.innerHTML = '';

            // 3. Find Investors
            const allInvestors = document.querySelectorAll('#investorDataStore span');
            let foundCount = 0;

            allInvestors.forEach(inv => {
                if (inv.getAttribute('data-advisor-id') === advisorId) {
                    foundCount++;

                    let statusBadge = '';
                    let status = inv.getAttribute('data-status');

                    if(status === 'ACTIVE') {
                        statusBadge = '<span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3">Active</span>';
                    } else if (status === 'PENDING') {
                        statusBadge = '<span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle rounded-pill px-3">Pending</span>';
                    } else {
                        statusBadge = '<span class="badge bg-light text-muted border rounded-pill px-3">Assigned</span>';
                    }

                    const li = document.createElement('li');
                    li.className = 'list-group-item d-flex justify-content-between align-items-center px-4 py-3';
                    li.innerHTML = `
                        <div class="d-flex align-items-center">
                            <div class="bg-light rounded-circle p-2 me-3"><i class="fa-solid fa-user text-secondary"></i></div>
                            <div>
                                <div class="fw-bold text-dark">` + inv.getAttribute('data-name') + `</div>
                                <div class="small text-muted">` + inv.getAttribute('data-email') + `</div>
                            </div>
                        </div>
                        ` + statusBadge + `
                    `;
                    listContainer.appendChild(li);
                }
            });

            // 4. Empty State
            if (foundCount === 0) {
                listContainer.innerHTML = `
                    <li class="list-group-item text-center text-muted py-5">
                        <i class="fa-solid fa-folder-open fs-2 opacity-25 mb-2 d-block"></i>
                        No investors assigned yet.
                    </li>`;
            }

            // 5. Show Modal
            var myModal = new bootstrap.Modal(document.getElementById('adminModal'));
            myModal.show();
        }
    </script>
</body>
</html>