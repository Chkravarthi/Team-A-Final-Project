<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Transactions | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Branding Variables --- */
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
            --bg-light: #f4fcfb;
            --glass-bg: rgba(255, 255, 255, 0.95);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--color-secondary);
        }

        /* --- Navbar --- */
        .navbar-custom {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 15px 0;
        }
        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            color: var(--color-secondary) !important;
            letter-spacing: -0.5px;
        }
        .logo-icon { color: var(--color-primary); }

        .nav-link-custom {
            color: #64748b;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            text-decoration: none;
            font-size: 0.95rem;
        }
        .nav-link-custom:hover { color: var(--color-primary); background: rgba(0, 208, 156, 0.05); }
        .nav-link-custom.active {
            background-color: var(--color-primary);
            color: white;
            box-shadow: 0 4px 12px rgba(0, 208, 156, 0.3);
        }

        /* --- Transaction Table Card --- */
        .table-card {
            background: white;
            border-radius: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            overflow: hidden;
            border: none;
        }
        .table th {
            background-color: #f8fafc;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 18px;
            border-bottom: 1px solid #e2e8f0;
            color: #64748b;
        }
        .table td {
            padding: 18px;
            vertical-align: middle;
            font-weight: 500;
            color: var(--color-secondary);
            border-bottom: 1px solid #f1f5f9;
        }
        .detail-row:hover { background-color: #f1f5f9; cursor: pointer; }

        /* --- Investor Cards (Admin View) --- */
        .investor-card {
            background: #fff;
            border: none;
            border-radius: 20px;
            padding: 24px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            height: 100%;
            box-shadow: 0 4px 20px rgba(0,0,0,0.04);
        }
        .investor-card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(0,0,0,0.08); }

        /* --- Badges --- */
        .badge-buy { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .badge-sell { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

        /* --- Buttons --- */
        .btn-brand {
            background: var(--color-primary);
            color: white;
            border: none;
            font-weight: 600;
            border-radius: 50px;
            padding: 10px 24px;
            transition: all 0.2s;
        }
        .btn-brand:hover { background: var(--color-primary-dark); color: white; transform: translateY(-2px); }

        .btn-icon {
            width: 36px; height: 36px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            background: #f8fafc;
            color: #64748b;
            transition: 0.2s;
            border: 1px solid #e2e8f0;
        }
        .btn-icon:hover { background: var(--color-primary); color: white; border-color: var(--color-primary); }

        /* --- Modals --- */
        .modal-content { border-radius: 24px; border: none; padding: 10px; }
        .receipt-header { background: #f8fafc; border-radius: 16px; padding: 20px; text-align: center; }

        .user-link { color: var(--color-primary); font-weight: 600; text-decoration: none; }
        .user-link:hover { text-decoration: underline; color: var(--color-primary-dark); }
    </style>
</head>
<body>

    <nav class="navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a class="navbar-brand me-5" href="welcome">
                    <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
                </a>
                <div class="d-none d-lg-flex gap-2">
                    <a href="welcome" class="nav-link-custom"><i class="fa-solid fa-house me-1"></i> Dashboard</a>
                    <a href="portfolio" class="nav-link-custom"><i class="fa-solid fa-briefcase me-1"></i> Portfolio</a>
                    <a href="assets" class="nav-link-custom"><i class="fa-solid fa-coins me-1"></i> Assets</a>

                    <c:if test="${sessionScope.role != 'ADVISOR'}">
                        <a href="transaction" class="nav-link-custom active"><i class="fa-solid fa-right-left me-1"></i> Transactions</a>
                    </c:if>

                    <a href="analytics" class="nav-link-custom"><i class="fa-solid fa-chart-pie me-1"></i> Analytics</a>
                </div>
            </div>

            <div class="dropdown">
                <div class="bg-white border rounded-pill px-3 py-1 shadow-sm d-flex align-items-center" style="cursor: pointer;" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=${sessionScope.userName}&background=00d09c&color=fff" class="rounded-circle me-2" width="32">
                    <span class="small fw-bold text-dark">${sessionScope.userName}</span>
                    <i class="fa-solid fa-chevron-down ms-2 text-muted" style="font-size: 0.7rem;"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 p-2 rounded-4">
                    <li class="dropdown-item small text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">${sessionScope.role} Account</li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger fw-bold rounded-3" href="logout"><i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">

        <%-- VIEW 1: USER LIST (For Admin/Advisor) --%>
        <c:if test="${viewMode == 'USER_LIST'}">
            <div class="mb-5">
                <h2 class="fw-bold text-dark">Client History</h2>
                <p class="text-muted">Select an investor to view their transaction logs.</p>
            </div>

            <div class="row g-4">
                <c:forEach var="inv" items="${investorList}">
                    <div class="col-md-4 col-lg-3">
                        <div class="investor-card" onclick="window.location.href='transaction?viewUserId=${inv.userId}'">
                            <img src="https://ui-avatars.com/api/?name=${inv.username}&size=80&background=random&color=fff" class="rounded-circle mb-3 shadow-sm">
                            <h5 class="fw-bold mb-1 text-dark">${inv.username}</h5>
                            <p class="text-muted small mb-0">${inv.email}</p>
                            <div class="mt-3">
                                <span class="badge bg-light text-muted border rounded-pill">ID: #${inv.userId}</span>
                            </div>
                        </div>
                    </div>
                </c:forEach>
                <c:if test="${empty investorList}">
                    <div class="col-12 text-center py-5">
                        <i class="fa-solid fa-user-slash fs-1 text-muted opacity-25 mb-3"></i>
                        <h5 class="text-muted">No investors found.</h5>
                    </div>
                </c:if>
            </div>
        </c:if>

        <%-- VIEW 2: HISTORY TABLE --%>
        <c:if test="${viewMode == 'HISTORY_TABLE'}">

            <div class="d-flex justify-content-between align-items-center mb-5">
                <div>
                    <h2 class="fw-bold">
                        <c:choose>
                            <c:when test="${not empty selectedUser}"><span style="color:var(--color-primary)">${selectedUser.username}'s</span> History</c:when>
                            <c:otherwise>Transaction History</c:otherwise>
                        </c:choose>
                    </h2>
                    <p class="text-muted">
                        <c:choose>
                            <c:when test="${sessionScope.role == 'ADMIN'}">Viewing specific investor records.</c:when>
                            <c:otherwise>Track your recent investment activities.</c:otherwise>
                        </c:choose>
                    </p>
                </div>

                <c:if test="${sessionScope.role == 'ADMIN'}">
                    <a href="transaction" class="btn btn-light border rounded-pill fw-bold px-3">
                        <i class="fa-solid fa-arrow-left me-2"></i> Back to Users
                    </a>
                </c:if>
            </div>

            <div class="table-card shadow-sm">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Date</th>
                            <c:if test="${sessionScope.role != 'INVESTOR'}">
                                <th>Investor</th>
                            </c:if>
                            <th>Asset</th>
                            <th>Type</th>
                            <th class="text-end">Quantity</th>
                            <th class="text-end">Unit Price</th>
                            <th class="text-end">Total</th>
                            <th class="text-center pe-4">Receipt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="t" items="${transactionList}">
                            <tr class="detail-row">
                                <td class="ps-4 text-muted small"><fmt:formatDate value="${t.transactionDate}" pattern="MMM dd, yyyy"/></td>

                                <c:if test="${sessionScope.role != 'INVESTOR'}">
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty userMap[t.userId]}">
                                                <span class="user-link" onclick="openHistoryModal('${t.userId}', '${userMap[t.userId].username}')">
                                                    <i class="fa-solid fa-circle-user me-1"></i> ${userMap[t.userId].username}
                                                </span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="text-muted small">User #${t.userId}</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                </c:if>

                                <td class="fw-bold text-dark">${t.assetName}</td>
                                <td>
                                    <span class="badge rounded-pill px-3 py-2 ${t.type == 'BUY' ? 'badge-buy' : 'badge-sell'}">
                                        ${t.type}
                                    </span>
                                </td>
                                <td class="text-end">${t.quantity}</td>
                                <td class="text-end text-muted">₹<fmt:formatNumber value="${t.price}" minFractionDigits="2"/></td>
                                <td class="text-end fw-bold text-dark">₹<fmt:formatNumber value="${t.quantity * t.price}" minFractionDigits="2"/></td>

                                <td class="text-center pe-4">
                                    <button class="btn btn-icon mx-auto shadow-sm"
                                            onclick="showDetails('${t.transactionId}', '${t.assetName}', '${t.type}', '${t.quantity}', '${t.price}')">
                                        <i class="fa-solid fa-receipt"></i>
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>

                        <c:if test="${empty transactionList}">
                            <tr><td colspan="8" class="text-center py-5">
                                <i class="fa-solid fa-file-invoice fs-1 text-muted opacity-25 mb-3"></i>
                                <p class="text-muted mb-0">No transactions found.</p>
                            </td></tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </c:if>
    </div>

    <div class="modal fade" id="detailModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">
                <div class="modal-header border-0 pb-0">
                    <h5 class="fw-bold ms-2">Trade Receipt</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="receipt-header mb-4">
                        <div class="display-6 fw-bold text-dark" id="detPrice"></div>
                        <p class="text-muted mb-0 fw-bold" id="detAsset"></p>
                    </div>

                    <div class="p-3 mb-4 border rounded-4">
                        <div class="d-flex justify-content-between mb-2 border-bottom pb-2">
                            <span class="text-muted small text-uppercase fw-bold">Order Type</span>
                            <strong id="detType" class="text-dark"></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2 border-bottom pb-2">
                            <span class="text-muted small text-uppercase fw-bold">Quantity</span>
                            <strong id="detQty" class="text-dark"></strong>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span class="text-muted small text-uppercase fw-bold">Transaction ID</span>
                            <strong id="detId" class="text-dark"></strong>
                        </div>
                    </div>

                    <a id="downloadBtn" href="#" class="btn btn-brand w-100 py-3 rounded-pill shadow-sm">
                        <i class="fa-solid fa-download me-2"></i> Download Invoice
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="historyModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content shadow-lg p-3">
                <div class="modal-header border-0 pb-2">
                    <div>
                        <h4 class="fw-bold mb-0" id="modalUserName">Investor History</h4>
                        <p class="text-muted small mb-0">Complete trade log for this user</p>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-0">
                    <div class="table-responsive rounded-4 border mt-2">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3">Date</th>
                                    <th>Asset</th>
                                    <th>Type</th>
                                    <th class="text-end">Qty</th>
                                    <th class="text-end pe-3">Amount</th>
                                </tr>
                            </thead>
                            <tbody id="modalBody">
                                </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // --- 1. RECEIPT LOGIC ---
        function showDetails(id, name, type, qty, price) {
            document.getElementById('detId').innerText = "#" + id;
            document.getElementById('detAsset').innerText = name;
            document.getElementById('detType').innerText = type;
            document.getElementById('detQty').innerText = qty + " Units";
            document.getElementById('detPrice').innerText = "₹" + (qty * price).toFixed(2);
            document.getElementById('downloadBtn').href = "transaction/download?id=" + id;

            // Color coding for modal
            const typeEl = document.getElementById('detType');
            if(type === 'BUY') typeEl.className = "text-success fw-bold";
            else typeEl.className = "text-danger fw-bold";

            new bootstrap.Modal(document.getElementById('detailModal')).show();
        }

        // --- 2. POPUP FILTER LOGIC ---
        const allTransactions = [
            <c:forEach var="t" items="${transactionList}">
            {
                userId: "${t.userId}",
                date: "<fmt:formatDate value='${t.transactionDate}' pattern='MMM dd, yyyy'/>",
                asset: "<c:out value='${t.assetName}'/>",
                type: "${t.type}",
                qty: "${t.quantity}",
                total: "${t.quantity * t.price}"
            },
            </c:forEach>
        ];

        const historyModal = new bootstrap.Modal(document.getElementById('historyModal'));

        function openHistoryModal(userId, userName) {
            document.getElementById('modalUserName').innerText = userName + "'s History";

            const userTrades = allTransactions.filter(t => t.userId === userId);
            const tbody = document.getElementById('modalBody');
            tbody.innerHTML = '';

            if(userTrades.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">No records found.</td></tr>';
            } else {
                userTrades.forEach(t => {
                    const badgeClass = t.type === 'BUY' ? 'badge-buy' : 'badge-sell';
                    const row = `
                        <tr>
                            <td class="ps-3 small text-muted">\${t.date}</td>
                            <td class="fw-bold">\${t.asset}</td>
                            <td><span class="badge \${badgeClass} rounded-pill px-3 py-2">\${t.type}</span></td>
                            <td class="text-end">\${t.qty}</td>
                            <td class="text-end fw-bold pe-3">₹\${parseFloat(t.total).toFixed(2)}</td>
                        </tr>
                    `;
                    tbody.innerHTML += row;
                });
            }
            historyModal.show();
        }
    </script>
</body>
</html>