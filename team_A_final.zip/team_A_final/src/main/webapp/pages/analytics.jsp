<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Analytics | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --color-primary: #00d09c; --color-primary-dark: #00a87d; --color-secondary: #2c3e50; --bg-light: #f4fcfb; --glass-bg: rgba(255, 255, 255, 0.95); }
        body { font-family: 'Poppins', sans-serif; background-color: var(--bg-light); color: var(--color-secondary); }
        .navbar-custom { background: var(--glass-bg); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 15px 0; }
        .navbar-brand { font-weight: 800; font-size: 1.5rem; color: var(--color-secondary) !important; letter-spacing: -0.5px; }

        /* Logo Colour Fix */
        .logo-icon { color: var(--color-primary) !important; }

        .nav-link-custom { color: #64748b; font-weight: 600; padding: 8px 16px; border-radius: 50px; transition: 0.3s; text-decoration: none; font-size: 0.95rem; }
        .nav-link-custom:hover { color: var(--color-primary); background: rgba(0, 208, 156, 0.05); }
        .nav-link-custom.active { background-color: var(--color-primary); color: white; box-shadow: 0 4px 12px rgba(0, 208, 156, 0.3); }
        .card-pro { border: none; border-radius: 24px; background: #fff; box-shadow: 0 10px 30px rgba(0,0,0,0.03); padding: 24px; transition: transform 0.3s ease; }
        .hover-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.08); cursor: pointer; border: 1px solid var(--color-primary); }
        .metric-value { font-size: 2.5rem; font-weight: 700; color: var(--color-secondary); letter-spacing: -1px; }
        .live-indicator { width: 8px; height: 8px; background-color: #ef4444; border-radius: 50%; display: inline-block; animation: pulse 1.5s infinite; }
        @keyframes pulse { 0% { opacity: 1; transform: scale(1); } 50% { opacity: 0.5; transform: scale(1.2); } 100% { opacity: 1; transform: scale(1); } }
        canvas { -moz-user-select: none; -webkit-user-select: none; -ms-user-select: none; }

        /* Table Styles */
        .table th { background-color: #f8fafc; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; padding: 15px; color: #64748b; }
        .table td { padding: 15px; vertical-align: middle; font-weight: 500; color: var(--color-secondary); }
        .btn-dark { background: var(--color-secondary); border: none; border-radius: 50px; }
        .btn-success { background: var(--color-primary); border: none; border-radius: 50px; }
        .btn-success:hover { background: var(--color-primary-dark); }
    </style>
</head>
<body>

    <nav class="navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a class="navbar-brand me-5" href="welcome">
                    <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
                </a>
                <div class="d-none d-lg-flex gap-2">
                    <a href="welcome" class="nav-link-custom"><i class="fa-solid fa-house me-1"></i> Dashboard</a>
                    <a href="portfolio" class="nav-link-custom"><i class="fa-solid fa-briefcase me-1"></i> Portfolio</a>
                    <a href="assets" class="nav-link-custom"><i class="fa-solid fa-coins me-1"></i> Assets</a>

                    <c:if test="${sessionScope.role != 'ADVISOR'}">
                        <a href="transaction" class="nav-link-custom"><i class="fa-solid fa-right-left me-1"></i> Transactions</a>
                    </c:if>

                    <a href="analytics" class="nav-link-custom active"><i class="fa-solid fa-chart-pie me-1"></i> Analytics</a>
                </div>
            </div>

            <div class="dropdown">
                <div class="bg-white border rounded-pill px-3 py-1 shadow-sm d-flex align-items-center" style="cursor: pointer;" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=${sessionScope.userName}&background=00d09c&color=fff" class="rounded-circle me-2" width="32">
                    <span class="small fw-bold text-dark">${sessionScope.userName}</span>
                    <i class="fa-solid fa-chevron-down ms-2 text-muted" style="font-size: 0.7rem;"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 p-2 rounded-4">
                    <li class="dropdown-item small text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">${sessionScope.role} Account</li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger fw-bold rounded-3" href="logout"><i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <input type="hidden" id="targetUserId" value="${targetUserId}">
        <input type="hidden" id="currentPortfolioId" value="${selectedId}">
        <input type="hidden" id="isMarketView" value="${marketView}">

        <%-- Global Helper Function for Colors (Placed here to be available for both Admin and User charts) --%>
        <script>
            // --- DYNAMIC COLOR GENERATOR (GOLDEN ANGLE) ---
            // Generates 'n' distinct colors. Even if you have 100 assets, colors won't repeat neighbors.
            const generateDistinctColors = (count) => {
                const colors = [];
                for(let i = 0; i < count; i++) {
                    // 137.508° is the Golden Angle. It provides optimal spacing on the color wheel.
                    const hue = Math.floor((i * 137.508) % 360);
                    // HSL: Hue, 65% Saturation (Vibrant), 55% Lightness (Readable)
                    colors.push(`hsl(\${hue}, 65%, 55%)`);
                }
                return colors;
            };
        </script>

        <c:if test="${sessionScope.role == 'ADMIN' && empty viewingUser}">
            <div class="d-flex justify-content-between align-items-center mb-5">
                <div><h2 class="fw-bold">System Overview</h2><p class="text-muted">Global analytics and investor management.</p></div>
            </div>

            <div class="row g-4 mb-5">
                <div class="col-12">
                    <div class="card-pro h-100">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold mb-0">Total System Assets</h5>
                            <span class="badge bg-light text-dark border rounded-pill">Global Allocation</span>
                        </div>
                        <div style="height: 350px; width: 100%; max-width: 600px; margin: 0 auto;">
                            <canvas id="systemChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <h4 class="fw-bold mb-4">Investor Analytics</h4>
            <div class="row g-4">
                <c:forEach var="inv" items="${allInvestors}">
                    <div class="col-md-3">
                        <div class="card-pro hover-card h-100 text-center position-relative" onclick="window.location.href='analytics?viewInvestorId=${inv.userId}'">
                            <div class="bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width:60px; height:60px;">
                                <i class="fa-solid fa-user fs-3 text-secondary"></i>
                            </div>
                            <h5 class="fw-bold mb-1 text-dark">${inv.username}</h5>
                            <p class="text-muted small mb-3">${inv.email}</p>
                            <hr class="opacity-25">
                            <div class="small text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">Managed By</div>
                            <div class="fw-bold text-primary">${not empty advisorMap[inv.userId] ? advisorMap[inv.userId] : 'Unassigned'}</div>
                        </div>
                    </div>
                </c:forEach>
            </div>
            <script>
                // Admin Chart Logic
                const sysLabels = [<c:forEach var="lbl" items="${sysLabels}">"${lbl}",</c:forEach>];
                new Chart(document.getElementById('systemChart'), {
                    type: 'doughnut',
                    data: {
                        labels: sysLabels,
                        datasets: [{
                            data: [<c:forEach var="val" items="${sysValues}">${val},</c:forEach>],
                            // USE DYNAMIC COLORS HERE TOO
                            backgroundColor: generateDistinctColors(sysLabels.length)
                        }]
                    },
                    options: { maintainAspectRatio: false }
                });
            </script>
        </c:if>

        <c:if test="${sessionScope.role == 'ADVISOR' && empty viewingUser && empty marketView}">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">My Clients</h2>
                <a href="analytics?viewMarket=true" class="btn btn-dark rounded-pill px-4 shadow-sm">
                    <i class="fa-solid fa-globe me-2"></i>View Market Assets
                </a>
            </div>

            <c:if test="${empty myClients}"><p class="text-muted">No active clients found.</p></c:if>
            <div class="row g-4">
                <c:forEach var="client" items="${myClients}">
                    <div class="col-md-4">
                        <div class="card-pro hover-card p-4" onclick="window.location.href='analytics?viewInvestorId=${client.userId}'">
                            <h5 class="fw-bold">${client.username}</h5>
                            <p class="text-muted small mb-0">${client.email}</p>
                            <hr>
                            <div class="d-flex justify-content-between"><span class="small fw-bold">View Analytics</span><i class="fa-solid fa-arrow-right text-primary"></i></div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </c:if>

        <c:if test="${(sessionScope.role != 'ADMIN' && sessionScope.role != 'ADVISOR') || not empty viewingUser || not empty marketView}">

            <div class="d-flex justify-content-between align-items-center mb-5">
                <div>
                    <c:if test="${not empty viewingUser}">
                        <a href="analytics" class="btn btn-light btn-sm rounded-pill mb-2 fw-bold"><i class="fa-solid fa-arrow-left me-1"></i> Back to Clients</a>
                        <h2 class="fw-bold">Analytics: ${viewingUser.username}</h2>
                    </c:if>
                    <c:if test="${not empty marketView}">
                        <a href="analytics" class="btn btn-light btn-sm rounded-pill mb-2 fw-bold"><i class="fa-solid fa-arrow-left me-1"></i> Back to Dashboard</a>
                        <h2 class="fw-bold">Global Market Assets</h2>
                    </c:if>
                    <c:if test="${empty viewingUser && empty marketView}">
                        <h2 class="fw-bold">Live Market Simulation</h2>
                    </c:if>

                    <p class="text-muted"><span class="live-indicator"></span> Market Open</p>
                </div>

                <c:if test="${empty marketView}">
                    <form action="analytics" method="get" class="d-flex align-items-center bg-white p-2 rounded-pill shadow-sm">
                        <c:if test="${not empty viewingUser}"><input type="hidden" name="viewInvestorId" value="${viewingUser.userId}"></c:if>
                        <select name="selectedPortfolioId" class="form-select border-0 fw-bold rounded-pill" style="width: 200px;" onchange="this.form.submit()">
                            <c:forEach var="p" items="${portfolios}">
                                <option value="${p.portfolioId}" ${p.portfolioId == selectedId ? 'selected' : ''}>${p.portfolioName}</option>
                            </c:forEach>
                            <c:if test="${empty portfolios}"><option>No Portfolios</option></c:if>
                        </select>
                    </form>
                </c:if>
            </div>

            <c:if test="${empty portfolios && empty marketView}">
                <div class="text-center py-5">
                    <div class="bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width:80px; height:80px;">
                        <i class="fa-solid fa-folder-open fs-2 text-muted opacity-50"></i>
                    </div>
                    <h4 class="fw-bold text-muted">No Data Available</h4>
                    <p class="text-muted">This user has not created any portfolios yet.</p>
                </div>
            </c:if>

            <c:if test="${not empty portfolios || not empty marketView}">
                <div class="card-pro mb-5 bg-white">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h5 class="fw-bold mb-0" id="graphTitle">
                                ${not empty marketView ? 'Select an Asset' : 'Total Portfolio Value'}
                            </h5>
                            <small class="text-muted">Real-time simulation.</small>
                        </div>
                        <div class="d-flex gap-2 align-items-center">
                            <select id="assetSelect" class="form-select form-select-sm border-0 bg-light fw-bold rounded-pill" style="width: 150px;">
                                <c:if test="${empty marketView}">
                                    <option value="ALL" selected>Total Portfolio</option>
                                </c:if>
                                <c:forEach var="lbl" items="${assetLabels}">
                                    <option value="${lbl}">${lbl}</option>
                                </c:forEach>
                                <c:if test="${empty assetLabels}"><option disabled>No Assets Found</option></c:if>
                            </select>
                            <span class="badge bg-success-subtle text-success px-3 py-2 rounded-pill"><i class="fa-solid fa-wifi me-2"></i>Live</span>
                        </div>
                    </div>
                    <div class="border rounded-4 p-3 position-relative" style="height: 400px;">
                        <canvas id="liveMarketChart"></canvas>
                    </div>
                </div>

                <c:if test="${empty marketView}">
                    <div class="row g-4 mb-5">
                        <div class="col-lg-6">
                            <div class="card-pro h-100">
                                <div class="mb-4">
                                    <div class="metric-label mb-2">Live Performance</div>
                                    <div id="liveReturnContainer" class="metric-value text-muted">--%</div>
                                    <p class="text-muted small">Updating live...</p>
                                </div>
                                <hr class="opacity-25">
                                <div class="mb-2">
                                    <div class="metric-label mb-2">Risk Score</div>
                                    <h3 class="fw-bold mb-0">${report != null ? report.riskScore : '0.0'} <span class="fs-6 text-muted">/ 10</span></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="card-pro h-100 d-flex flex-column">
                                <h5 class="fw-bold mb-3">Asset Allocation</h5>
                                <div class="flex-grow-1" style="position: relative; min-height: 250px;">
                                    <canvas id="allocationChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-pro mb-5 bg-white">
                        <div class="d-flex flex-wrap gap-3 align-items-end justify-content-between mb-3">
                            <div><h5 class="fw-bold mb-1">Transaction History</h5><p class="text-muted small mb-0">Detailed log of your trading activity.</p></div>
                            <div class="d-flex gap-2 align-items-end">
                                <div><label class="small fw-bold text-muted">Start</label><input type="date" id="startDate" class="form-control border bg-light"></div>
                                <div><label class="small fw-bold text-muted">End</label><input type="date" id="endDate" class="form-control border bg-light"></div>
                                <button onclick="updateHistoryTable()" class="btn btn-dark shadow-sm px-3"><i class="fa-solid fa-filter"></i></button>
                                <button onclick="downloadReport()" class="btn btn-success fw-bold text-white shadow-sm px-3"><i class="fa-solid fa-download me-2"></i> Report</button>
                            </div>
                        </div>

                        <div class="overflow-auto border rounded-4" style="max-height: 400px;">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light sticky-top">
                                    <tr>
                                        <th class="ps-4 py-3">Date</th>
                                        <th class="py-3">Type</th>
                                        <th class="py-3">Asset Name</th>
                                        <th class="text-end py-3">Quantity</th>
                                        <th class="text-end py-3">Price</th>
                                        <th class="text-end py-3 pe-4">Total Value</th>
                                    </tr>
                                </thead>
                                <tbody id="historyTableBody">
                                </tbody>
                            </table>
                            <div id="noDataMessage" class="text-center py-5 text-muted d-none">
                                <i class="fa-solid fa-clipboard-question fs-1 opacity-25"></i>
                                <p class="small mt-2">No transactions found for this period.</p>
                            </div>
                        </div>
                    </div>
                </c:if>

                <script>
                    const ctxLive = document.getElementById('liveMarketChart').getContext('2d');
                    let gradientLive = ctxLive.createLinearGradient(0, 0, 0, 400);
                    gradientLive.addColorStop(0, 'rgba(0, 208, 156, 0.4)');
                    gradientLive.addColorStop(1, 'rgba(255, 255, 255, 0.0)');

                    const liveChart = new Chart(ctxLive, {
                        type: 'line',
                        data: {
                            labels: [],
                            datasets: [{
                                label: 'Value (₹)',
                                data: [],
                                borderColor: '#00d09c',
                                backgroundColor: gradientLive,
                                borderWidth: 2,
                                pointRadius: 0,
                                pointHoverRadius: 6,
                                fill: true,
                                tension: 0.4,
                                cubicInterpolationMode: 'monotone'
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            animation: false,
                            interaction: { intersect: false, mode: 'index' },
                            plugins: {
                                legend: { display: false },
                                tooltip: {
                                    callbacks: { label: function(context) { return ' Value: ₹' + context.parsed.y.toFixed(2); } }
                                }
                            },
                            scales: {
                                x: { display: false },
                                y: { position: 'right', grid: { borderDash: [5, 5] } }
                            }
                        }
                    });

                    const isMarketView = document.getElementById('isMarketView').value === 'true';
                    let selectedAsset = isMarketView ? document.getElementById('assetSelect').options[0].value : "ALL";

                    if(isMarketView) {
                         const title = document.getElementById('graphTitle');
                         if(title) title.innerText = "Live Market: " + selectedAsset;
                    }

                    document.getElementById('assetSelect').addEventListener('change', function() {
                        selectedAsset = this.value;
                        const title = document.getElementById('graphTitle');

                        if(selectedAsset === 'ALL') {
                            title.innerText = "Total Portfolio Value";
                        } else {
                            title.innerText = "Live Market: " + selectedAsset;
                        }

                        liveChart.data.labels = [];
                        liveChart.data.datasets[0].data = [];
                        liveChart.update();
                    });

                    function fetchLivePrice() {
                        const targetId = document.getElementById('targetUserId').value;
                        const currentPId = document.getElementById('currentPortfolioId').value;
                        let apiUrl = "";

                        if (selectedAsset === "ALL" && !isMarketView) {
                            if(!currentPId) return;
                            apiUrl = '/api/portfolio-updates?investorId=' + targetId;
                        } else {
                            apiUrl = '/api/analytics/asset-live?assetName=' + encodeURIComponent(selectedAsset);
                        }

                        fetch(apiUrl)
                            .then(res => res.json())
                            .then(data => {
                                let displayValue = 0;

                                if (selectedAsset === "ALL" && !isMarketView) {
                                    if(Array.isArray(data) && data.length > 0) {
                                        const pData = data.find(p => p.id == currentPId);
                                        if(pData) {
                                            displayValue = parseFloat(pData.totalValue || 0);
                                            if(displayValue === 0) displayValue = 10000 + (parseFloat(pData.pl) * 100);

                                            const returnEl = document.getElementById('liveReturnContainer');
                                            if (returnEl) {
                                                const val = parseFloat(pData.pl);
                                                returnEl.innerText = (val >= 0 ? "+" : "") + val.toFixed(2) + "%";
                                                returnEl.className = "metric-value " + (val >= 0 ? "text-success" : "text-danger");
                                            }
                                        }
                                    }
                                } else {
                                    if (data.price) displayValue = parseFloat(data.price);
                                }

                                if (displayValue > 0) {
                                    const now = new Date();
                                    const timeLabel = now.getHours() + ':' + now.getMinutes() + ':' + now.getSeconds();
                                    liveChart.data.labels.push(timeLabel);
                                    liveChart.data.datasets[0].data.push(displayValue);
                                    if (liveChart.data.labels.length > 20) {
                                        liveChart.data.labels.shift();
                                        liveChart.data.datasets[0].data.shift();
                                    }
                                    liveChart.update();
                                }
                            })
                            .catch(err => console.error(err));
                    }
                    setInterval(fetchLivePrice, 2000);

                    <c:if test="${empty marketView}">
                        const allocLabels = [<c:forEach var="lbl" items="${assetLabels}">"${lbl}",</c:forEach>];

                        // --- PIE CHART GENERATION ---
                        if (allocLabels.length > 0) {
                            new Chart(document.getElementById('allocationChart'), {
                                type: 'doughnut',
                                data: {
                                    labels: allocLabels,
                                    datasets: [{
                                        data: [<c:forEach var="val" items="${assetValues}">${val},</c:forEach>],
                                        // Use the Global Helper Function from top of body
                                        backgroundColor: generateDistinctColors(allocLabels.length)
                                    }]
                                },
                                options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
                            });
                        }

                        // TABLE LOGIC
                        const today = new Date();
                        const lastMonth = new Date();
                        lastMonth.setDate(today.getDate() - 30);
                        document.getElementById('endDate').valueAsDate = today;
                        document.getElementById('startDate').valueAsDate = lastMonth;

                        function updateHistoryTable() {
                            const start = document.getElementById('startDate').value;
                            const end = document.getElementById('endDate').value;
                            const targetId = document.getElementById('targetUserId').value;
                            const tbody = document.getElementById('historyTableBody');
                            const noData = document.getElementById('noDataMessage');

                            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-5 text-muted"><div class="spinner-border spinner-border-sm text-success me-2"></div>Loading Transactions...</td></tr>';
                            noData.classList.add('d-none');

                            fetch('/api/analytics/filter?startDate=' + start + '&endDate=' + end + '&viewInvestorId=' + targetId)
                                .then(res => res.json())
                                .then(data => {
                                    tbody.innerHTML = '';
                                    if (!data || data.length === 0) {
                                        noData.classList.remove('d-none');
                                        return;
                                    }
                                    data.forEach(item => {
                                        let dateStr = "N/A";
                                        if (item.transactionDate) {
                                            dateStr = new Date(item.transactionDate).toISOString().split('T')[0];
                                        }
                                        const type = item.type ? item.type : "UNKNOWN";
                                        const badgeClass = (type === 'BUY') ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger';

                                        const priceFormatted = parseFloat(item.price).toFixed(2);
                                        const totalVal = (item.price * item.quantity).toFixed(2);

                                        const row = `
                                            <tr>
                                                <td class="ps-4 fw-bold text-secondary">\${dateStr}</td>
                                                <td><span class="badge \${badgeClass} border border-0 px-2 rounded-pill">\${type}</span></td>
                                                <td class="fw-bold">\${item.assetName || item.name}</td>
                                                <td class="text-end">\${item.quantity}</td>
                                                <td class="text-end text-muted">₹\${priceFormatted}</td>
                                                <td class="text-end pe-4 fw-bold">₹\${totalVal}</td>
                                            </tr>`;
                                        tbody.innerHTML += row;
                                    });
                                })
                                .catch(err => {
                                    console.error(err);
                                    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger py-4">Failed to load data.</td></tr>';
                                });
                        }

                        function downloadReport() {
                            const start = document.getElementById('startDate').value;
                            const end = document.getElementById('endDate').value;
                            const targetId = document.getElementById('targetUserId').value;
                            window.location.href = '/analytics/download?startDate=' + start + '&endDate=' + end + '&viewInvestorId=' + targetId;
                        }

                        updateHistoryTable();
                    </c:if>
                </script>
            </c:if>
        </c:if>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>