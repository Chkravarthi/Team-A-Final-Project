<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GrowMore | Investment Management System</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Color Palette --- */
        :root {
            --color-primary: #00d09c;     /* Brand Green/Teal */
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;   /* Dark Navy */
            --color-bg-light: #f4fcfb;    /* Very light teal tint */
            --glass-bg: rgba(255, 255, 255, 0.95);
            --shadow-soft: 0 10px 40px rgba(0,0,0,0.08);
        }

        /* --- Global Animations --- */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* NEW: Text Reveal Animation */
        @keyframes textFocusIn {
            0% { filter: blur(12px); opacity: 0; }
            100% { filter: blur(0); opacity: 1; }
        }

        /* NEW: Smooth Tracking Animation */
        @keyframes trackingIn {
            0% { letter-spacing: -0.5em; opacity: 0; }
            100% { opacity: 1; }
        }

        /* --- Global Styles --- */
        body {
            font-family: 'Poppins', sans-serif;
            color: var(--color-secondary);
            background-color: #ffffff;
            overflow-x: hidden;
            position: relative;
        }

        /* --- Mouse Follow Background Animation --- */
        #mouse-glow {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            /* Initial diagonal glow position */
            background: radial-gradient(circle at 0% 0%, rgba(0, 208, 156, 0.15) 0%, transparent 70%);
            pointer-events: none;
            z-index: 0;
            transition: background 0.1s ease-out;
        }

        /* --- Navbar (Glassmorphism) --- */
        .navbar-custom {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 15px 0;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .navbar-brand {
            font-weight: 800;
            font-size: 1.6rem;
            color: var(--color-secondary) !important;
            letter-spacing: -0.5px;
        }
        .logo-icon { color: var(--color-primary); }
        .nav-link {
            font-weight: 500;
            color: #555 !important;
            margin: 0 10px;
            transition: color 0.3s;
        }
        .nav-link:hover { color: var(--color-primary) !important; }

        .btn-nav-outline {
            border: 2px solid var(--color-secondary);
            color: var(--color-secondary);
            font-weight: 600;
            border-radius: 8px;
            padding: 8px 20px;
        }
        .btn-nav-outline:hover {
            background-color: var(--color-secondary);
            color: #fff;
        }
        .btn-nav-primary {
            background-color: var(--color-primary);
            color: #fff;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            padding: 10px 25px;
            transition: transform 0.2s;
        }
        .btn-nav-primary:hover {
            background-color: var(--color-primary-dark);
            transform: translateY(-2px);
        }

        /* --- Hero Section --- */
        .hero-section {
            padding: 140px 0 100px;
            text-align: center;
            background: transparent;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        /* Static Particle Layer */
        .hero-section::before {
            content: "";
            position: absolute;
            width: 100%; height: 100%;
            top: 0; left: 0;
            background-image: radial-gradient(var(--color-primary) 1px, transparent 1px);
            background-size: 50px 50px;
            opacity: 0.15;
            mask-image: linear-gradient(to bottom, black 40%, transparent 100%);
            animation: heroMove 60s linear infinite;
            z-index: -1;
        }
        @keyframes heroMove { 0% { transform: translateY(0); } 100% { transform: translateY(-500px); } }

        .hero-content {
            position: relative;
            z-index: 2;
            animation: fadeInUp 0.8s ease-out forwards;
        }

        .hero-badge {
            background-color: rgba(0, 208, 156, 0.1);
            color: var(--color-primary-dark);
            padding: 8px 16px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-block;
            margin-bottom: 20px;
            animation: textFocusIn 1s cubic-bezier(0.550, 0.085, 0.680, 0.530) both;
        }

        .hero-section h1 {
            font-size: 3.5rem;
            font-weight: 800;
            line-height: 1.4;
            margin-bottom: 20px;
            letter-spacing: -1px;
            animation: textFocusIn 1.2s cubic-bezier(0.230, 1.000, 0.320, 1.000) 0.2s both;
        }

        .highlight-text {
            color: var(--color-primary);
            position: relative;
            display: inline-block;
            padding: 0 15px;
            background: rgba(0, 208, 156, 0.05);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 12px;
            border: 1px solid rgba(0, 208, 156, 0.2);
            box-shadow: 0 8px 32px 0 rgba(0, 208, 156, 0.25);
            transition: all 0.4s ease;
        }

        .highlight-text:hover {
            transform: scale(1.05);
            background: rgba(0, 208, 156, 0.1);
            box-shadow: 0 8px 32px 0 rgba(0, 208, 156, 0.4);
        }

        /* MODIFIED: Animation removed for this paragraph */
        .hero-section p {
            font-size: 1.25rem;
            color: #666;
            max-width: 700px;
            margin: 0 auto 40px;
            font-weight: 400;
            /* Animation property removed here */
        }

        .btn-cta {
            background-color: var(--color-primary);
            color: white;
            padding: 16px 45px;
            font-size: 1.1rem;
            font-weight: 700;
            border-radius: 50px;
            border: none;
            box-shadow: 0 15px 30px rgba(0, 208, 156, 0.3);
            transition: all 0.3s ease;
            animation: fadeInUp 1s ease-out 0.8s both;
        }
        .btn-cta:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 208, 156, 0.4);
            background-color: var(--color-primary-dark);
            color: white;
        }

        /* --- Features Section --- */
        .features-section {
            padding: 100px 0;
            background-color: rgba(255, 255, 255, 0.8);
            position: relative;
            z-index: 1;
        }

        .section-title {
            font-weight: 800;
            margin-bottom: 60px;
            position: relative;
            display: inline-block;
        }

        .feature-card {
            background: #fff;
            padding: 40px 30px;
            border-radius: 20px;
            border: 1px solid #f0f0f0;
            transition: all 0.3s ease;
            height: 100%;
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.8s ease-out forwards;
            opacity: 0;
        }

        .delay-1 { animation-delay: 1s; }
        .delay-2 { animation-delay: 1.2s; }
        .delay-3 { animation-delay: 1.4s; }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-soft);
            border-color: transparent;
        }

        .feature-card::before {
            content: "";
            position: absolute;
            top: 0; left: 0; width: 100%; height: 5px;
            background: var(--color-primary);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.3s ease;
        }
        .feature-card:hover::before { transform: scaleX(1); }

        .icon-box {
            width: 60px; height: 60px;
            background-color: rgba(0, 208, 156, 0.1);
            color: var(--color-primary);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 25px;
            transition: all 0.3s;
        }
        .feature-card:hover .icon-box {
            background-color: var(--color-primary);
            color: #fff;
            transform: rotate(5deg);
        }

        .feature-card h5 { font-weight: 700; margin-bottom: 15px; font-size: 1.25rem; }
        .feature-card p { color: #777; line-height: 1.6; margin-bottom: 0; font-size: 0.95rem; }

        /* --- Footer --- */
        .footer-custom {
            background-color: var(--color-bg-light);
            padding: 40px 0;
            text-align: center;
            border-top: 1px solid #eee;
            position: relative;
            z-index: 1;
        }
        .footer-text { font-size: 0.9rem; color: #888; }
        .footer-logo { color: var(--color-secondary); font-weight: 700; }
    </style>
</head>
<body>

    <div id="mouse-glow"></div>

    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fa-solid fa-chart-line logo-icon"></i> GrowMore
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">

                </ul>
                <div class="d-flex gap-2">
                    <a href="/signin" class="btn btn-nav-outline">Sign In</a>
                    <a href="/signup" class="btn btn-nav-primary">Sign Up</a>
                </div>
            </div>
        </div>
    </nav>

    <section class="hero-section">
        <div class="container hero-content">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <span class="hero-badge"><i class="fa-solid fa-rocket me-2"></i>Next Gen Portfolio Management</span>
                    <h1>
                        Take Control of Your <br>
                        <span class="highlight-text">Financial Future</span>
                    </h1>
                    <p>
                        Unified tracking, real-time analytics, and secure trade execution.
                        The professional tool for Investors and Advisors alike.
                    </p>
                    <a href="/signup" class="btn btn-cta">
                        Start Growing Today <i class="fa-solid fa-arrow-right ms-2"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section id="features" class="features-section">
        <div class="container">
            <div class="text-center">
                <h2 class="section-title">Why Choose GrowMore?</h2>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4">
                    <div class="feature-card delay-1">
                        <div class="icon-box"><i class="fa-solid fa-layer-group"></i></div>
                        <h5>Dynamic Portfolios</h5>
                        <p>Create tailored strategies tailored to your specific risk tolerance. Manage multiple asset classes in one view.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-card delay-2">
                        <div class="icon-box"><i class="fa-solid fa-chart-pie"></i></div>
                        <h5>Real-Time Tracking</h5>
                        <p>Live updates on Stocks, Bonds, and Mutual Funds. Never miss a market movement with instant data refresh.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-card delay-3">
                        <div class="icon-box"><i class="fa-solid fa-bolt"></i></div>
                        <h5>Instant Execution</h5>
                        <p>Secure, low-latency BUY and SELL orders. Execute trades instantly with full transaction history logging.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-card delay-1">
                        <div class="icon-box"><i class="fa-solid fa-magnifying-glass-chart"></i></div>
                        <h5>Deep Analytics</h5>
                        <p>Visualize performance with interactive charts. Track ROI, P&L, and historical trends effortlessly.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-card delay-2">
                        <div class="icon-box"><i class="fa-solid fa-user-shield"></i></div>
                        <h5>Role-Based Security</h5>
                        <p>Bank-grade security protocols separating Investors, Advisors, and Admin privileges for data integrity.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-card delay-3">
                        <div class="icon-box"><i class="fa-solid fa-headset"></i></div>
                        <h5>Advisor Connect</h5>
                        <p>Investors can request professional Advisors. Advisors can manage client portfolios seamlessly.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer-custom">
        <div class="container">
            <div class="mb-3">
                <span class="footer-logo"><i class="fa-solid fa-chart-line text-primary"></i> GrowMore</span>
            </div>
            <p class="footer-text">&copy; 2026 GrowMore Inc. All rights reserved. <br> Secure Investment Management System.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        const glow = document.getElementById('mouse-glow');
        window.addEventListener('mousemove', (e) => {
            const x = (e.clientX / window.innerWidth) * 100;
            const y = (e.clientY / window.innerHeight) * 100;
            glow.style.background = `radial-gradient(circle at ${x}% ${y}%, rgba(0, 208, 156, 0.2) 0%, transparent 65%)`;
        });
    </script>
</body>
</html>
