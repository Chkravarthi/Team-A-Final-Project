<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Assets | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Branding Variables --- */
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
            --bg-light: #f4fcfb;
            --glass-bg: rgba(255, 255, 255, 0.95);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--color-secondary);
        }

        /* --- Navbar --- */
        .navbar-custom {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 15px 0;
        }
        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            color: var(--color-secondary) !important;
            letter-spacing: -0.5px;
        }
        .logo-icon { color: var(--color-primary); }

        .nav-link-custom {
            color: #64748b;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            text-decoration: none;
            font-size: 0.95rem;
        }
        .nav-link-custom:hover { color: var(--color-primary); background: rgba(0, 208, 156, 0.05); }
        .nav-link-custom.active {
            background-color: var(--color-primary);
            color: white;
            box-shadow: 0 4px 12px rgba(0, 208, 156, 0.3);
        }

        /* --- Asset Cards --- */
        .asset-card {
            border: none;
            border-radius: 24px;
            background: #fff;
            padding: 24px;
            transition: all 0.3s ease;
            height: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            overflow: hidden;
        }
        .asset-card:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(0,0,0,0.08); }

        .asset-icon {
            width: 48px; height: 48px;
            border-radius: 14px;
            background: #f0fdf9;
            color: var(--color-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }

        /* --- Price Animations --- */
        .price-up { color: #00d09c !important; transition: color 0.5s; }
        .price-down { color: #ef4444 !important; transition: color 0.5s; }

        /* --- Buttons --- */
        .btn-brand {
            background: var(--color-primary);
            color: white;
            border: none;
            font-weight: 600;
            border-radius: 50px;
            padding: 10px 24px;
            transition: all 0.2s;
        }
        .btn-brand:hover { background: var(--color-primary-dark); color: white; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 208, 156, 0.3); }

        .btn-outline-dark { border-radius: 50px; font-weight: 600; padding: 8px 20px; }
        .btn-dark { border-radius: 50px; font-weight: 600; padding: 8px 20px; }

        /* --- Modals & Forms --- */
        .modal-content { border-radius: 24px; border: none; }
        .form-control, .form-select { border-radius: 12px; padding: 12px; background-color: #f8fafc; border: 1px solid #e2e8f0; }
        .form-control:focus { border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(0,208,156,0.1); }
    </style>
</head>
<body>

    <nav class="navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a class="navbar-brand me-5" href="welcome">
                    <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
                </a>
                <div class="d-none d-lg-flex gap-2">
                    <a href="welcome" class="nav-link-custom"><i class="fa-solid fa-house me-1"></i> Dashboard</a>
                    <a href="portfolio" class="nav-link-custom"><i class="fa-solid fa-briefcase me-1"></i> Portfolio</a>
                    <a href="assets" class="nav-link-custom active"><i class="fa-solid fa-coins me-1"></i> Assets</a>

                    <c:if test="${sessionScope.role != 'ADVISOR'}">
                        <a href="transaction" class="nav-link-custom"><i class="fa-solid fa-right-left me-1"></i> Transactions</a>
                    </c:if>

                    <a href="analytics" class="nav-link-custom"><i class="fa-solid fa-chart-pie me-1"></i> Analytics</a>
                </div>
            </div>

            <div class="dropdown">
                <div class="bg-white border rounded-pill px-3 py-1 shadow-sm d-flex align-items-center" style="cursor: pointer;" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=${sessionScope.userName}&background=00d09c&color=fff" class="rounded-circle me-2" width="32">
                    <span class="small fw-bold text-dark">${sessionScope.userName}</span>
                    <i class="fa-solid fa-chevron-down ms-2 text-muted" style="font-size: 0.7rem;"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 p-2 rounded-4">
                    <li class="dropdown-item small text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">${sessionScope.role} Account</li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger fw-bold rounded-3" href="logout"><i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <div>
                <h2 class="fw-bold">
                    <c:choose>
                        <c:when test="${viewingMode == 'PORTFOLIO_VIEW'}"><span style="color:var(--color-primary)">My</span> Holdings</c:when>
                        <c:when test="${viewingMode == 'CLIENT_VIEW'}">Client Analysis</c:when>
                        <c:otherwise>Live Market (₹)</c:otherwise>
                    </c:choose>
                </h2>
                <p class="text-muted">Real-time market prices updated instantly.</p>
            </div>
            <c:if test="${viewingMode == 'PORTFOLIO_VIEW'}">
                <a href="portfolio" class="btn btn-light border rounded-pill px-4 fw-bold"><i class="fa-solid fa-arrow-left me-2"></i> Back to Goals</a>
            </c:if>
            <c:if test="${sessionScope.role == 'ADMIN'}">
                <button class="btn btn-dark rounded-pill px-4 fw-bold shadow-sm" onclick="openAdminModal('CREATE')"><i class="fa-solid fa-rocket me-2"></i>Launch Asset</button>
            </c:if>
        </div>

        <div class="row g-4">
            <c:forEach var="asset" items="${assetList}">

                <div class="col-md-6 ${viewingMode == 'PORTFOLIO_VIEW' ? 'col-lg-4' : 'col-lg-3'}">

                    <div class="asset-card" style="min-height: ${viewingMode == 'PORTFOLIO_VIEW' ? '450px' : '320px'};">

                        <div>
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <div class="asset-icon"><i class="fa-solid fa-chart-line"></i></div>
                                <span class="badge bg-light text-dark border rounded-pill px-3 small py-2">${asset.type}</span>
                            </div>

                            <h5 class="fw-bold mb-1 text-dark">${asset.name}</h5>

                            <div class="my-3">
                                <label class="small fw-bold text-muted text-uppercase" style="font-size: 0.65rem;">Current Price</label>
                                <h3 class="text-success fw-bold mb-0 d-flex align-items-center gap-2">
                                    ₹<span id="price-${asset.assetId}"><fmt:formatNumber value="${asset.tempCurrentPrice}" minFractionDigits="2"/></span>
                                    <i id="arrow-${asset.assetId}" class="fa-solid fa-minus text-muted fs-6"></i>
                                </h3>
                            </div>

                            <div class="row g-2">
                                <c:if test="${sessionScope.role == 'ADMIN'}">
                                    <div class="col-12">
                                        <div class="bg-light p-2 rounded-3 border">
                                            <div class="small text-muted fw-bold text-uppercase" style="font-size:0.65rem">Launch Price</div>
                                            <div class="fw-bold text-dark">₹<fmt:formatNumber value="${asset.price}" minFractionDigits="2"/></div>
                                        </div>
                                    </div>
                                </c:if>

                                <c:if test="${viewingMode == 'PORTFOLIO_VIEW'}">
                                    <div class="col-6">
                                        <div class="bg-light p-2 rounded-3 border">
                                            <div class="small text-muted fw-bold text-uppercase" style="font-size:0.65rem">Avg Buy</div>
                                            <div class="fw-bold text-primary small">₹<fmt:formatNumber value="${asset.tempAvgBuyPrice}" maxFractionDigits="1"/></div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="bg-success-subtle text-success p-2 rounded-3 border border-success-subtle">
                                            <div class="small fw-bold text-uppercase" style="font-size:0.65rem">Qty</div>
                                            <div class="fw-bold small">${asset.quantity}</div>
                                        </div>
                                    </div>

                                    <div class="col-6 mt-2">
                                        <div class="p-1">
                                            <div class="small text-muted fw-bold" style="font-size:0.65rem">VALUE</div>
                                            <div class="fw-bold small text-dark">₹<span id="val-${asset.assetId}">...</span></div>
                                        </div>
                                    </div>
                                    <div class="col-6 mt-2">
                                        <div class="p-1">
                                            <div class="small text-muted fw-bold" style="font-size:0.65rem">RETURNS</div>
                                            <span id="pl-${asset.assetId}" class="badge bg-light text-dark border">...</span>
                                        </div>
                                    </div>
                                </c:if>
                            </div>
                        </div>

                        <div class="mt-3 pt-3 border-top d-grid gap-2">
                            <c:if test="${sessionScope.role == 'INVESTOR'}">
                                <c:choose>
                                    <c:when test="${viewingMode == 'MARKET_VIEW'}">
                                        <button class="btn btn-brand rounded-pill fw-bold btn-sm py-2 shadow-sm"
                                                onclick="openTradeModal('BUY', '${asset.name}', ${asset.tempCurrentPrice})">Buy</button>
                                    </c:when>
                                    <c:otherwise>
                                        <button class="btn btn-outline-danger rounded-pill fw-bold btn-sm py-2"
                                                onclick="openTradeModal('SELL', '${asset.name}', ${asset.tempCurrentPrice})">Sell</button>
                                    </c:otherwise>
                                </c:choose>
                            </c:if>

                            <c:if test="${sessionScope.role == 'ADMIN'}">
                                <div class="d-flex justify-content-between">
                                    <button class="btn btn-sm btn-link text-primary text-decoration-none fw-bold" onclick="openAdminModal('UPDATE', '${asset.assetId}', '${asset.name}', '${asset.type}', '${asset.price}')"><i class="fa-solid fa-pen me-1"></i>Edit</button>
                                    <form action="${pageContext.request.contextPath}/admin/asset/manage" method="post" style="display: inline;">
                                        <input type="hidden" name="operation" value="DELETE">
                                        <input type="hidden" name="assetId" value="${asset.assetId}">
                                        <button type="submit" class="btn btn-sm btn-link text-danger text-decoration-none fw-bold">
                                            <i class="fa-solid fa-trash me-1"></i>Del
                                        </button>
                                    </form>
                                </div>
                            </c:if>
                        </div>
                    </div>
                </div>
            </c:forEach>
        </div>
    </div>

    <input type="hidden" id="pagePortfolioId" value="${param.portfolioId}">

    <div class="modal fade" id="tradeModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content p-4 shadow-lg">
                <form action="asset/trade" method="post">
                    <input type="hidden" name="action" id="tAction">
                    <input type="hidden" name="name" id="tName">
                    <input type="hidden" name="price" id="tPrice">
                    <h4 class="fw-bold mb-4 text-dark"><span id="tTypeDisplay"></span> Order</h4>
                    <div class="mb-3"><label class="small fw-bold text-muted mb-1">Portfolio</label>
                        <select name="targetPortfolioId" class="form-select fw-bold text-secondary">
                            <c:choose>
                                <c:when test="${not empty selectedPortfolioId}"><option value="${selectedPortfolioId}" selected>Active Portfolio</option></c:when>
                                <c:otherwise><c:forEach var="p" items="${userPortfolios}"><option value="${p.portfolioId}">${p.portfolioName}</option></c:forEach></c:otherwise>
                            </c:choose>
                        </select>
                    </div>
                    <%-- Updated: Added min="1" validation --%>
                    <div class="mb-4"><label class="small fw-bold text-muted mb-1">Quantity</label><input type="number" name="quantity" class="form-control" min="1" value="1" required></div>
                    <button type="submit" id="tBtn" class="btn w-100 py-3 rounded-pill fw-bold shadow">Confirm</button>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="adminAssetModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content p-4 shadow-lg">
                <form action="admin/asset/manage" method="post">
                    <input type="hidden" name="operation" id="modalOp" value="CREATE">
                    <input type="hidden" name="assetId" id="modalAssetId">
                    <h3 class="fw-bold mb-3 text-dark" id="modalTitle">Manage Asset</h3>
                    <div class="mb-3">
                         <label class="small fw-bold text-muted mb-1">Asset Name</label>
                         <input type="text" name="name" id="modalName" class="form-control" placeholder="e.g. Apple Inc." required>
                    </div>
                    <div class="mb-3">
                         <label class="small fw-bold text-muted mb-1">Type</label>
                         <select name="type" id="modalType" class="form-select"><option value="STOCK">STOCK</option><option value="MF">MF</option></select>
                    </div>
                    <div class="mb-4">
                         <label class="small fw-bold text-muted mb-1">Launch Price (₹)</label>
                         <%-- Updated: Added min="0.01" validation --%>
                         <input type="number" step="0.01" min="0.01" name="price" id="modalPrice" class="form-control" placeholder="100.00" required>
                    </div>
                    <button type="submit" class="btn btn-dark w-100 py-3 rounded-pill fw-bold">Save Asset</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const tradeModal = new bootstrap.Modal(document.getElementById('tradeModal'));
        const adminModal = new bootstrap.Modal(document.getElementById('adminAssetModal'));
        function openTradeModal(action, name, price) {
            document.getElementById('tAction').value = action;
            document.getElementById('tTypeDisplay').innerText = action;
            document.getElementById('tName').value = name;
            document.getElementById('tPrice').value = price;
            const btn = document.getElementById('tBtn');
            btn.className = action === 'BUY' ? 'btn btn-success w-100 py-3 rounded-pill fw-bold' : 'btn btn-danger w-100 py-3 rounded-pill fw-bold';
            if(action === 'BUY') { btn.style.backgroundColor = 'var(--color-primary)'; btn.style.border = 'none'; }
            else { btn.style.backgroundColor = ''; btn.style.border = ''; }
            tradeModal.show();
        }
        function openAdminModal(op, id='', name='', type='STOCK', price='') {
            document.getElementById('modalOp').value = op;
            document.getElementById('modalAssetId').value = id;
            document.getElementById('modalName').value = name;
            document.getElementById('modalType').value = type;
            document.getElementById('modalPrice').value = price;
            document.getElementById('modalTitle').innerText = op === 'UPDATE' ? "Edit Asset" : "Launch Asset";
            adminModal.show();
        }

        const pagePId = document.getElementById('pagePortfolioId').value;

        function updateLiveAssets() {
            let apiUrl = '/api/asset-updates';
            if (pagePId) apiUrl += '?portfolioId=' + pagePId;

            fetch(apiUrl)
                .then(response => { if(response.ok) return response.json(); })
                .then(data => {
                    if (!data) return;

                    data.forEach(item => {
                        const priceEl = document.getElementById('price-' + item.assetId);
                        const arrowEl = document.getElementById('arrow-' + item.assetId);

                        if (priceEl) {
                            const oldPrice = parseFloat(priceEl.innerText.replace(/,/g, ''));
                            const newPrice = parseFloat(item.livePrice);

                            priceEl.innerText = item.livePrice;

                            if (newPrice > oldPrice) {
                                priceEl.parentElement.classList.remove('price-down');
                                priceEl.parentElement.classList.add('price-up');
                                if(arrowEl) arrowEl.className = "fa-solid fa-arrow-trend-up text-success fs-5";
                                setTimeout(() => priceEl.parentElement.classList.remove('price-up'), 5000);
                            } else if (newPrice < oldPrice) {
                                priceEl.parentElement.classList.remove('price-up');
                                priceEl.parentElement.classList.add('price-down');
                                if(arrowEl) arrowEl.className = "fa-solid fa-arrow-trend-down text-danger fs-5";
                                setTimeout(() => priceEl.parentElement.classList.remove('price-down'), 5000);
                            }
                        }

                        const valEl = document.getElementById('val-' + item.assetId);
                        if (valEl && item.currentValue) valEl.innerText = item.currentValue;

                        const plEl = document.getElementById('pl-' + item.assetId);
                        if (plEl && item.pl) {
                            const plVal = parseFloat(item.pl);
                            const sign = plVal >= 0 ? "+" : "";
                            const arrowIcon = plVal >= 0 ? '<i class="fa-solid fa-caret-up me-1"></i>' : '<i class="fa-solid fa-caret-down me-1"></i>';
                            plEl.innerHTML = arrowIcon + sign + plVal + " (" + item.plPct + "%)";
                            plEl.className = plVal >= 0 ? "badge bg-success-subtle text-success border border-success-subtle" : "badge bg-danger-subtle text-danger border border-danger-subtle";
                        }
                    });
                })
                .catch(err => console.log('Syncing...'));
        }

        updateLiveAssets();
        setInterval(updateLiveAssets, 5000);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Updated to catch the "errorPopup" and "successPopup" attributes
            const errorMsg = "${errorPopup}";
            const successMsg = "${successPopup}";

            if (errorMsg && errorMsg !== "null" && errorMsg.trim() !== "") {
                Swal.fire({
                    icon: 'error',
                    title: 'Action Denied',
                    text: errorMsg,
                    confirmButtonColor: '#d33'
                });
            }

            if (successMsg && successMsg !== "null" && successMsg.trim() !== "") {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: successMsg,
                    timer: 2000,
                    showConfirmButton: false
                });
            }
        });
    </script>
</body>
</html>