<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Create Account | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Branding Variables --- */
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
        }

        /* --- 1. BACKGROUND --- */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #e0f2fe;
            /* Mesh Gradient Background */
            background-image:
                radial-gradient(at 0% 0%, hsla(165,83%,40%,0.3) 0px, transparent 50%),
                radial-gradient(at 100% 0%, hsla(200,80%,50%,0.3) 0px, transparent 50%),
                radial-gradient(at 100% 100%, hsla(340,100%,76%,0.2) 0px, transparent 50%),
                radial-gradient(at 0% 100%, hsla(22,100%,77%,0.2) 0px, transparent 50%);
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 0;
            color: var(--color-secondary);
        }

        /* --- 2. THE ULTRA-CLEAR GLASS CARD --- */
        .signup-card {
            width: 100%;
            max-width: 480px;
            padding: 2.5rem 2.5rem;

            /* ULTRA TRANSPARENT GLASS EFFECT */
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));

            /* The Blur */
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);

            /* Very subtle borders */
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            border-right: 1px solid rgba(255, 255, 255, 0.1);

            /* Shadow */
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.1);

            border-radius: 24px;

            /* Static Entrance */
            animation: fadeInUp 0.6s ease-out forwards;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Logo & Text */
        .brand-title {
            color: var(--color-secondary);
            font-weight: 800;
            letter-spacing: -0.5px;
            font-size: 1.8rem;
            text-shadow: 0 2px 4px rgba(255,255,255,0.6);
        }
        .logo-icon { color: var(--color-primary); filter: drop-shadow(0 0 5px rgba(0,208,156,0.4)); }

        /* --- 3. INPUTS (Matched Transparency) --- */
        .form-control, .form-select {
            background-color: rgba(255, 255, 255, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 12px;
            padding: 10px 15px;
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--color-secondary);
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            background-color: rgba(255, 255, 255, 0.7);
            box-shadow: 0 0 0 4px rgba(0, 208, 156, 0.15);
            border-color: var(--color-primary);
            z-index: 2;
        }

        .input-group-text {
            background-color: rgba(255, 255, 255, 0.5);
            border-color: rgba(255, 255, 255, 0.3);
        }

        .input-group:focus-within {
            box-shadow: 0 0 0 3px rgba(0, 208, 156, 0.15);
            border-radius: 12px;
        }

        /* Button */
        .btn-brand {
            background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 208, 156, 0.3);
        }
        .btn-brand:hover {
            background: linear-gradient(135deg, var(--color-primary-dark) 0%, var(--color-primary) 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 208, 156, 0.4);
        }

        /* Advisor Box */
        .advisor-box {
            background-color: rgba(0, 208, 156, 0.1);
            border: 1px dashed rgba(0, 208, 156, 0.5);
            border-radius: 16px;
        }

        /* Alert & Links */
        .alert-custom { border-radius: 12px; font-size: 0.9rem; border: none; font-weight: 500; background-color: rgba(254, 226, 226, 0.9); color: #991b1b; }
        a { color: var(--color-primary-dark); font-weight: 700; transition: color 0.2s; text-shadow: 0 1px 0 rgba(255,255,255,0.4); }
        a:hover { color: #008c69; }

    </style>
</head>
<body>

    <div class="signup-card">
        <div class="text-center mb-4">
            <h2 class="brand-title">
                <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
            </h2>
            <p class="text-muted small fw-bold" style="opacity: 0.9;">Start your investment journey today.</p>
        </div>

        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-custom text-center mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i><%= request.getAttribute("error") %>
            </div>
        <% } %>

        <form action="register" method="post" onsubmit="return validateForm()">
            <div class="mb-3">
                <label class="form-label text-muted small fw-bold ms-1">Full Name</label>
                <div class="input-group">
                    <span class="input-group-text border-end-0 rounded-start-4 ps-3"><i class="fa-regular fa-user"></i></span>
                    <input type="text" name="username" class="form-control border-start-0 rounded-end-4 ps-1" required placeholder="User Name">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label text-muted small fw-bold ms-1">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text border-end-0 rounded-start-4 ps-3"><i class="fa-regular fa-envelope"></i></span>
                    <input type="email" name="email" class="form-control border-start-0 rounded-end-4 ps-1" required placeholder="mail@example.com">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label text-muted small fw-bold ms-1">Password</label>
                <div class="input-group">
                    <span class="input-group-text border-end-0 rounded-start-4 ps-3"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" name="password" id="password" class="form-control border-start-0 border-end-0 ps-1" required placeholder="Create a strong password">
                    <span class="input-group-text border-start-0 rounded-end-4 pe-3 text-muted" style="cursor: pointer;" onclick="togglePassword('password', 'toggleIcon1')">
                        <i class="fa-regular fa-eye" id="toggleIcon1"></i>
                    </span>
                </div>
                <div class="form-text ms-1" style="font-size: 0.75rem; color: rgba(44,62,80,0.8);">
                    Min 8 chars, 1 number, 1 symbol (!@#$..)
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label text-muted small fw-bold ms-1">Confirm Password</label>
                <div class="input-group">
                    <span class="input-group-text border-end-0 rounded-start-4 ps-3"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" id="confirmPassword" class="form-control border-start-0 border-end-0 ps-1" required placeholder="Re-enter password">
                    <span class="input-group-text border-start-0 rounded-end-4 pe-3 text-muted" style="cursor: pointer;" onclick="togglePassword('confirmPassword', 'toggleIcon2')">
                        <i class="fa-regular fa-eye" id="toggleIcon2"></i>
                    </span>
                </div>
                <div id="passwordError" class="text-danger small mt-1 ps-1 fw-bold" style="display:none;">
                    <i class="fa-solid fa-triangle-exclamation me-1"></i> Passwords do not match!
                </div>
                <div id="complexityError" class="text-danger small mt-1 ps-1 fw-bold" style="display:none;">
                    <i class="fa-solid fa-triangle-exclamation me-1"></i> Weak password! Use 8+ chars, numbers & symbols.
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-muted small fw-bold ms-1">Select Role</label>
                <div class="input-group">
                    <span class="input-group-text border-end-0 rounded-start-4 ps-3"><i class="fa-solid fa-briefcase"></i></span>
                    <select name="role" id="roleSelect" class="form-select border-start-0 rounded-end-4 ps-1" onchange="toggleAdvisorFields()">
                        <option value="INVESTOR">Investor</option>
                        <option value="ADVISOR">Advisor</option>
                        <%-- REMOVED ADMIN OPTION HERE --%>
                    </select>
                </div>
            </div>

            <div id="advisorFields" style="display: none;" class="mb-4 p-4 advisor-box">
                <h6 class="small fw-bold text-dark mb-3"><i class="fa-solid fa-certificate me-2 text-primary"></i>Professional Credentials</h6>
                <div class="mb-2">
                    <label class="small text-muted fw-bold">Qualification</label>
                    <input type="text" name="qualification" class="form-control form-control-sm" placeholder="e.g. MBA, CFA">
                </div>
                <div class="mb-0">
                    <label class="small text-muted fw-bold">Years of Experience</label>
                    <input type="text" name="experience" class="form-control form-control-sm" placeholder="e.g. 5 Years">
                </div>
            </div>

            <button type="submit" class="btn btn-brand w-100">Create Account</button>
        </form>

        <div class="text-center mt-4">
            <small class="text-muted fw-bold">Already have an account? <a href="signin" class="text-decoration-none">Sign In</a></small>
        </div>
    </div>

    <script>
        // Toggle Password Visibility (Generic Function)
        function togglePassword(inputId, iconId) {
            const inputField = document.getElementById(inputId);
            const icon = document.getElementById(iconId);

            if (inputField.type === 'password') {
                inputField.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                inputField.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Toggle Advisor Box
        function toggleAdvisorFields() {
            var role = document.getElementById("roleSelect").value;
            var fields = document.getElementById("advisorFields");
            var qualInput = document.getElementsByName("qualification")[0];
            var expInput = document.getElementsByName("experience")[0];

            if (role === "ADVISOR") {
                fields.style.display = "block";
                if(qualInput) qualInput.required = true;
                if(expInput) expInput.required = true;
            } else {
                fields.style.display = "none";
                if(qualInput) qualInput.required = false;
                if(expInput) expInput.required = false;
                if(qualInput) qualInput.value = "";
                if(expInput) expInput.value = "";
            }
        }

        // Validate Form with Password Complexity Logic
        function validateForm() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;
            var matchError = document.getElementById("passwordError");
            var complexityError = document.getElementById("complexityError");

            // Reset Errors
            matchError.style.display = "none";
            complexityError.style.display = "none";
            document.getElementById("password").classList.remove("border-danger");
            document.getElementById("confirmPassword").classList.remove("border-danger");

            // 1. Check Matching
            if (password !== confirmPassword) {
                matchError.style.display = "block";
                document.getElementById("confirmPassword").classList.add("border-danger");
                return false;
            }

            // 2. Check Complexity (Regex)
            // Logic: At least 1 number, At least 1 special char, Min 8 chars total
            var strictPattern = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;

            if (!strictPattern.test(password)) {
                complexityError.style.display = "block";
                document.getElementById("password").classList.add("border-danger");
                return false;
            }

            return true;
        }
    </script>
</body>
</html>