<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Sign In | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Branding Variables --- */
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
        }

        /* --- 1. BACKGROUND (Mesh Gradient) --- */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #e0f2fe;
            background-image:
                radial-gradient(at 0% 0%, hsla(165,83%,40%,0.3) 0px, transparent 50%),
                radial-gradient(at 100% 0%, hsla(200,80%,50%,0.3) 0px, transparent 50%),
                radial-gradient(at 100% 100%, hsla(340,100%,76%,0.2) 0px, transparent 50%),
                radial-gradient(at 0% 100%, hsla(22,100%,77%,0.2) 0px, transparent 50%);
            background-attachment: fixed;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--color-secondary);
        }

        /* --- 2. THE TINTED GLASS CARD --- */
        .login-card {
            width: 100%;
            max-width: 420px;
            padding: 3rem 2.5rem;

            /* TINTED GLASS EFFECT */
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);

            /* Glass Borders */
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            border-right: 1px solid rgba(255, 255, 255, 0.1);

            border-radius: 24px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.1);

            /* Static Entrance */
            animation: fadeInUp 0.6s ease-out forwards;
        }

        /* Logo Styling */
        .brand-title {
            color: var(--color-secondary);
            font-weight: 800;
            letter-spacing: -0.5px;
            font-size: 2rem;
            text-shadow: 0 2px 4px rgba(255,255,255,0.6);
        }
        .logo-icon { color: var(--color-primary); filter: drop-shadow(0 0 5px rgba(0,208,156,0.4)); }

        /* --- 3. INPUTS (Matched Transparency) --- */
        .form-control {
            background-color: rgba(255, 255, 255, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 12px;
            padding: 12px 15px;
            font-size: 0.95rem;
            font-weight: 500;
            color: var(--color-secondary);
            transition: all 0.3s ease;
        }

        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.7);
            box-shadow: none;
            border-color: var(--color-primary);
            z-index: 2;
        }

        .input-group-text {
            background-color: rgba(255, 255, 255, 0.5);
            border-color: rgba(255, 255, 255, 0.3);
            color: #6c757d;
        }

        .input-group:focus-within {
            box-shadow: 0 0 0 4px rgba(0, 208, 156, 0.15);
            border-radius: 12px;
        }

        /* Button */
        .btn-brand {
            background: linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%);
            border: none;
            color: white;
            padding: 14px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0, 208, 156, 0.3);
        }
        .btn-brand:hover {
            background: linear-gradient(135deg, var(--color-primary-dark) 0%, var(--color-primary) 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 208, 156, 0.4);
        }

        .alert-custom { border-radius: 12px; font-size: 0.9rem; border: none; font-weight: 500; }
        .alert-success-custom { background-color: rgba(209, 231, 221, 0.9); color: #0f5132; }
        .alert-danger-custom { background-color: rgba(254, 226, 226, 0.9); color: #991b1b; }

        a { color: var(--color-primary-dark); font-weight: 700; transition: color 0.2s; text-shadow: 0 1px 0 rgba(255,255,255,0.4); }
        a:hover { color: #008c69; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="text-center mb-4">
            <h2 class="brand-title">
                <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
            </h2>
            <p class="text-muted small fw-bold" style="opacity: 0.9;">Welcome back! Please login to your account.</p>
        </div>

        <% if (request.getAttribute("success") != null) { %>
            <div class="alert alert-custom alert-success-custom text-center">
                <i class="fa-solid fa-circle-check me-2"></i><%= request.getAttribute("success") %>
            </div>
        <% } %>

        <% if (request.getAttribute("error") != null) { %>
            <div class="alert alert-custom alert-danger-custom text-center">
                <i class="fa-solid fa-circle-exclamation me-2"></i><%= request.getAttribute("error") %>
            </div>
        <% } %>

        <form action="login" method="post">
            <div class="mb-3">
                <label class="form-label text-muted small fw-bold ms-1">Email or Username</label>
                <div class="input-group">
                    <span class="input-group-text border-end-0 rounded-start-4 ps-3"><i class="fa-regular fa-envelope"></i></span>
                    <input type="text" name="email" class="form-control border-start-0 rounded-end-4 ps-1" required placeholder="name@example.com">
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-muted small fw-bold ms-1">Password</label>
                <div class="input-group">
                    <span class="input-group-text border-end-0 rounded-start-4 ps-3"><i class="fa-solid fa-lock"></i></span>

                    <input type="password" name="password" id="passwordInput" class="form-control border-start-0 border-end-0 ps-1" required placeholder="••••••••">

                    <span class="input-group-text border-start-0 rounded-end-4 pe-3 text-muted" style="cursor: pointer;" onclick="togglePassword()">
                        <i class="fa-regular fa-eye" id="toggleIcon"></i>
                    </span>
                </div>
            </div>

            <button type="submit" class="btn btn-brand w-100">Sign In</button>
        </form>

        <div class="text-center mt-4">
            <small class="text-muted fw-bold">Don't have an account? <a href="signup" class="text-decoration-none">Create Account</a></small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('passwordInput');
            const toggleIcon = document.getElementById('toggleIcon');

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>