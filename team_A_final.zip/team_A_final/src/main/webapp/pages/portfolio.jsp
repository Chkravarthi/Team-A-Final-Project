<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Portfolio | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
    .modal {
        z-index: 1060 !important; /* Forces modal to the very front */
    }
    .modal-backdrop {
        z-index: 1050 !important; /* Forces the dark background behind the modal */
    }
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
            --bg-light: #f4fcfb;
            --glass-bg: rgba(255, 255, 255, 0.95);
        }

        body { font-family: 'Poppins', sans-serif; background-color: var(--bg-light); color: var(--color-secondary); }

        /* --- Navbar --- */
        .navbar-custom { background: var(--glass-bg); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(0,0,0,0.05); padding: 15px 0; }
        .navbar-brand { font-weight: 800; font-size: 1.5rem; color: var(--color-secondary) !important; letter-spacing: -0.5px; }
        .logo-icon { color: var(--color-primary); }

        .nav-link-custom { color: #64748b; font-weight: 600; padding: 8px 16px; border-radius: 50px; transition: 0.3s; text-decoration: none; font-size: 0.95rem; }
        .nav-link-custom:hover { color: var(--color-primary); background: rgba(0, 208, 156, 0.05); }
        .nav-link-custom.active { background-color: var(--color-primary); color: white; box-shadow: 0 4px 12px rgba(0, 208, 156, 0.3); }

        /* --- Portfolio Cards --- */
        .portfolio-card { border: none; border-radius: 24px; background: #fff; transition: all 0.3s ease; height: 100%; box-shadow: 0 10px 30px rgba(0,0,0,0.03); display: flex; flex-direction: column; justify-content: space-between; position: relative; overflow: hidden; }
        .portfolio-card:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(0,0,0,0.08); }
        .icon-box { width: 50px; height: 50px; border-radius: 16px; background: #f0fdf9; color: var(--color-primary); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; }

        /* --- Progress Bars --- */
        .progress-custom { height: 8px; border-radius: 10px; background-color: #f1f5f9; margin-top: 10px; overflow: hidden; }
        .progress-bar-custom { background-color: var(--color-primary); border-radius: 10px; transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1); }

        /* --- Buttons --- */
        .btn-brand { background: var(--color-primary); color: white; border: none; font-weight: 600; border-radius: 50px; padding: 10px 24px; transition: all 0.2s; }
        .btn-brand:hover { background: var(--color-primary-dark); color: white; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 208, 156, 0.3); }
        .btn-outline-brand { border: 2px solid var(--color-primary); color: var(--color-primary); font-weight: 600; border-radius: 50px; padding: 8px 20px; background: transparent; transition: all 0.2s; }
        .btn-outline-brand:hover { background: var(--color-primary); color: white; }

        /* --- Modals & Forms --- */
        .modal-content { border-radius: 24px; border: none; }
        .form-control, .form-select { border-radius: 12px; padding: 12px; background-color: #f8fafc; border: 1px solid #e2e8f0; }
        .form-control:focus { border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(0,208,156,0.1); }
        .status-pill { font-size: 0.75rem; font-weight: 700; padding: 6px 12px; border-radius: 30px; letter-spacing: 0.5px; text-transform: uppercase; }
    </style>
</head>
<body>

    <nav class="navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a class="navbar-brand me-5" href="welcome">
                    <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
                </a>
                <div class="d-none d-lg-flex gap-2">
                    <a href="welcome" class="nav-link-custom"><i class="fa-solid fa-house me-1"></i> Dashboard</a>
                    <a href="portfolio" class="nav-link-custom active"><i class="fa-solid fa-briefcase me-1"></i> Portfolio</a>
                    <a href="assets" class="nav-link-custom"><i class="fa-solid fa-coins me-1"></i> Assets</a>
                    <c:if test="${sessionScope.role != 'ADVISOR'}">
                        <a href="transaction" class="nav-link-custom"><i class="fa-solid fa-right-left me-1"></i> Transactions</a>
                    </c:if>
                    <a href="analytics" class="nav-link-custom"><i class="fa-solid fa-chart-pie me-1"></i> Analytics</a>
                </div>
            </div>

            <div class="dropdown">
                <div class="bg-white border rounded-pill px-3 py-1 shadow-sm d-flex align-items-center" style="cursor: pointer;" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=${sessionScope.userName}&background=00d09c&color=fff" class="rounded-circle me-2" width="32">
                    <span class="small fw-bold text-dark">${sessionScope.userName}</span>
                    <i class="fa-solid fa-chevron-down ms-2 text-muted" style="font-size: 0.7rem;"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 p-2 rounded-4">
                    <li class="dropdown-item small text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">${sessionScope.role} Account</li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger fw-bold rounded-3" href="logout"><i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <c:choose>
            <%-- VIEW 1: INVESTOR LIST (For Admin/Advisor) --%>
            <c:when test="${viewMode == 'INVESTOR_LIST'}">
                <div class="mb-5">
                    <h2 class="fw-bold text-dark">Client Overview</h2>
                    <p class="text-muted">Select an investor to view their active portfolios.</p>
                </div>
                <div class="row g-4">
                    <c:forEach var="u" items="${investorList}">
                        <div class="col-md-6 col-lg-4">
                            <a href="portfolio?investorId=${u.id}" class="text-decoration-none">
                                <div class="portfolio-card p-4">
                                    <div class="d-flex align-items-center gap-3 mb-4">
                                        <img src="https://ui-avatars.com/api/?name=${u.username}&background=random&color=fff" class="rounded-circle shadow-sm" width="55">
                                        <div>
                                            <h5 class="fw-bold text-dark mb-0">${u.username}</h5>
                                            <span class="badge bg-light text-muted border rounded-pill">ID: #${u.id}</span>
                                        </div>
                                    </div>
                                    <div class="mt-auto">
                                        <div class="d-flex justify-content-between align-items-center bg-light rounded-4 p-3 border">
                                            <span class="fw-bold text-secondary"><i class="fa-solid fa-bullseye me-2 text-primary"></i>Active Goals</span>
                                            <span class="badge bg-dark rounded-pill px-3">${portfolioCounts[u.id]}</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </c:forEach>
                </div>
            </c:when>

            <%-- VIEW 2: PORTFOLIO LIST (Detail View) --%>
            <c:otherwise>
                <div class="d-flex justify-content-between align-items-center mb-5">
                    <div>
                        <h2 class="fw-bold">
                            <c:choose>
                                <c:when test="${sessionScope.role == 'INVESTOR'}">My Goals</c:when>
                                <c:otherwise><span style="color:var(--color-primary);">${viewingName}'s</span> Goals</c:otherwise>
                            </c:choose>
                        </h2>
                    </div>
                    <div class="d-flex gap-2">
                        <c:if test="${sessionScope.role != 'INVESTOR'}">
                            <a href="portfolio" class="btn btn-light border rounded-pill fw-bold px-3"><i class="fa-solid fa-arrow-left me-2"></i> Back</a>
                        </c:if>
                        <c:if test="${sessionScope.role == 'INVESTOR'}">
                            <button class="btn btn-brand shadow-sm" data-bs-toggle="modal" data-bs-target="#createPortfolioModal"><i class="fa-solid fa-plus me-2"></i>New Goal</button>
                        </c:if>
                    </div>
                </div>

                <div class="row g-4">
                    <c:forEach var="p" items="${portfolioList}">
                        <div class="col-md-4">
                            <div class="portfolio-card p-4">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="d-flex gap-3 align-items-center">
                                        <div class="icon-box"><i class="fa-solid fa-bullseye"></i></div>
                                        <div>
                                            <h5 class="fw-bold mb-0 text-dark">${p.portfolioName}</h5>
                                            <span class="status-pill bg-light text-muted border mt-1 d-inline-block">${p.riskLevel} Risk</span>
                                        </div>
                                    </div>
                                   <div class="d-flex gap-1">
                                       <c:if test="${sessionScope.role == 'INVESTOR'}">
                                           <button class="btn btn-light btn-sm rounded-circle border"
                                                   onclick="openEditModal('${p.portfolioId}', '${p.portfolioName}', '${p.totalValue}', '${p.riskLevel}')">
                                               <i class="fa-solid fa-pen text-muted" style="font-size: 0.8rem;"></i>
                                           </button>
                                       </c:if>

                                       <c:if test="${sessionScope.role == 'INVESTOR' || sessionScope.role == 'ADMIN'}">
                                           <button class="btn btn-light btn-sm rounded-circle border border-danger-subtle"
                                                   onclick="confirmDelete('${p.portfolioId}', '${p.portfolioName}')">
                                               <i class="fa-solid fa-trash text-danger" style="font-size: 0.8rem;"></i>
                                           </button>
                                       </c:if>
                                   </div>
                                </div>

                                <div class="row mb-3 g-2">
                                    <div class="col-6">
                                        <small class="text-muted d-block fw-bold" style="font-size: 0.7rem;">INVESTED</small>
                                        <h6 class="fw-bold mb-0">₹<span id="inv-${p.portfolioId}"><fmt:formatNumber value="${p.investedAmount}" maxFractionDigits="0"/></span></h6>
                                    </div>
                                    <div class="col-6">
                                        <small class="text-muted d-block fw-bold" style="font-size: 0.7rem;">CURRENT</small>
                                        <h6 class="fw-bold mb-0">₹<span id="val-${p.portfolioId}"><fmt:formatNumber value="${p.liveValue}" maxFractionDigits="0"/></span></h6>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <span id="badge-${p.portfolioId}" class="badge ${p.profitLossPct >= 0 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} rounded-pill px-3 py-2 fw-bold w-100 d-flex justify-content-between align-items-center">
                                        <span class="small text-uppercase">Returns</span>
                                        <span><i class="fa-solid ${p.profitLossPct >= 0 ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down'} me-1"></i><span id="pl-${p.portfolioId}"><fmt:formatNumber value="${p.profitLossPct}" maxFractionDigits="2"/></span>%</span>
                                    </span>
                                </div>

                                <div class="mb-4">
                                    <div class="d-flex justify-content-between small fw-bold mb-1">
                                        <span class="text-muted">Goal Progress</span>
                                        <span class="text-primary"><span id="pct-${p.portfolioId}"><fmt:formatNumber value="${p.growthPct}" maxFractionDigits="1"/></span>%</span>
                                    </div>
                                    <div class="progress progress-custom">
                                        <div id="bar-${p.portfolioId}" class="progress-bar progress-bar-custom" style="width: ${p.growthPct > 100 ? 100 : p.growthPct}%"></div>
                                    </div>
                                </div>

                                <div class="d-grid mt-auto">
                                    <a href="assets?portfolioId=${p.portfolioId}" class="btn btn-outline-brand rounded-pill">View Assets</a>
                                </div>
                            </div>
                        </div>
                    </c:forEach>
                </div>
                <input type="hidden" id="liveQueryId" value="${param.investorId}">
            </c:otherwise>
        </c:choose>
    </div>

    <%-- MODALS SECTION --%>
        <c:if test="${sessionScope.role == 'INVESTOR'}">
            <div class="modal fade" id="createPortfolioModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content p-4">
                        <div class="modal-header border-0 px-0 pt-0"><h4 class="fw-bold">New Goal</h4><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                        <form action="portfolio/add" method="post">
                            <div class="modal-body px-0">
                                <label class="small fw-bold text-muted mb-1">Goal Name</label>
                                <%-- UPDATED: name="portfolioName" to match Bean --%>
                                <input type="text" name="portfolioName" class="form-control mb-3" placeholder="e.g. Retirement Fund" required>
                                <label class="small fw-bold text-muted mb-1">Target Amount (₹)</label>
                                <%-- UPDATED: name="totalValue" to match Bean --%>
                                <input type="number" step="0.01" name="totalValue" class="form-control mb-3" required>
                                <label class="small fw-bold text-muted mb-1">Risk Profile</label>
                                <%-- UPDATED: name="riskLevel" to match Bean --%>
                                <select name="riskLevel" class="form-select mb-3"><option value="LOW">Low Risk</option><option value="MEDIUM">Medium Risk</option><option value="HIGH">High Risk</option></select>
                            </div>
                            <button type="submit" class="btn btn-brand w-100 py-2">Create Goal</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="editPortfolioModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content p-4">
                        <div class="modal-header border-0 px-0 pt-0"><h4 class="fw-bold">Edit Goal</h4><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                        <form action="portfolio/edit" method="post">
                            <div class="modal-body px-0">
                                <input type="hidden" name="portfolioId" id="editId">
                                <label class="small fw-bold text-muted mb-1">Goal Name</label>
                                <%-- UPDATED: name="portfolioName" --%>
                                <input type="text" name="portfolioName" id="editName" class="form-control mb-3" required>
                                <label class="small fw-bold text-muted mb-1">Target Amount (₹)</label>
                                <%-- UPDATED: name="totalValue" --%>
                                <input type="number" step="0.01" name="totalValue" id="editValue" class="form-control mb-3" required>
                                <label class="small fw-bold text-muted mb-1">Risk Profile</label>
                                <%-- UPDATED: name="riskLevel" --%>
                                <select name="riskLevel" id="editRisk" class="form-select mb-3"><option value="LOW">Low</option><option value="MEDIUM">Medium</option><option value="HIGH">High</option></select>
                            </div>
                            <button type="submit" class="btn btn-dark w-100 rounded-pill fw-bold">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </c:if>

        <div class="modal fade" id="deletePortfolioModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content p-4">
                    <div class="modal-header border-0 px-0 pt-0"><h5 class="fw-bold">Delete Goal?</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body px-0">
                        <p class="text-muted">Are you sure you want to delete <strong id="deletePName" class="text-dark"></strong>? All linked data will be removed.</p>
                    </div>
                    <form id="deleteForm" action="portfolio/delete" method="post" class="d-flex gap-2">
                        <input type="hidden" name="portfolioId" id="deletePId">
                        <button type="button" class="btn btn-light w-100 fw-bold rounded-pill" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger w-100 fw-bold rounded-pill">Delete</button>
                    </form>
                </div>
            </div>
        </div>

       <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

       <script>
               // Modal Handlers
               const editEl = document.getElementById('editPortfolioModal');
               const editModal = editEl ? new bootstrap.Modal(editEl) : null;
               const deleteModal = new bootstrap.Modal(document.getElementById('deletePortfolioModal'));

               function openEditModal(id, name, value, risk) {
                   if(editModal) {
                       document.getElementById('editId').value = id;
                       document.getElementById('editName').value = name;
                       document.getElementById('editValue').value = value;
                       document.getElementById('editRisk').value = risk;
                       editModal.show();
                   }
               }

               function confirmDelete(id, name) {
                   document.getElementById('deletePId').value = id;
                   document.getElementById('deletePName').innerHTML =
                       `<span class="text-danger">"` + name + `"</span><br>` +
                       `<small class="text-muted">Warning: Deleting this goal will permanently remove all linked history and data.</small>`;

                   const userRole = "${sessionScope.role}";
                   const form = document.getElementById('deleteForm');
                   form.action = (userRole === 'ADMIN') ? "admin/portfolio/delete" : "portfolio/delete";
                   deleteModal.show();
               }

               // Live Price Updates
               if (document.querySelector('.portfolio-card')) {
                   setInterval(() => {
                       let url = '/api/portfolio-updates';
                       const qId = document.getElementById('liveQueryId');
                       if(qId && qId.value) url += '?investorId=' + qId.value;

                       fetch(url).then(res => res.json()).then(data => {
                           data.forEach(item => {
                               const valEl = document.getElementById('val-' + item.id);
                               if (valEl) valEl.innerText = item.value;
                               const pctEl = document.getElementById('pct-' + item.id);
                               if (pctEl) pctEl.innerText = item.progress;
                               const barEl = document.getElementById('bar-' + item.id);
                               if (barEl) barEl.style.width = item.progress + '%';
                               const plEl = document.getElementById('pl-' + item.id);
                               const badgeEl = document.getElementById('badge-' + item.id);
                               if (plEl && badgeEl) {
                                   const plVal = parseFloat(item.pl);
                                   plEl.innerText = plVal.toFixed(2);
                                   badgeEl.className = (plVal >= 0) ? "badge bg-success-subtle text-success rounded-pill px-3 py-2 fw-bold w-100 d-flex justify-content-between align-items-center" : "badge bg-danger-subtle text-danger rounded-pill px-3 py-2 fw-bold w-100 d-flex justify-content-between align-items-center";
                                   badgeEl.querySelector('i').className = (plVal >= 0) ? "fa-solid fa-arrow-trend-up me-1" : "fa-solid fa-arrow-trend-down me-1";
                               }
                           });
                       }).catch(() => {});
                   }, 3000);
               }

               document.addEventListener("DOMContentLoaded", function() {
                   // Combined Error Logic for Deletion Blocked AND Validation Errors
                   const errorPopup = "${errorPopup}";
                   if (errorPopup && errorPopup.trim() !== "" && errorPopup !== "null") {
                       Swal.fire({
                           icon: 'error',
                           title: 'Action Blocked',
                           text: errorPopup,
                           confirmButtonColor: '#d33'
                       });
                   }

                   // Corrected Success Message logic to match Controller Attribute "successPopup"
                   const successPopup = "${successPopup}";
                   if (successPopup && successPopup.trim() !== "" && successPopup !== "null") {
                       Swal.fire({
                           icon: 'success',
                           title: 'Success!',
                           text: successPopup,
                           timer: 3000,
                           showConfirmButton: false
                       });
                   }
               });
           </script>
       </body>
       </html>