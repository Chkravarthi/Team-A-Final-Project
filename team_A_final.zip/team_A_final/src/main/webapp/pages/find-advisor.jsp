<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Find Advisor | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Branding Variables --- */
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
            --bg-light: #f4fcfb;
            --glass-bg: rgba(255, 255, 255, 0.95);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--color-secondary);
        }

        /* --- Navbar --- */
        .navbar-custom {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 15px 0;
        }
        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            color: var(--color-secondary) !important;
            letter-spacing: -0.5px;
        }
        .logo-icon { color: var(--color-primary); }

        .nav-link-custom {
            color: #64748b;
            font-weight: 600;
            padding: 8px 20px;
            border-radius: 50px;
            transition: 0.3s;
            text-decoration: none;
            font-size: 0.9rem;
            background: rgba(0, 208, 156, 0.05);
        }
        .nav-link-custom:hover { color: var(--color-primary); background: rgba(0, 208, 156, 0.1); }

        /* --- Advisor Cards --- */
        .advisor-card {
            border: none;
            border-radius: 24px;
            background: #fff;
            padding: 30px 20px;
            transition: all 0.3s ease;
            height: 100%;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .advisor-card:hover { transform: translateY(-8px); box-shadow: 0 20px 40px rgba(0,0,0,0.08); border: 1px solid var(--color-primary); }

        .avatar-img { width: 90px; height: 90px; border-radius: 50%; object-fit: cover; margin-bottom: 15px; border: 4px solid #f8fafc; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }

        /* --- Buttons & Badges --- */
        .btn-brand {
            background: var(--color-primary);
            color: white;
            border: none;
            font-weight: 600;
            border-radius: 50px;
            padding: 10px 24px;
            transition: all 0.2s;
            width: 100%;
        }
        .btn-brand:hover { background: var(--color-primary-dark); color: white; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 208, 156, 0.3); }

        .btn-disabled {
            background: #e2e8f0;
            color: #94a3b8;
            border: none;
            border-radius: 50px;
            padding: 10px 24px;
            width: 100%;
            font-weight: 600;
            cursor: not-allowed;
        }

        .alert-custom { border-radius: 12px; font-size: 0.9rem; border: none; font-weight: 500; background-color: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>

    <nav class="navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <a class="navbar-brand" href="welcome">
                <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
            </a>
            <a href="welcome" class="nav-link-custom">
                <i class="fa-solid fa-arrow-left me-1"></i> Dashboard
            </a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="text-center mb-5">
            <h1 class="fw-bold display-6 mb-2 text-dark">Expert Advisors</h1>
            <p class="text-muted">Connect with certified professionals to boost your portfolio.</p>

            <c:if test="${param.error eq 'AlreadyConnected'}">
                <div class="alert alert-custom d-inline-block mt-3 px-4 shadow-sm">
                    <i class="fa-solid fa-circle-exclamation me-2"></i> You are already connected to an Advisor!
                </div>
            </c:if>
        </div>

        <div class="row g-4 justify-content-center">
            <c:forEach var="advisor" items="${advisorList}">
                <div class="col-md-6 col-lg-4">
                    <div class="advisor-card">

                        <img src="https://ui-avatars.com/api/?name=${advisor.username}&background=00d09c&color=fff&size=128" class="avatar-img" alt="${advisor.username}">

                        <h4 class="fw-bold mb-1 text-dark">${advisor.username}</h4>
                        <p class="text-muted small mb-3">${advisor.email}</p>

                        <div class="badge bg-light text-primary mb-4 py-2 px-3 rounded-pill border">
                            <i class="fa-solid fa-certificate me-1"></i> Certified Expert
                        </div>

                        <div class="mt-auto w-100">
                            <c:choose>

                                <%-- 1. I am ACTIVE with THIS Advisor --%>
                                <c:when test="${myStatus == 'ACTIVE' && myAdvisorId == advisor.userId}">
                                    <button class="btn btn-success w-100 fw-bold py-2 rounded-pill shadow-sm" disabled style="opacity:1;">
                                        <i class="fa-solid fa-circle-check me-2"></i> Connected
                                    </button>
                                </c:when>

                                <%-- 2. I am ACTIVE with SOMEONE ELSE --%>
                                <c:when test="${myStatus == 'ACTIVE'}">
                                    <button class="btn-disabled">
                                        Advisor Assigned
                                    </button>
                                </c:when>

                                <%-- 3. Request is PENDING for THIS Advisor --%>
                                <c:when test="${myStatus == 'PENDING' && myAdvisorId == advisor.userId}">
                                    <button class="btn btn-warning w-100 fw-bold py-2 text-dark rounded-pill border border-warning-subtle" disabled>
                                        <i class="fa-solid fa-clock me-2"></i> Request Sent
                                    </button>
                                </c:when>

                                <%-- 4. Request is PENDING for someone else --%>
                                <c:when test="${myStatus == 'PENDING'}">
                                    <button class="btn-disabled">
                                        Pending Approval
                                    </button>
                                </c:when>

                                <%-- 5. No Advisor, Free to Connect --%>
                                <c:otherwise>
                                    <form action="select-advisor" method="post">
                                        <input type="hidden" name="advisorId" value="${advisor.userId}">
                                        <button type="submit" class="btn btn-brand">
                                            Connect Now
                                        </button>
                                    </form>
                                </c:otherwise>

                            </c:choose>
                        </div>
                    </div>
                </div>
            </c:forEach>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>