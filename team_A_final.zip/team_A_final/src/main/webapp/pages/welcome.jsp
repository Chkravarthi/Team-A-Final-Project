
​<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Dashboard | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- Branding Variables --- */
        :root {
            --color-primary: #00d09c;
            --color-primary-dark: #00a87d;
            --color-secondary: #2c3e50;
            --bg-light: #f4fcfb;
            --glass-bg: rgba(255, 255, 255, 0.95);
            /* Added Danger Colors to match theme */
            --color-danger: #ef4444;
            --color-danger-dark: #dc2626;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--color-secondary);
        }

        /* --- Navbar --- */
        .navbar-custom {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding: 15px 0;
        }
        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            color: var(--color-secondary) !important;
            letter-spacing: -0.5px;
        }
        .logo-icon { color: var(--color-primary); }

        .nav-link-custom {
            color: #64748b;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 50px;
            transition: 0.3s;
            text-decoration: none;
            font-size: 0.95rem;
        }
        .nav-link-custom:hover { color: var(--color-primary); background: rgba(0, 208, 156, 0.05); }
        .nav-link-custom.active {
            background-color: var(--color-primary);
            color: white;
            box-shadow: 0 4px 12px rgba(0, 208, 156, 0.3);
        }

        /* --- Cards & Containers --- */
        .card-pro {
            border: none;
            border-radius: 20px;
            background: #fff;
            box-shadow: 0 10px 30px rgba(0,0,0,0.03);
            transition: transform 0.3s ease;
        }
        .hover-card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(0,0,0,0.08); cursor: pointer; }

        /* --- Hero Section --- */
        .grad-hero {
            background: linear-gradient(135deg, var(--color-secondary) 0%, #1e293b 100%);
            color: white;
            position: relative;
            overflow: hidden;
        }
        .grad-hero::before {
            content: "";
            position: absolute;
            top: -50%; right: -20%;
            width: 300px; height: 300px;
            background: radial-gradient(circle, var(--color-primary) 0%, transparent 70%);
            opacity: 0.15;
        }

        /* --- Buttons --- */
        .btn-brand {
            background: var(--color-primary);
            color: white;
            border: none;
            font-weight: 600;
            border-radius: 50px;
            padding: 10px 24px;
            transition: all 0.2s;
        }
        .btn-brand:hover { background: var(--color-primary-dark); color: white; transform: translateY(-2px); }

        /* --- NEW: Custom Reject Button (Matches btn-brand exactly) --- */
        .btn-reject {
            background: var(--color-danger);
            color: white;
            border: none;
            font-weight: 600;
            border-radius: 50px;
            padding: 10px 24px;
            transition: all 0.2s;
        }
        .btn-reject:hover { background: var(--color-danger-dark); color: white; transform: translateY(-2px); }

        .btn-light-custom {
            background: rgba(255,255,255,0.1);
            color: white;
            border: 1px solid rgba(255,255,255,0.2);
            backdrop-filter: blur(5px);
            border-radius: 50px;
            padding: 10px 20px;
            font-weight: 600;
        }
        .btn-light-custom:hover { background: white; color: var(--color-secondary); }

        /* --- Utilities --- */
        .animate-fade { animation: fadeIn 0.8s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

        .status-badge { font-size: 0.75rem; font-weight: 700; padding: 6px 12px; border-radius: 30px; letter-spacing: 0.5px; text-transform: uppercase; }

        /* Modal Styling */
        .modal-content { border-radius: 24px; border: none; }
        .modal-header { border-bottom: 1px solid rgba(0,0,0,0.05); }
        .form-control, .form-select { border-radius: 12px; padding: 12px; background-color: #f8fafc; border: 1px solid #e2e8f0; }
        .form-control:focus { border-color: var(--color-primary); box-shadow: 0 0 0 3px rgba(0,208,156,0.1); }
    </style>
</head>
<body>

    <nav class="navbar-custom sticky-top">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <a class="navbar-brand me-5" href="welcome">
                    <i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore
                </a>
                <div class="d-none d-lg-flex gap-2">
                    <a href="welcome" class="nav-link-custom active"><i class="fa-solid fa-house me-1"></i> Dashboard</a>
                    <a href="portfolio" class="nav-link-custom"><i class="fa-solid fa-briefcase me-1"></i> Portfolio</a>
                    <a href="assets" class="nav-link-custom"><i class="fa-solid fa-coins me-1"></i> Assets</a>

                    <c:if test="${sessionScope.role != 'ADVISOR'}">
                        <a href="transaction" class="nav-link-custom"><i class="fa-solid fa-right-left me-1"></i> Transactions</a>
                    </c:if>

                    <a href="analytics" class="nav-link-custom"><i class="fa-solid fa-chart-pie me-1"></i> Analytics</a>
                </div>
            </div>

            <div class="dropdown">
                <div class="bg-white border rounded-pill px-3 py-1 shadow-sm d-flex align-items-center" style="cursor: pointer;" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=${sessionScope.userName}&background=00d09c&color=fff" class="rounded-circle me-2" width="32">
                    <span class="small fw-bold text-dark">${sessionScope.userName}</span>
                    <i class="fa-solid fa-chevron-down ms-2 text-muted" style="font-size: 0.7rem;"></i>
                </div>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 p-2 rounded-4">
                    <li class="dropdown-item small text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">${sessionScope.role} Account</li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger fw-bold rounded-3" href="logout"><i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-5 animate-fade">

        <c:if test="${sessionScope.role == 'INVESTOR'}">
            <div class="row g-4 mb-5">
                <div class="col-lg-8">
                    <div class="card-pro grad-hero p-5 h-100">
                        <div class="position-relative z-1">
                            <h1 class="fw-bold mb-3">Welcome, ${sessionScope.userName}</h1>
                            <p class="opacity-75 fs-5 fw-light">Your financial growth journey continues here.</p>
                            <div class="d-flex gap-3 mt-4">
                                <a href="portfolio" class="btn btn-brand shadow-lg">Manage Wealth</a>
                                <button class="btn btn-light-custom" data-bs-toggle="modal" data-bs-target="#ticketModal">
                                    <i class="fa-solid fa-ticket me-2"></i>Support Ticket
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card-pro p-4 h-100 text-center border d-flex flex-column justify-content-center">
                        <h6 class="fw-bold text-muted small text-uppercase mb-4">Dedicated Advisor</h6>
                        <c:choose>
                            <c:when test="${user.connectionStatus == 'ACTIVE'}">
                                <div class="mb-3 position-relative d-inline-block">
                                    <img src="https://ui-avatars.com/api/?name=${advisorName}&background=f0fdf9&color=00d09c&bold=true" class="rounded-circle border border-3 border-white shadow-sm" width="80">
                                    <span class="position-absolute bottom-0 end-0 bg-success border border-white rounded-circle p-2"></span>
                                </div>
                                <h5 class="fw-bold mb-1">${advisorName}</h5>
                                <span class="status-badge bg-success-subtle text-success">Connected</span>
                            </c:when>
                            <c:when test="${user.connectionStatus == 'PENDING'}">
                                <div class="py-3">
                                    <div class="bg-warning-subtle rounded-circle d-inline-flex p-3 mb-3">
                                        <i class="fa-solid fa-clock fs-2 text-warning-emphasis"></i>
                                    </div>
                                    <h6 class="text-warning fw-bold">Connection Pending</h6>
                                </div>
                            </c:when>
                            <c:otherwise>
                                <div class="py-3">
                                    <div class="bg-light rounded-circle d-inline-flex p-3 mb-3">
                                        <i class="fa-solid fa-user-plus fs-2 text-secondary opacity-25"></i>
                                    </div>
                                    <h6 class="text-muted mb-3">No advisor connected</h6>
                                    <button class="btn btn-outline-dark rounded-pill fw-bold w-100 btn-sm" data-bs-toggle="modal" data-bs-target="#expertModal">Find Expert</button>
                                </div>
                            </c:otherwise>
                        </c:choose>
                    </div>
                </div>
            </div>

            <c:if test="${not empty myTickets}">
                <div class="card-pro p-4 mb-5">
                    <h5 class="fw-bold mb-4"><i class="fa-solid fa-clock-rotate-left me-2 text-primary"></i>Support History</h5>
                    <div class="table-responsive">
                        <table class="table align-middle table-hover">
                            <thead class="text-muted small text-uppercase bg-light rounded-3"><tr><th class="ps-3 py-3 rounded-start-3">Status</th><th>Type</th><th class="rounded-end-3">Description</th></tr></thead>
                            <tbody>
                                <c:forEach var="t" items="${myTickets}">
                                    <tr>
                                        <td class="ps-3"><span class="status-badge ${t.status == 'OPEN' ? 'bg-warning-subtle text-warning-emphasis' : 'bg-success-subtle text-success'}">${t.status}</span></td>
                                        <td class="fw-bold small text-dark">${t.requestType}</td>
                                        <td class="text-muted small">${t.description}</td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </div>
            </c:if>

            <div class="modal fade" id="ticketModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content p-4">
                        <div class="modal-header pt-0"><h5 class="fw-bold">New Support Request</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                        <div class="modal-body">
                            <form action="ticket/raise" method="post">
                                <div class="mb-3">
                                    <label class="small fw-bold text-muted mb-1">Issue Type</label>
                                    <select name="requestType" class="form-select fw-bold text-secondary">
                                        <option value="DISCONNECT_ADVISOR">Disconnect Current Advisor</option>
                                        <option value="GENERAL_QUERY">General Inquiry / Bug Report</option>
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="small fw-bold text-muted mb-1">Description</label>
                                    <textarea name="description" class="form-control" rows="3" placeholder="Describe your issue..." required></textarea>
                                </div>
                                <button type="submit" class="btn btn-brand w-100 py-3">Submit Ticket</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="expertModal" tabindex="-1">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="fw-bold"><i class="fa-solid fa-magnifying-glass me-2 text-primary"></i>Find Your Expert</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body p-4 bg-light">
                            <c:forEach var="adv" items="${advisorList}">
                                <div class="card-pro p-3 mb-3 hover-card">
                                    <div class="row align-items-center">
                                        <div class="col-md-4 d-flex align-items-center">
                                            <img src="https://ui-avatars.com/api/?name=${adv.username}&background=random" class="rounded-circle me-3" width="50">
                                            <div>
                                                <h6 class="fw-bold mb-0 text-dark">${adv.username}</h6>
                                                <small class="text-muted">${adv.email}</small>
                                            </div>
                                        </div>
                                        <div class="col-md-5 my-2 my-md-0 border-start border-end px-3">
                                            <div class="d-flex justify-content-between">
                                                <div class="text-center">
                                                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size:0.7rem;">Qualification</small>
                                                    <span class="fw-bold text-primary">${not empty adv.qualification ? adv.qualification : 'N/A'}</span>
                                                </div>
                                                <div class="text-center">
                                                    <small class="text-muted d-block text-uppercase fw-bold" style="font-size:0.7rem;">Experience</small>
                                                    <span class="fw-bold text-dark">${not empty adv.experience ? adv.experience : 'N/A'}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 text-end">
                                            <form action="connect-advisor" method="post">
                                                <input type="hidden" name="advisorId" value="${adv.userId}">
                                                <button class="btn btn-dark rounded-pill fw-bold w-100">Connect</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </c:forEach>
                        </div>
                    </div>
                </div>
            </div>
        </c:if>

        <c:if test="${sessionScope.role == 'ADVISOR'}">
            <c:if test="${not empty pendingRequests}">
                <div class="card-pro p-4 mb-4 border border-warning border-opacity-50 bg-warning-subtle">
                    <h5 class="fw-bold mb-3 text-warning-emphasis"><i class="fa-solid fa-bell me-2"></i>New Client Requests</h5>
                    <c:forEach var="req" items="${pendingRequests}">
                        <div class="bg-white p-3 rounded-4 d-flex justify-content-between align-items-center mb-2 shadow-sm">
                            <div class="d-flex align-items-center">
                                <div class="bg-light rounded-circle d-flex align-items-center justify-content-center me-3" style="width:45px; height:45px;">
                                    <i class="fa-solid fa-user text-muted"></i>
                                </div>
                                <div>
                                    <span class="fw-bold d-block text-dark">${req.username}</span>
                                    <small class="text-muted">Requesting connection</small>
                                </div>
                            </div>
                            <div class="d-flex gap-2">
                                <form action="advisor/accept" method="post">
                                    <input type="hidden" name="investorId" value="${req.userId}">
                                    <button class="btn btn-brand btn-sm shadow-sm px-3">Accept</button>
                                </form>
                                <form action="advisor/decline" method="post">
                                    <input type="hidden" name="investorId" value="${req.userId}">
                                    <button class="btn btn-reject btn-sm shadow-sm px-3">Decline</button>
                                </form>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </c:if>

            <h4 class="fw-bold mb-4">Your Active Clients</h4>
            <div class="card-pro p-4">
                <table class="table align-middle">
                    <thead class="text-muted small text-uppercase bg-light"><tr><th class="ps-3 py-3 rounded-start-3">Client Name</th><th>Email</th><th class="text-end pe-3 rounded-end-3">Action</th></tr></thead>
                    <tbody>
                        <c:forEach var="client" items="${myClients}">
                            <tr>
                                <td class="ps-3 fw-bold text-dark">${client.username}</td>
                                <td class="text-muted">${client.email}</td>
                                <td class="text-end pe-3">
                                    <a href="portfolio?investorId=${client.userId}" class="btn btn-outline-dark btn-sm rounded-pill px-4 fw-bold">Analyze Assets</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </c:if>

        <c:if test="${sessionScope.role == 'ADMIN'}">

            <c:if test="${not empty pendingAdvisors}">
                <div class="card-pro p-4 mb-4 border border-warning border-opacity-25 bg-warning-subtle">
                    <div class="d-flex align-items-center mb-3">
                        <i class="fa-solid fa-shield-halved fs-4 text-warning-emphasis me-2"></i>
                        <h5 class="fw-bold text-warning-emphasis mb-0">Advisor Verifications</h5>
                    </div>
                    <div class="bg-white rounded-4 p-3 shadow-sm">
                        <table class="table table-borderless align-middle mb-0">
                            <tbody>
                                <c:forEach var="u" items="${pendingAdvisors}">
                                    <tr class="border-bottom">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="bg-light rounded-circle p-2 me-3"><i class="fa-solid fa-user-tie fs-4 text-primary"></i></div>
                                                <div><div class="fw-bold text-dark">${u.username}</div><div class="small text-muted">${u.email}</div></div>
                                            </div>
                                        </td>
                                        <td><span class="status-badge bg-warning text-dark">Pending</span></td>
                                        <td class="text-end">
                                            <form action="admin/verify" method="post" class="d-flex gap-2 justify-content-end">
                                                <input type="hidden" name="userId" value="${u.userId}">
                                                <button type="submit" name="action" value="REJECT" class="btn btn-outline-danger fw-bold btn-sm rounded-pill px-3">Reject</button>
                                                <button type="submit" name="action" value="APPROVE" class="btn btn-brand btn-sm shadow-sm px-3">Approve</button>
                                            </form>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </div>
            </c:if>

            <div class="row g-4 mb-5">
                <div class="col-lg-8">
                    <div class="card-pro p-4 h-100 border border-primary border-opacity-25 bg-primary-subtle">
                        <div class="d-flex align-items-center mb-3">
                            <i class="fa-solid fa-headset fs-4 text-primary-emphasis me-2"></i>
                            <h5 class="fw-bold text-primary-emphasis mb-0">Help Desk</h5>
                        </div>
                        <c:if test="${empty openTickets}"><p class="text-muted small mb-0 ms-4">All caught up! No open tickets.</p></c:if>
                        <c:if test="${not empty openTickets}">
                            <div class="bg-white rounded-4 p-3 shadow-sm">
                                <table class="table table-borderless align-middle mb-0">
                                    <tbody>
                                        <c:forEach var="t" items="${openTickets}">
                                            <tr class="border-bottom">
                                                <td><div class="fw-bold text-dark">#${t.ticketId}</div><div class="badge bg-light text-dark border">${t.requestType}</div></td>
                                                <td class="text-muted small w-50">${t.description}</td>
                                                <td class="text-end">
                                                    <form action="admin/ticket/resolve" method="post">
                                                        <input type="hidden" name="ticketId" value="${t.ticketId}">
                                                        <button class="btn btn-primary btn-sm rounded-pill px-4 fw-bold shadow-sm">Resolve</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        </c:forEach>
                                    </tbody>
                                </table>
                            </div>
                        </c:if>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card-pro h-100 p-4 hover-card d-flex flex-column justify-content-center align-items-center text-center border"
                         data-bs-toggle="modal" data-bs-target="#historyModal">
                        <div class="bg-light rounded-circle p-3 mb-3">
                            <i class="fa-solid fa-clock-rotate-left fs-2 text-secondary"></i>
                        </div>
                        <h5 class="fw-bold">Ticket History</h5>
                        <p class="text-muted small mb-3">View all resolved support requests</p>
                        <span class="badge bg-secondary rounded-pill px-3 py-2">
                            ${not empty resolvedTickets ? fn:length(resolvedTickets) : 0} Resolved
                        </span>
                    </div>
                </div>
            </div>

            <h4 class="fw-bold mb-4">System Management</h4>
            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card-pro p-4 h-100"><h5 class="fw-bold mb-4">Advisors List</h5>
                        <c:forEach var="adv" items="${allAdvisors}">
                            <c:if test="${adv.status == 'APPROVED' || adv.status == null}">
                                <div class="d-flex justify-content-between align-items-center py-3 border-bottom">
                                    <span class="fw-bold text-dark">${adv.username}</span>
                                    <button class="btn btn-light btn-sm border rounded-pill px-3 fw-bold" data-bs-toggle="modal" data-bs-target="#modal${adv.userId}">View Clients</button>
                                </div>
                                <div class="modal fade" id="modal${adv.userId}" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header border-0"><h5 class="fw-bold">Managed by ${adv.username}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                        <div class="modal-body">
                                            <c:set var="found" value="false" />
                                            <c:forEach var="inv" items="${allInvestors}"><c:if test="${inv.advisorId == adv.userId}"><c:set var="found" value="true" />
                                                <div class="d-flex justify-content-between mb-2 p-2 bg-light rounded"><span><strong>${inv.username}</strong></span><span class="text-muted small">${inv.email}</span></div>
                                            </c:if></c:forEach>
                                            <c:if test="${!found}"><p class="text-center text-muted">No clients assigned yet.</p></c:if>
                                        </div>
                                    </div></div>
                                </div>
                            </c:if>
                        </c:forEach>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card-pro p-4 h-100"><h5 class="fw-bold mb-4">Investor Connections</h5>
                        <table class="table align-middle"><thead class="text-muted small text-uppercase bg-light"><tr><th class="ps-3 rounded-start-3">Investor</th><th>Status</th><th class="text-end pe-3 rounded-end-3">Action</th></tr></thead>
                            <tbody><c:forEach var="inv" items="${allInvestors}"><tr><td class="ps-3 fw-bold">${inv.username}</td><td><span class="badge rounded-pill ${not empty inv.advisorId ? 'bg-success' : 'bg-secondary'}">${not empty inv.advisorId ? 'Linked' : 'Open'}</span></td>
                                <td class="text-end pe-3"><c:if test="${not empty inv.advisorId}"><form action="admin/disconnect" method="post"><input type="hidden" name="investorId" value="${inv.userId}"><button class="btn btn-link text-danger p-0 fw-bold text-decoration-none small">Disconnect</button></form></c:if></td></tr></c:forEach></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </c:if>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Capture the message from the RedirectAttributes
            const errorMsg = "${errorPopup}";
            const successMsg = "${successPopup}";

            if (errorMsg && errorMsg !== "null" && errorMsg.trim() !== "") {
                Swal.fire({
                    icon: 'error',
                    title: 'Blocked!',
                    text: errorMsg,
                    confirmButtonColor: '#d33'
                });
            }

            if (successMsg && successMsg !== "null" && successMsg.trim() !== "") {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: successMsg,
                    timer: 2000,
                    showConfirmButton: false
                });
            }
        });
    </script>
</body>
</html>
