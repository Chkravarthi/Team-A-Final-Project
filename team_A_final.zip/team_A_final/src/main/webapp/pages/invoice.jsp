<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Invoice #${transaction.transactionId} | GrowMore</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --color-primary: #00d09c;
            --color-secondary: #2c3e50;
            --bg-light: #f4fcfb;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--color-secondary);
            padding: 40px 0;
        }

        .invoice-card {
            background: white;
            max-width: 600px;
            margin: 0 auto;
            padding: 40px;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.08);
            position: relative;
            overflow: hidden;
        }

        /* Top decorative bar */
        .invoice-card::before {
            content: "";
            position: absolute;
            top: 0; left: 0; width: 100%; height: 8px;
            background: var(--color-primary);
        }

        .brand-logo { color: var(--color-secondary); font-weight: 800; font-size: 1.8rem; letter-spacing: -0.5px; }
        .logo-icon { color: var(--color-primary); }

        .invoice-header { border-bottom: 2px dashed #f1f5f9; padding-bottom: 30px; margin-bottom: 30px; }

        .label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #94a3b8; font-weight: 700; margin-bottom: 5px; }
        .value { font-weight: 600; color: var(--color-secondary); font-size: 1rem; }

        .total-box {
            background-color: #f8fafc;
            border-radius: 16px;
            padding: 20px;
            text-align: center;
            margin: 20px 0;
            border: 1px solid #e2e8f0;
        }
        .total-amount { font-size: 2rem; font-weight: 700; color: var(--color-secondary); }

        .table-custom td { padding: 12px 0; border-bottom: 1px solid #f1f5f9; color: var(--color-secondary); }
        .table-custom tr:last-child td { border-bottom: none; }

        .btn-print {
            background-color: var(--color-secondary);
            color: white;
            border-radius: 50px;
            padding: 12px 30px;
            font-weight: 600;
            border: none;
            transition: 0.2s;
        }
        .btn-print:hover { background-color: #1e293b; transform: translateY(-2px); color: white; }

        /* Print Styles */
        @media print {
            body { background: white; padding: 0; }
            .invoice-card { box-shadow: none; max-width: 100%; border-radius: 0; padding: 20px; }
            .d-print-none { display: none !important; }
            .total-box { background-color: #f8fafc !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body>

    <div class="invoice-card">

        <div class="invoice-header d-flex justify-content-between align-items-center">
            <div>
                <div class="brand-logo"><i class="fa-solid fa-chart-line logo-icon me-2"></i>GrowMore</div>
                <div class="text-muted small mt-1">Investment & Wealth Management</div>
            </div>
            <div class="text-end">
                <div class="badge bg-light text-dark border px-3 py-2 rounded-pill">
                    RECEIPT #${transaction.transactionId}
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-6">
                <div class="label">Date</div>
                <div class="value"><fmt:formatDate value="${transaction.transactionDate}" pattern="MMMM dd, yyyy"/></div>
            </div>
            <div class="col-6 text-end">
                <div class="label">Order Type</div>
                <div class="value">
                    <c:choose>
                        <c:when test="${transaction.transactionType == 'BUY'}">
                            <span class="text-success"><i class="fa-solid fa-arrow-trend-up me-1"></i> BUY ORDER</span>
                        </c:when>
                        <c:otherwise>
                            <span class="text-danger"><i class="fa-solid fa-arrow-trend-down me-1"></i> SELL ORDER</span>
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>
        </div>

        <div class="total-box">
            <div class="label">Total Transaction Value</div>
            <div class="total-amount">₹<fmt:formatNumber value="${transaction.totalValue}" minFractionDigits="2"/></div>
        </div>

        <div class="mb-5">
            <div class="label mb-3">Transaction Details</div>
            <table class="table table-custom table-borderless">
                <tr>
                    <td class="text-muted"><i class="fa-solid fa-box-open me-2"></i>Asset Name</td>
                    <td class="text-end fw-bold">${transaction.assetName}</td>
                </tr>
                <tr>
                    <td class="text-muted"><i class="fa-solid fa-layer-group me-2"></i>Quantity</td>
                    <td class="text-end fw-bold">${transaction.quantity} Units</td>
                </tr>
                <tr>
                    <td class="text-muted"><i class="fa-solid fa-tag me-2"></i>Price per Unit</td>
                    <td class="text-end fw-bold">₹<fmt:formatNumber value="${transaction.price}" minFractionDigits="2"/></td>
                </tr>
            </table>
        </div>

        <div class="text-center mt-5 pt-4 border-top">
            <p class="small text-muted mb-1">Thank you for investing with GrowMore.</p>
            <p class="small text-muted opacity-50">This is a computer-generated receipt and does not require a signature.</p>
        </div>

        <div class="text-center mt-4 d-print-none">
            <button onclick="window.print()" class="btn btn-print shadow-lg">
                <i class="fa-solid fa-print me-2"></i> Print Invoice
            </button>
            <div class="mt-3">
                <a href="javascript:history.back()" class="text-decoration-none text-muted small fw-bold">Back to Transactions</a>
            </div>
        </div>

    </div>

</body>
</html>