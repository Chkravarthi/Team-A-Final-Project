
package com.example.demo.test_modules;

import com.example.demo.bean.Transaction;
import com.example.demo.repository.TransactionRepository;
import com.example.demo.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private TransactionService transactionService;

    // 1) RECORD
    @Test
    void record_shouldSaveTransaction() {
        // Act
        transactionService.record(101, "BUY", "AAPL", 10, 150.0);

        // Assert
        ArgumentCaptor<Transaction> captor = ArgumentCaptor.forClass(Transaction.class);
        verify(transactionRepository, times(1)).save(captor.capture());
        Transaction saved = captor.getValue();

        assertEquals(101, saved.getUserId());
        assertEquals("BUY", saved.getType());
        assertEquals("AAPL", saved.getAssetName());
        assertEquals(10, saved.getQuantity());
        assertEquals(150.0, saved.getPrice());
        assertNotNull(saved.getTransactionDate());
    }

    // 2) FETCH HISTORY
    @Test
    void getTransactionsByUserId_shouldReturnList() {
        Transaction t1 = new Transaction();
        t1.setTransactionId(1);
        t1.setUserId(101);
        t1.setType("BUY");
        t1.setAssetName("AAPL");
        t1.setQuantity(5);
        t1.setPrice(100.0);
        t1.setTransactionDate(new Date());

        Transaction t2 = new Transaction();
        t2.setTransactionId(2);
        t2.setUserId(101);
        t2.setType("SELL");
        t2.setAssetName("AAPL");
        t2.setQuantity(2);
        t2.setPrice(120.0);
        t2.setTransactionDate(new Date());

        when(transactionRepository.findByUserIdOrderByTransactionDateDesc(101))
                .thenReturn(Arrays.asList(t1, t2));

        List<Transaction> result = transactionService.getTransactionsByUserId(101);

        assertEquals(2, result.size());
        verify(transactionRepository, times(1))
                .findByUserIdOrderByTransactionDateDesc(101);
    }

    // 3) FETCH SINGLE RECEIPT
    @Test
    void getTransactionById_shouldReturnTransactionWhenFound() {
        Transaction t = new Transaction();
        t.setTransactionId(99);
        t.setUserId(101);
        t.setType("BUY");
        t.setAssetName("GOOG");
        t.setQuantity(3);
        t.setPrice(2000.0);
        t.setTransactionDate(new Date());

        when(transactionRepository.findById(99)).thenReturn(Optional.of(t));

        Transaction found = transactionService.getTransactionById(99);

        assertNotNull(found);
        assertEquals(99, found.getTransactionId());
        verify(transactionRepository, times(1)).findById(99);
    }

    // 4) ADMIN VIEW (ALL)
    @Test
    void getAllTransactions_shouldReturnAll() {
        Transaction t = new Transaction();
        t.setTransactionId(1);
        t.setUserId(101);
        t.setType("BUY");
        t.setAssetName("AAPL");
        t.setQuantity(10);
        t.setPrice(150.0);
        t.setTransactionDate(new Date());

        when(transactionRepository.findAll()).thenReturn(List.of(t));

        List<Transaction> all = transactionService.getAllTransactions();

        assertEquals(1, all.size());
        verify(transactionRepository, times(1)).findAll();
    }

    // 5) AVG BUY PRICE
    @Test
    void calculateAvgBuyPrice_shouldComputeWeightedAverage() {
        Transaction buy1 = new Transaction();
        buy1.setType("BUY");
        buy1.setAssetName("AAPL");
        buy1.setQuantity(10);
        buy1.setPrice(100.0);

        Transaction buy2 = new Transaction();
        buy2.setType("BUY");
        buy2.setAssetName("AAPL");
        buy2.setQuantity(20);
        buy2.setPrice(150.0);

        Transaction sell = new Transaction();
        sell.setType("SELL");
        sell.setAssetName("AAPL");
        sell.setQuantity(5);
        sell.setPrice(160.0);

        when(transactionRepository.findByUserIdOrderByTransactionDateDesc(101))
                .thenReturn(Arrays.asList(buy1, buy2, sell));

        double avg = transactionService.calculateAvgBuyPrice(101, "AAPL");

        // (10*100 + 20*150) / (10+20) = 133.3333...
        assertEquals(133.3333, avg, 0.0001);
        verify(transactionRepository, times(1))
                .findByUserIdOrderByTransactionDateDesc(101);
    }
}

