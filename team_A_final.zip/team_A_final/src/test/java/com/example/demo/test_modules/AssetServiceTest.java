package com.example.demo.test_modules;

import com.example.demo.bean.Asset;
import com.example.demo.repository.AssetRepository;
import com.example.demo.service.AssetService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AssetServiceTest {

    @Mock private AssetRepository assetRepository;
    @InjectMocks private AssetService assetService;

    @Test
    void testGetMarketAssets_UniqueFiltering_Check() {
        // GIVEN: Repository returns duplicates with different casing
        Asset a1 = new Asset(); a1.setName("Gold");
        Asset a2 = new Asset(); a2.setName("GOLD");
        Asset a3 = new Asset(); a3.setName("Silver");

        when(assetRepository.findAll()).thenReturn(Arrays.asList(a1, a2, a3));

        // WHEN
        List<Asset> result = assetService.getMarketAssets();

        // THEN: Verify only unique, uppercased names remain
        // If logic fails to filter, size will be 3 instead of 2.
        assertAll("Unique Market Asset Check",
                () -> assertEquals(2, result.size(), "Market view should filter out duplicate names"),
                () -> assertTrue(result.stream().anyMatch(a -> a.getName().equals("GOLD")), "Name should be normalized to GOLD"),
                () -> assertTrue(result.stream().anyMatch(a -> a.getName().equals("SILVER")), "Name should be normalized to SILVER")
        );
    }

    @Test
    void testBuyAsset_QuantityUpdate_Check() {
        // GIVEN: User already has 10 units of an asset
        Asset existing = new Asset();
        existing.setName("Apple");
        existing.setQuantity(10);

        when(assetRepository.findByPortfolioId(1)).thenReturn(Arrays.asList(existing));

        // WHEN: Buying 5 more units
        assetService.buyAsset(1, "Apple", "Stock", 5, 150.0);

        // THEN: Total should be 15. If math is broken in Service (+ to -), shows difference.
        assertEquals(15, existing.getQuantity(), "The quantity should increase after buying!");
    }

    @Test
    void testSellAsset_PartialQuantity_Check() {
        // GIVEN: User has 10 units
        Asset existing = new Asset();
        existing.setName("Bitcoin");
        existing.setQuantity(10);

        when(assetRepository.findByPortfolioId(1)).thenReturn(Arrays.asList(existing));

        // WHEN: Selling 4 units
        assetService.sellAsset(1, "Bitcoin", 4);

        // THEN: Expected 6. If logic is wrong, JUnit shows side-by-side comparison.
        assertEquals(6, existing.getQuantity(), "The quantity should decrease correctly after selling!");
    }
}