package com.example.demo.test_modules;

import com.example.demo.bean.User;
import com.example.demo.repository.AuthRepository;
import com.example.demo.service.AuthService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock private AuthRepository authRepository;
    @Mock private PasswordEncoder passwordEncoder;
    @InjectMocks private AuthService authService;

    // --- REGISTRATION SCENARIOS ---

    @Test
    void registerUser_DuplicateEmail_Check() {
        // GIVEN
        User user = new User();
        user.setEmail("exists@test.com");
        when(authRepository.existsByEmail("exists@test.com")).thenReturn(true);

        // WHEN: Catch the message instead of letting it crash
        String actualMessage = "";
        try {
            authService.registerUser(user);
        } catch (Exception e) {
            actualMessage = e.getMessage();
        }

        // THEN: This gives the Yellow Failure with "Expected vs Actual"
        assertEquals("Email already exists!", actualMessage, "FAIL POINT 1: Email check message mismatch!");
    }

    @Test
    void registerUser_Status_Advisor_Check() {
        // GIVEN
        User user = new User();
        user.setRole("ADVISOR");
        when(authRepository.existsByEmail(any())).thenReturn(false);
        when(passwordEncoder.encode(any())).thenReturn("hash");
        when(authRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        // WHEN
        User result = null;
        try {
            result = authService.registerUser(user);
        } catch (Exception e) {
            fail("Registration crashed unexpectedly: " + e.getMessage());
        }

        // THEN: If logic is wrong, shows difference (e.g., Expected: PENDING, Actual: APPROVED)
        assertEquals("PENDING", result.getStatus(), "FAIL POINT 3: Role-based status is incorrect!");
    }

    // --- LOGIN SCENARIOS ---

    @Test
    void loginUser_NotFound_Check() {
        // GIVEN
        when(authRepository.findByEmail("noone@test.com")).thenReturn(Optional.empty());

        // WHEN
        String actualMessage = "";
        try {
            authService.loginUser("noone@test.com", "pass");
        } catch (Exception e) {
            actualMessage = e.getMessage();
        }

        // THEN: Shows difference if message changes
        assertEquals("User not found", actualMessage, "FAIL POINT 6: User lookup message mismatch!");
    }

    @Test
    void loginUser_WrongPassword_Check() {
        // GIVEN
        User existing = new User();
        existing.setPassword("hashed");
        when(authRepository.findByEmail(anyString())).thenReturn(Optional.of(existing));
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(false);

        // WHEN
        String actualMessage = "";
        try {
            authService.loginUser("test@test.com", "wrong");
        } catch (Exception e) {
            actualMessage = e.getMessage();
        }

        // THEN: Shows comparison window
        assertEquals("Invalid Password", actualMessage, "FAIL POINT 5: Password rejection message mismatch!");
    }
}