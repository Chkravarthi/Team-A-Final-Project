
package com.example.demo.test_modules;

import com.example.demo.bean.Asset;
import com.example.demo.bean.Portfolio;
import com.example.demo.repository.AssetRepository;
import com.example.demo.repository.PortfolioRepository;
import com.example.demo.service.MarketService;
import com.example.demo.service.PortfolioService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PortfolioServiceTest {

    @Mock private PortfolioRepository portfolioRepository;
    @Mock private AssetRepository assetRepository;
    @Mock private MarketService marketService;

    @InjectMocks
    private PortfolioService portfolioService;

    // 1) CORE: calculateMetrics
    @Test
    void calculateMetrics_shouldComputeInvestedCurrentGrowthAndPL() {
        // Portfolio with target (totalValue) = 2000
        Portfolio p = new Portfolio();
        p.setPortfolioId(10);
        p.setTotalValue(BigDecimal.valueOf(2000.0));

        // Assets: A (price 100, qty 5), B (price 200, qty 2)
        Asset a = new Asset(); a.setName("A"); a.setPrice(100.0); a.setQuantity(5); // invested 500
        Asset b = new Asset(); b.setName("B"); b.setPrice(200.0); b.setQuantity(2); // invested 400
        when(assetRepository.findByPortfolioId(10)).thenReturn(List.of(a, b));

        // Market prices: use MarketService
        when(marketService.getCurrentPrice("A", 100.0)).thenReturn(120.0); // current 120*5 = 600
        when(marketService.getCurrentPrice("B", 200.0)).thenReturn(210.0); // current 210*2 = 420

        // Act
        portfolioService.calculateMetrics(p);

        // Assert
        // Invested = 500 + 400 = 900
        assertEquals(900.0, p.getInvestedAmount(), 0.0001);

        // Current = 600 + 420 = 1020
        assertEquals(1020.0, p.getLiveValue(), 0.0001);

        // GrowthPct = (current / target) * 100 = (1020/2000)*100 = 51.0
        assertEquals(51.0, p.getGrowthPct(), 0.0001);

        // P/L% = ((current - invested) / invested) * 100 = ((1020 - 900)/900)*100 = 13.3333...
        assertEquals(13.3333, p.getProfitLossPct(), 0.0001);

        // Verify market calls
        verify(marketService, times(1)).getCurrentPrice("A", 100.0);
        verify(marketService, times(1)).getCurrentPrice("B", 200.0);
    }

    // 2) getPortfoliosByInvestor: applies calculateMetrics to each
    @Test
    void getPortfoliosByInvestor_shouldFetchAndCalculateForEachPortfolio() {
        Portfolio p1 = new Portfolio(); p1.setPortfolioId(1); p1.setTotalValue(BigDecimal.valueOf(1000.0));
        Portfolio p2 = new Portfolio(); p2.setPortfolioId(2); p2.setTotalValue(BigDecimal.valueOf(500.0));
        when(portfolioRepository.findByInvestorId(42)).thenReturn(List.of(p1, p2));

        // assets for p1
        Asset a11 = new Asset(); a11.setName("X"); a11.setPrice(100.0); a11.setQuantity(5);
        when(assetRepository.findByPortfolioId(1)).thenReturn(List.of(a11));
        when(marketService.getCurrentPrice("X", 100.0)).thenReturn(110.0); // current = 550

        // assets for p2
        Asset a21 = new Asset(); a21.setName("Y"); a21.setPrice(50.0); a21.setQuantity(3);
        when(assetRepository.findByPortfolioId(2)).thenReturn(List.of(a21));
        when(marketService.getCurrentPrice("Y", 50.0)).thenReturn(48.0); // current = 144

        // Act
        List<Portfolio> result = portfolioService.getPortfoliosByInvestor(42);

        // Assert
        assertEquals(2, result.size());

        // p1: invested = 500, current = 550, target = 1000
        assertEquals(500.0, p1.getInvestedAmount(), 0.0001);
        assertEquals(550.0, p1.getLiveValue(), 0.0001);
        assertEquals(55.0, p1.getGrowthPct(), 0.0001);
        assertEquals(10.0, p1.getProfitLossPct(), 0.0001);

        // p2: invested = 150, current = 144, target = 500
        assertEquals(150.0, p2.getInvestedAmount(), 0.0001);
        assertEquals(144.0, p2.getLiveValue(), 0.0001);
        assertEquals(28.8, p2.getGrowthPct(), 0.0001);
        assertEquals(-4.0, p2.getProfitLossPct(), 0.0001);

        verify(portfolioRepository, times(1)).findByInvestorId(42);
        verify(marketService, times(1)).getCurrentPrice("X", 100.0);
        verify(marketService, times(1)).getCurrentPrice("Y", 50.0);
    }

    // 3) createPortfolio: save
    @Test
    void createPortfolio_shouldSave() {
        Portfolio p = new Portfolio();
        portfolioService.createPortfolio(p);
        verify(portfolioRepository, times(1)).save(p);
    }

    // 4) getPortfolioById: findById().orElse(null)
    @Test
    void getPortfolioById_shouldReturnPortfolioWhenPresent() {
        Portfolio p = new Portfolio(); p.setPortfolioId(77);
        when(portfolioRepository.findById(77)).thenReturn(Optional.of(p));

        Portfolio found = portfolioService.getPortfolioById(77);

        assertNotNull(found);
        assertEquals(77, found.getPortfolioId());
        verify(portfolioRepository, times(1)).findById(77);
    }

    // 5) deletePortfolio: deleteById
    @Test
    void deletePortfolio_shouldDeleteById() {
        portfolioService.deletePortfolio(99);
        verify(portfolioRepository, times(1)).deleteById(99);
    }
}
