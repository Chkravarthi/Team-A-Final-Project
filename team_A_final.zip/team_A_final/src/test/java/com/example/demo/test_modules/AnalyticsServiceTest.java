
package com.example.demo.test_modules;

import com.example.demo.bean.Asset;
import com.example.demo.bean.PerformanceReport;
import com.example.demo.bean.Portfolio;
import com.example.demo.repository.AssetRepository;
import com.example.demo.repository.PerformanceRepository;
import com.example.demo.repository.PortfolioRepository;
import com.example.demo.service.AnalyticsService;
import com.example.demo.service.AssetService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AnalyticsServiceTest {

    @Mock private PerformanceRepository performanceRepository;
    @Mock private PortfolioRepository portfolioRepository;
    @Mock private AssetService assetService;
    @Mock private AssetRepository assetRepository;

    @InjectMocks
    private AnalyticsService analyticsService;

    // 1) getAllMarketAssetNames
    @Test
    void getAllMarketAssetNames_shouldReturnDistinctNames() {
        when(assetRepository.findDistinctNames()).thenReturn(Arrays.asList("AAPL", "MSFT", "GOOG"));

        List<String> names = analyticsService.getAllMarketAssetNames();

        assertEquals(3, names.size());
        assertTrue(names.contains("AAPL"));
        verify(assetRepository, times(1)).findDistinctNames();
    }

    // 2) getLiveAssetPrice
    @Test
    void getLiveAssetPrice_shouldReturnPriceNearBase_withTrendAndNoise() {
        Asset a = new Asset();
        a.setName("AAPL");
        a.setPrice(100.0);
        a.setQuantity(10);

        when(assetRepository.findByName("AAPL")).thenReturn(List.of(a));

        double live = analyticsService.getLiveAssetPrice("AAPL");

        // Trend is ±2% and noise is ±0.5% → multiplier ~ [0.975, 1.025]
        assertTrue(live >= 97.5 && live <= 102.5,
                "Live price should be within ±2.5% of base due to trend+noise");
        verify(assetRepository, times(1)).findByName("AAPL");
    }



    // 4) getAssetAllocation
    @Test
    void getAssetAllocation_shouldComputePercentagesRoundedToTwoDecimals() {
        Asset a1 = new Asset();
        a1.setName("Equity");
        a1.setPrice(100.0);
        a1.setQuantity(2); // 200

        Asset a2 = new Asset();
        a2.setName("Debt");
        a2.setPrice(50.0);
        a2.setQuantity(2); // 100

        when(assetService.getAssetsByPortfolio(10)).thenReturn(Arrays.asList(a1, a2));

        var allocation = analyticsService.getAssetAllocation(10);

        // Total = 300 → Equity = 66.666..., Debt = 33.333...
        // Rounded HALF_UP to 2 decimals
        assertEquals(2, allocation.size());
        assertEquals(66.67, allocation.get("Equity"));
        assertEquals(33.33, allocation.get("Debt"));
    }

    // 5) getInvestorTotalPerformance
    @Test
    void getInvestorTotalPerformance_shouldReturnPortfolioWeightedReturnPctRounded() {
        // Two portfolios for investor 42
        Portfolio p1 = mock(Portfolio.class);
        when(p1.getPortfolioId()).thenReturn(101);
        when(p1.getTotalValue()).thenReturn(BigDecimal.valueOf(1000.0));

        Portfolio p2 = mock(Portfolio.class);
        when(p2.getPortfolioId()).thenReturn(102);
        when(p2.getTotalValue()).thenReturn(BigDecimal.valueOf(500.0));

        when(portfolioRepository.findByInvestorId(42)).thenReturn(List.of(p1, p2));

        // Current values from assets: p1 → 1100; p2 → 400
        Asset a11 = new Asset(); a11.setName("AAPL"); a11.setPrice(100.0); a11.setQuantity(11); // 1100
        Asset a21 = new Asset(); a21.setName("BOND"); a21.setPrice(80.0);  a21.setQuantity(5);  // 400

        when(assetService.getAssetsByPortfolio(101)).thenReturn(List.of(a11));
        when(assetService.getAssetsByPortfolio(102)).thenReturn(List.of(a21));

        // Total initial = 1500; total current = 1500 → 0.00%
        double perfZero = analyticsService.getInvestorTotalPerformance(42);
        assertEquals(0.00, perfZero);

        // Adjust p1 current to 1200 (12 * 100)
        a11.setQuantity(12);
        double perfUp = analyticsService.getInvestorTotalPerformance(42);
        // New current = 1600; (1600 - 1500) / 1500 * 100 = 6.666... → rounded 6.67
        assertEquals(6.67, perfUp);
    }
}
